@echo off
title Risk Cartography - AFA/Sapin II Compliance

:: UTF-8 encoding
set PYTHONIOENCODING=utf-8
set PYTHONUTF8=1

echo.
echo ====================================================================
echo        RISK CARTOGRAPHY - AFA/Sapin II Compliance Tool
echo                        Version 1.0.0
echo ====================================================================
echo.

:: Navigate to script directory
cd /d "%~dp0"

:: ============================================================
:: STEP 1: Check Python
:: ============================================================
echo [1/5] Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] Python is not installed or not in PATH
    echo.
    echo Please install Python 3.8+ from https://www.python.org/downloads/
    echo IMPORTANT: Check "Add Python to PATH" during installation
    echo.
    start https://www.python.org/downloads/
    pause
    exit /b 1
)
python --version

:: ============================================================
:: STEP 2: Create virtual environment
:: ============================================================
echo.
echo [2/5] Setting up virtual environment...
if not exist "venv\Scripts\activate.bat" (
    echo Creating venv...
    python -m venv venv
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment
        pause
        exit /b 1
    )
    echo venv created.
) else (
    echo venv already exists.
)

:: ============================================================
:: STEP 3: Activate virtual environment
:: ============================================================
echo.
echo [3/5] Activating virtual environment...
call venv\Scripts\activate.bat
if errorlevel 1 (
    echo [ERROR] Failed to activate virtual environment
    pause
    exit /b 1
)
echo Activated. Python now points to:
where python

:: ============================================================
:: STEP 4: Install dependencies
:: ============================================================
echo.
echo [4/5] Installing dependencies...

:: Check if already installed
python -c "import pandas, openpyxl, reportlab, xlsxwriter" >nul 2>&1
if errorlevel 1 (
    echo Installing packages...
    python -m pip install --upgrade pip
    python -m pip install pandas openpyxl reportlab xlsxwriter
    if errorlevel 1 (
        echo [ERROR] Failed to install packages
        pause
        exit /b 1
    )
) else (
    echo All packages already installed.
)

:: Verify
echo.
echo Verifying packages:
python -c "import pandas; print('  pandas:', pandas.__version__)"
python -c "import openpyxl; print('  openpyxl:', openpyxl.__version__)"
python -c "import reportlab; print('  reportlab:', reportlab.Version)"
python -c "import xlsxwriter; print('  xlsxwriter:', xlsxwriter.__version__)"

:: ============================================================
:: STEP 5: Launch application
:: ============================================================
echo.
echo [5/5] Starting application...
echo.
echo ====================================================================
echo   Browser will open at: http://localhost:8501
echo   Press Ctrl+C to stop
echo ====================================================================
echo.

python -m streamlit run app.py --server.port 8501 --server.address 127.0.0.1 --browser.gatherUsageStats false

:: Deactivate on exit
call venv\Scripts\deactivate.bat 2>nul
pause
