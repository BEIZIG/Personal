#!/usr/bin/env python3
"""
Generate realistic demo data for Risk Cartography presentation.
Creates 8 Excel files with coherent AFA/Sapin II risk scenarios.
"""

import pandas as pd
import random
from pathlib import Path
from datetime import datetime

# Output directory
OUTPUT_DIR = Path(__file__).parent / "demo_input"
OUTPUT_DIR.mkdir(exist_ok=True)

# Entity names (realistic business units)
ENTITIES = [
    "ACME_Headquarters",
    "ACME_Europe",
    "ACME_North_America",
    "ACME_Asia_Pacific",
    "ACME_Manufacturing",
    "ACME_R&D",
    "ACME_Finance_Services",
    "ACME_Supply_Chain"
]

# Risk scenarios by category (AFA/Sapin II compliant)
RISK_SCENARIOS = {
    "A": {  # Procurement
        "name": "Procurement & Supply",
        "scenarios": [
            ("Supplier kickback scheme", "A buyer receives personal benefits from a supplier in exchange for favorable treatment", "Single-source contracts, high-value purchases, weak approval controls"),
            ("Invoice fraud", "Supplier submits inflated invoices with internal complicity", "Complex services, no detailed pricing, limited invoice verification"),
            ("Order splitting", "Purchase orders split to bypass approval thresholds", "High approval limits, no cumulative tracking"),
            ("Conflict of interest - supplier", "Employee has undisclosed relationship with supplier", "No conflict declaration process, family businesses"),
            ("Fictitious supplier", "Creation of fake supplier to embezzle funds", "Weak vendor validation, centralized payment control"),
        ],
        "prevention": [
            "Competitive bidding for contracts >€50K",
            "Segregation of duties: requester/approver/payer",
            "Annual supplier audit program",
            "Conflict of interest declarations",
            "Vendor master data validation process",
        ]
    },
    "C": {  # Commercial/Sales
        "name": "Commercial & Sales",
        "scenarios": [
            ("Excessive client gifts", "Sales team offers luxury gifts to secure contracts", "High-value deals, competitive markets, entertainment budgets"),
            ("Hidden commissions to agents", "Intermediaries paid to influence client decisions", "Export markets, complex tenders, use of agents"),
            ("Bid rigging with competitors", "Coordinated pricing with competitors on tenders", "Oligopolistic markets, repeated contract awards"),
            ("Bribery of client employees", "Direct payments to client decision-makers", "High-risk countries, large public contracts"),
            ("Unfair commercial conditions", "Preferential terms in exchange for personal benefit", "Complex pricing, discretionary discounts"),
        ],
        "prevention": [
            "Gift & hospitality policy with €150 limit",
            "Third-party due diligence program",
            "Sales commission transparency rules",
            "Tender process audit trail",
            "Commercial terms approval matrix",
        ]
    },
    "R": {  # Human Resources
        "name": "Human Resources",
        "scenarios": [
            ("Nepotism in hiring", "Hiring relatives of external decision-makers for favor", "Executive hiring, no HR oversight"),
            ("Ghost employee", "Fictitious employee on payroll for client/official benefit", "Remote locations, weak HR controls"),
            ("Undisclosed conflict - recruitment", "Manager hires personal acquaintance without disclosure", "Decentralized hiring, no background checks"),
            ("Bonus manipulation", "Manager awards discretionary bonuses to buy silence", "Large bonus pools, subjective criteria"),
            ("Favoritism in promotions", "Promotion based on personal relationship rather than merit", "Subjective evaluation, single decision-maker"),
        ],
        "prevention": [
            "Multi-level interview process",
            "HR validation of all hiring decisions",
            "Background verification for key roles",
            "Objective performance evaluation criteria",
            "Promotion committee reviews",
        ]
    },
    "F": {  # Finance
        "name": "Finance & Accounting",
        "scenarios": [
            ("Facilitation payment", "Payment to expedite administrative procedures", "International operations, customs, permits"),
            ("Fraudulent accounting entries", "Disguising improper payments as consulting fees", "Multiple expense categories, weak coding"),
            ("Expense report fraud", "Inflated expenses to fund unofficial payments", "Travel expenses, entertainment costs"),
            ("Wire transfer to unauthorized accounts", "Payments diverted to third-party accounts", "Multiple banking relationships, manual approvals"),
            ("Cash handling irregularities", "Undocumented cash payments for improper purposes", "Petty cash, field operations"),
        ],
        "prevention": [
            "Four-eyes principle for payments >€10K",
            "Expense report verification and sampling",
            "Bank account validation process",
            "Cash transaction limits and controls",
            "Regular accounting reconciliation",
        ]
    },
    "M": {  # M&A and JV
        "name": "M&A & Joint Ventures",
        "scenarios": [
            ("Acquisition with corruption liability", "Target company has undisclosed corruption exposure", "Cross-border acquisitions, emerging markets"),
            ("JV partner corruption", "Joint venture partner pays bribes on behalf of JV", "Local partners, government contracts"),
            ("Conflict of interest in M&A", "Executive has personal stake in target company", "Proprietary deals, limited disclosure"),
            ("Inflated advisory fees", "Excessive fees to advisors with undisclosed relationships", "Multiple advisors, complex transactions"),
            ("Post-acquisition integration gaps", "Failure to implement compliance in acquired entity", "Rapid integration, limited resources"),
        ],
        "prevention": [
            "Pre-acquisition compliance due diligence",
            "JV partner code of conduct requirements",
            "Conflict disclosure for deal team",
            "Advisory fee benchmarking",
            "100-day compliance integration plan",
        ]
    },
    "S": {  # Sponsoring
        "name": "Sponsorship & Donations",
        "scenarios": [
            ("Charity donation to official's foundation", "Donations to entities linked to decision-makers", "Charitable giving, community programs"),
            ("Sponsorship as disguised bribe", "Event sponsorship benefiting client/official personally", "Sports events, cultural programs"),
            ("Political contribution violation", "Indirect political funding through intermediaries", "Industry associations, PACs"),
            ("Embezzlement of sponsorship funds", "Misappropriation of allocated sponsorship budget", "Large budgets, weak oversight"),
            ("Quid pro quo in grant making", "Grants conditioned on business advantages", "CSR programs, educational grants"),
        ],
        "prevention": [
            "Charitable contribution approval committee",
            "Sponsorship beneficiary due diligence",
            "No political contributions policy",
            "Sponsorship budget tracking and audit",
            "Grant recipient annual reporting",
        ]
    },
    "P": {  # Public Officials
        "name": "Public Officials Relations",
        "scenarios": [
            ("Unregistered lobbying activity", "Influencing officials without proper registration", "Regulatory matters, legislative advocacy"),
            ("Traffic of influence", "Using intermediaries to access officials", "Permits, licenses, government decisions"),
            ("Improper hospitality to officials", "Excessive entertainment of government employees", "Official visits, conferences"),
            ("Favoritism in public procurement", "Receiving insider information on tenders", "Public contracts, preferential treatment"),
            ("Revolving door violations", "Hiring former officials without cooling-off period", "Regulatory agencies, government departments"),
        ],
        "prevention": [
            "Lobbying registration and disclosure",
            "Public official interaction logging",
            "Strict hospitality limits for officials",
            "Public tender ethics guidelines",
            "Former public official hiring policy",
        ]
    }
}

# Generate coherent prevention measures
def get_prevention_measures(category, count=4):
    measures = RISK_SCENARIOS[category]["prevention"]
    selected = random.sample(measures, min(count, len(measures)))
    return "• " + "\n• ".join(selected)

# Generate corrective actions based on residual risk
def get_corrective_action(prob_res, impact_res):
    if prob_res * impact_res >= 12:
        return random.choice([
            "Immediate action required: Implement additional controls within 30 days",
            "Escalate to Compliance Committee for enhanced monitoring",
            "Deploy independent third-party audit within Q1",
            "Mandatory training for all personnel + enhanced supervision"
        ])
    elif prob_res * impact_res >= 8:
        return random.choice([
            "Reinforce existing controls with quarterly review",
            "Implement secondary verification process",
            "Conduct targeted awareness training",
            "Strengthen approval workflow with additional checkpoint"
        ])
    elif prob_res * impact_res >= 4:
        return random.choice([
            "Monitor through regular compliance reporting",
            "Include in annual internal audit scope",
            "Refresh training materials and communication",
            "Update procedure documentation"
        ])
    else:
        return random.choice([
            "Maintain current controls with periodic review",
            "Continue standard monitoring activities",
            "No immediate action required - annual review",
            "Risk accepted within tolerance level"
        ])

# Risk level based on score
def get_risk_level(score):
    if score >= 12:
        return "🔴 Critical"
    elif score >= 8:
        return "🟠 High"
    elif score >= 4:
        return "🟡 Moderate"
    else:
        return "🟢 Low"

# Generate entity-specific risk profile
def generate_entity_data(entity_name, entity_idx):
    """Generate risk data for one entity with realistic distribution."""
    
    random.seed(entity_idx + 42)  # Reproducible but varied per entity
    
    risks = []
    
    # Define entity risk profile (some entities have higher risk in certain areas)
    entity_profiles = {
        0: {"high_risk": ["A", "C"], "low_risk": ["S"]},      # HQ - procurement & sales focus
        1: {"high_risk": ["C", "P"], "low_risk": ["M"]},      # Europe - regulatory focus
        2: {"high_risk": ["C", "F"], "low_risk": ["R"]},      # NA - finance & sales
        3: {"high_risk": ["A", "P"], "low_risk": ["F"]},      # APAC - public officials
        4: {"high_risk": ["A", "R"], "low_risk": ["S"]},      # Manufacturing - supply chain
        5: {"high_risk": ["R", "M"], "low_risk": ["C"]},      # R&D - acquisitions & HR
        6: {"high_risk": ["F", "M"], "low_risk": ["A"]},      # Finance - financial risks
        7: {"high_risk": ["A", "C"], "low_risk": ["P"]},      # Supply Chain
    }
    
    profile = entity_profiles.get(entity_idx, {"high_risk": [], "low_risk": []})
    
    # Generate 32 risks across categories
    for cat_code, cat_data in RISK_SCENARIOS.items():
        scenarios = cat_data["scenarios"]
        cat_name = cat_data["name"]
        
        for i, (scenario, description, factors) in enumerate(scenarios):
            risk_id = f"{cat_code}{i+1}"
            
            # Adjust probability based on entity profile
            base_prob = random.randint(1, 4)
            if cat_code in profile["high_risk"]:
                base_prob = min(4, base_prob + 1)
            elif cat_code in profile["low_risk"]:
                base_prob = max(1, base_prob - 1)
            
            # Inherent risk (gross)
            prob_gross = base_prob
            impact_gross = random.randint(1, 4)
            score_gross = prob_gross * impact_gross
            level_gross = get_risk_level(score_gross)
            
            # Residual risk (net) - should generally be lower due to controls
            control_effectiveness = random.uniform(0.2, 0.7)  # 20-70% reduction
            prob_res = max(1, int(prob_gross * (1 - control_effectiveness * random.uniform(0.3, 1.0))))
            impact_res = max(1, int(impact_gross * (1 - control_effectiveness * random.uniform(0.2, 0.8))))
            score_res = prob_res * impact_res
            level_res = get_risk_level(score_res)
            
            prevention = get_prevention_measures(cat_code)
            corrective = get_corrective_action(prob_res, impact_res)
            
            risks.append({
                "risk_id": risk_id,
                "process": cat_name,
                "scenario": scenario,
                "description": description,
                "factors": factors,
                "prob_gross": prob_gross,
                "impact_gross": impact_gross,
                "score_gross": score_gross,
                "level_gross": level_gross,
                "prevention": prevention,
                "prob_res": prob_res,
                "impact_res": impact_res,
                "score_res": score_res,
                "level_res": level_res,
                "corrective": corrective
            })
    
    return risks

def create_excel_file(entity_name, risks, output_path):
    """Create Excel file with proper formatting."""
    
    # Create DataFrame
    df = pd.DataFrame(risks)
    df.columns = [
        'N°', 'Process', 'Corruption Scenario', 'Risk Description', 'Aggravating Factors',
        'Probability\n(1-4)', 'Impact\n(1-4)', 'Score\nbrut', 'Niveau\nbrut',
        'Existing Prevention Measures',
        'Probability\nréelle (1-4)', 'Impact\nréel (1-4)', 'Score\nréel', 'Niveau\nréel',
        'Corrective Actions / Gap'
    ]
    
    # Create Excel with header rows
    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        # Write header info
        header_df = pd.DataFrame([
            ['RISK CARTOGRAPHY - CORRUPTION', '', '', '', ''],
            ['LOI SAPIN 2, ARTICLE 17', '', '', '', ''],
            ['', '', '', '', ''],
        ])
        header_df.to_excel(writer, sheet_name='All', index=False, header=False, startrow=0)
        
        # Write data with headers
        df.to_excel(writer, sheet_name='All', index=False, startrow=3)
    
    print(f"  ✓ Created: {output_path.name}")

def main():
    print("=" * 60)
    print("  Generating Demo Data for Risk Cartography")
    print("=" * 60)
    print()
    
    # Generate files for each entity
    print(f"📁 Output directory: {OUTPUT_DIR}")
    print()
    
    for idx, entity in enumerate(ENTITIES):
        filename = f"risk_cartography_{entity}.xlsx"
        output_path = OUTPUT_DIR / filename
        
        risks = generate_entity_data(entity, idx)
        create_excel_file(entity, risks, output_path)
    
    print()
    print("=" * 60)
    print(f"  ✅ Generated {len(ENTITIES)} Excel files")
    print("=" * 60)
    
    # Summary statistics
    print()
    print("📊 Summary:")
    print(f"  - Files: {len(ENTITIES)}")
    print(f"  - Risks per file: 35 (7 categories × 5 scenarios)")
    print(f"  - Total risks: {len(ENTITIES) * 35}")
    print(f"  - Categories: A, C, R, F, M, S, P")
    print()
    print(f"📂 Files saved to: {OUTPUT_DIR}")

if __name__ == "__main__":
    main()
