@echo off
setlocal enabledelayedexpansion
title Risk Cartography - AFA/Sapin II Compliance

echo.
echo ====================================================================
echo        RISK CARTOGRAPHY - AFA/Sapin II Compliance Tool
echo                        Version 1.0.0
echo ====================================================================
echo.

:: Get script directory
cd /d "%~dp0"

:: Check for Python
echo [1/5] Checking Python installation...
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo ====================================================================
    echo   ERROR: Python is not installed or not in PATH
    echo ====================================================================
    echo.
    echo   HOW TO INSTALL PYTHON:
    echo.
    echo   1. Open your browser and go to:
    echo      https://www.python.org/downloads/
    echo.
    echo   2. Click the big yellow "Download Python 3.12" button
    echo.
    echo   3. Run the downloaded installer
    echo.
    echo   4. VERY IMPORTANT: Check the box at the bottom that says:
    echo      [X] Add Python to PATH
    echo.
    echo   5. Click "Install Now"
    echo.
    echo   6. Restart your computer
    echo.
    echo   7. Double-click this file again
    echo.
    echo ====================================================================
    echo.
    echo Opening Python download page...
    start https://www.python.org/downloads/
    pause
    exit /b 1
)

:: Check Python version
for /f "tokens=2" %%i in ('python --version 2^>^&1') do set PYVER=%%i
echo       Found Python %PYVER%

:: Check/create virtual environment
echo [2/5] Setting up virtual environment...
if not exist "venv" (
    echo       Creating virtual environment...
    python -m venv venv
    if %errorlevel% neq 0 (
        echo       Warning: Could not create venv, using global Python
    )
)

:: Activate virtual environment
if exist "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
    echo       Virtual environment activated
)

:: Upgrade pip first
echo [3/5] Upgrading pip...
python -m pip install --upgrade pip >nul 2>&1

:: Install dependencies from requirements.txt
echo [4/5] Installing dependencies from requirements.txt...
python -m pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo       Trying individual packages...
    python -m pip install streamlit pandas openpyxl
    if %errorlevel% neq 0 (
        echo       Trying with --user flag...
        python -m pip install --user streamlit pandas openpyxl
        if %errorlevel% neq 0 (
            echo.
            echo ====================================================================
            echo   ERROR: Failed to install dependencies
            echo.
            echo   Please run manually in Command Prompt:
            echo   python -m pip install streamlit pandas openpyxl
            echo ====================================================================
            echo.
            pause
            exit /b 1
        )
    )
)
echo       Dependencies installed successfully

:: Start application using python -m streamlit (more reliable)
echo [5/5] Starting application...
echo.
echo ====================================================================
echo   Application starting...
echo.
echo   Your browser will open automatically at:
echo   http://localhost:8501
echo.
echo   Press Ctrl+C to stop the application
echo ====================================================================
echo.

:: Launch streamlit via python -m (works even if not in PATH)
python -m streamlit run app.py --server.port 8501 --browser.gatherUsageStats false

:: Cleanup
if exist "venv\Scripts\deactivate.bat" (
    call venv\Scripts\deactivate.bat
)

pause
