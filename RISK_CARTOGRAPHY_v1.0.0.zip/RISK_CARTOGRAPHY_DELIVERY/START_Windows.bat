@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
title Risk Cartography - AFA/Sapin II Compliance

echo.
echo ╔══════════════════════════════════════════════════════════════════╗
echo ║        RISK CARTOGRAPHY - AFA/Sapin II Compliance Tool          ║
echo ║                        Version 1.0.0                             ║
echo ╚══════════════════════════════════════════════════════════════════╝
echo.

:: Check for Python
echo [1/4] Checking Python installation...
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo ╔══════════════════════════════════════════════════════════════════╗
    echo ║  ERROR: Python is not installed or not in PATH                  ║
    echo ║                                                                  ║
    echo ║  Please install Python 3.8 or higher:                           ║
    echo ║  https://www.python.org/downloads/                              ║
    echo ║                                                                  ║
    echo ║  IMPORTANT: Check "Add Python to PATH" during installation!    ║
    echo ╚══════════════════════════════════════════════════════════════════╝
    echo.
    pause
    exit /b 1
)

:: Check Python version
for /f "tokens=2" %%i in ('python --version 2^>^&1') do set PYVER=%%i
echo       Found Python %PYVER%

:: Check/create virtual environment
echo [2/4] Setting up virtual environment...
if not exist "venv" (
    echo       Creating virtual environment...
    python -m venv venv
    if %errorlevel% neq 0 (
        echo       Warning: Could not create venv, using global Python
    )
)

:: Activate virtual environment
if exist "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
    echo       Virtual environment activated
)

:: Install dependencies
echo [3/4] Installing dependencies...
pip install -q streamlit pandas openpyxl 2>nul
if %errorlevel% neq 0 (
    echo       Warning: Some packages may have failed to install
    echo       Trying with --user flag...
    pip install --user -q streamlit pandas openpyxl 2>nul
)

:: Check if streamlit is available
where streamlit >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo ╔══════════════════════════════════════════════════════════════════╗
    echo ║  ERROR: Streamlit installation failed                           ║
    echo ║                                                                  ║
    echo ║  Please run manually:                                           ║
    echo ║  pip install streamlit pandas openpyxl                          ║
    echo ╚══════════════════════════════════════════════════════════════════╝
    echo.
    pause
    exit /b 1
)

:: Start application
echo [4/4] Starting application...
echo.
echo ╔══════════════════════════════════════════════════════════════════╗
echo ║  Application starting...                                         ║
echo ║                                                                  ║
echo ║  Your browser will open automatically at:                       ║
echo ║  http://localhost:8501                                          ║
echo ║                                                                  ║
echo ║  Press Ctrl+C to stop the application                           ║
echo ╚══════════════════════════════════════════════════════════════════╝
echo.

:: Launch streamlit
streamlit run app.py --server.port 8501 --browser.gatherUsageStats false

:: Cleanup
if exist "venv\Scripts\deactivate.bat" (
    call venv\Scripts\deactivate.bat
)

pause
