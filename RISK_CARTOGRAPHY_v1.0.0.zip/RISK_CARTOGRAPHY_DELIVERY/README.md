# Risk Cartography - AFA/Sapin II Compliance Tool

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-proprietary-red.svg)]()

**Version 1.0.0** | *Professional Risk Analysis Solution*

---

## ⚠️ PREREQUISITE: Python Installation

**Python is required to run this application.** If not already installed:

### Windows (5 minutes)
1. Go to **https://www.python.org/downloads/**
2. Click **"Download Python 3.12"** (or latest version)
3. Run the installer
4. ✅ **IMPORTANT: Check "Add Python to PATH"** at the bottom of the installer
5. Click "Install Now"
6. Restart your computer

### Mac
```bash
# Using Homebrew (recommended)
brew install python3

# Or download from https://www.python.org/downloads/
```

### Linux (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv
```

### Verify Installation
Open a terminal/command prompt and type:
```bash
python --version
```
You should see `Python 3.x.x`

---

## 📋 Overview

Risk Cartography is a professional-grade risk analysis tool designed for **AFA/Sapin II compliance** assessment. It provides:

- 🎯 **15 configurable risk dimensions** with customizable weights
- 📊 **Interactive HTML dashboards** with real-time charts
- 📈 **PowerBI-ready exports** for enterprise reporting
- ⚙️ **Admin interface** for complete customization without coding

---

## 🚀 Quick Start

### Windows
```
Double-click START_Windows.bat
```

### Linux / macOS
```bash
chmod +x START_Linux_Mac.sh
./START_Linux_Mac.sh
```

The application will open automatically in your browser at **http://localhost:8501**

---

## 📁 Folder Structure

```
RISK_CARTOGRAPHY_DELIVERY/
├── app.py                    # Main application
├── requirements.txt          # Python dependencies
├── START_Windows.bat         # Windows launcher
├── START_Linux_Mac.sh        # Linux/Mac launcher
├── lib/                      # Core modules
│   ├── main.py              # Analysis orchestrator
│   ├── analyzer.py          # Risk calculations
│   ├── data_loader.py       # Excel reader
│   ├── html_generator.py    # Dashboard generator
│   ├── exporters.py         # PowerBI/Excel export
│   └── config_loader.py     # Configuration manager
├── config/                   # Configuration files
│   ├── analysis_config.json # Master config (auto-generated)
│   ├── column_mapping.json  # Column definitions
│   ├── column_order.json    # Display order
│   ├── categories.json      # Risk categories
│   ├── risk_levels.json     # Risk level definitions
│   └── formulas.json        # Calculation formulas
├── input/                    # Place your Excel files here
├── output/                   # Generated reports go here
├── samples/                  # Sample data files
│   └── sample_entity.xlsx   # Example input file
└── docs/                     # Documentation
    ├── TROUBLESHOOTING.md   # Common issues & solutions
    └── QUICK_START.md       # Quick reference guide
```

---

## 💻 System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| Python | 3.6 | 3.10+ |
| RAM | 4 GB | 8 GB |
| Disk | 100 MB | 500 MB |
| Browser | Chrome, Firefox, Edge | Chrome |

---

## 📖 User Guide

### Application Modes

The application has **3 modes** accessible from the sidebar:

1. **🎯 Executor Mode** - Run risk analysis on your data
2. **⚙️ Admin Mode** - Configure columns, categories, formulas
3. **📖 Wiki Mode** - Built-in documentation

### Running an Analysis

1. Place your Excel file in the `input/` folder
2. Launch the application
3. In **Executor Mode**, select your file from the dropdown
4. Click **🚀 Run Analysis**
5. View dashboards and download reports from `output/`

### Admin Configuration

In **Admin Mode**, you can configure:

- **Column Mapping**: Add, remove, reorder columns with ⬆️⬇️ buttons
- **Risk Categories**: Define AFA/Sapin II compliance categories
- **Risk Levels**: Customize risk scoring (High/Medium/Low)
- **Formulas**: Configure automatic calculations

---

## 🔧 Manual Installation

If the automatic scripts don't work:

```bash
# 1. Create virtual environment
python -m venv venv

# 2. Activate it
# Windows:   venv\Scripts\activate
# Linux/Mac: source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run
streamlit run app.py
```

---

## 📊 Output Files

After analysis, the `output/` folder contains:

| File | Description |
|------|-------------|
| `dashboard_ENTITY.html` | Interactive HTML dashboard with charts |
| `powerbi_ENTITY.json` | PowerBI-ready JSON export |
| `analysis_results.xlsx` | Detailed Excel results |
| `risk_summary.csv` | CSV summary for external tools |

---

## ⚠️ Troubleshooting

### "Python not found"
Install Python 3.8+ from [python.org](https://www.python.org/downloads/)  
Windows: Check "Add Python to PATH" during installation

### "streamlit: command not found"
```bash
pip install --user streamlit
# Then add to PATH: export PATH="$HOME/.local/bin:$PATH"
```

### "Permission denied" on Linux/Mac
```bash
chmod +x START_Linux_Mac.sh
```

### Port 8501 already in use
```bash
streamlit run app.py --server.port 8502
```

See `docs/TROUBLESHOOTING.md` for more solutions.

---

## 📧 Support

For technical support or feature requests, contact your account manager.

---

*© 2024 - All Rights Reserved*
