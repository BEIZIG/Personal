#!/bin/bash
#═══════════════════════════════════════════════════════════════════════
#  RISK CARTOGRAPHY - AFA/Sapin II Compliance Tool
#  Version 1.0.0
#═══════════════════════════════════════════════════════════════════════

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║        RISK CARTOGRAPHY - AFA/Sapin II Compliance Tool          ║"
echo "║                        Version 1.0.0                             ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Check for Python
echo -e "${BLUE}[1/4]${NC} Checking Python installation..."

# Try python3 first, then python
PYTHON_CMD=""
if command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
else
    echo ""
    echo -e "${RED}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${RED}║  ERROR: Python is not installed                                  ║${NC}"
    echo -e "${RED}║                                                                  ║${NC}"
    echo -e "${RED}║  Please install Python 3.8 or higher:                           ║${NC}"
    echo -e "${RED}║  - macOS: brew install python3                                  ║${NC}"
    echo -e "${RED}║  - Ubuntu/Debian: sudo apt install python3 python3-pip         ║${NC}"
    echo -e "${RED}║  - RHEL/CentOS: sudo yum install python3 python3-pip           ║${NC}"
    echo -e "${RED}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    exit 1
fi

# Check Python version
PYVER=$($PYTHON_CMD --version 2>&1 | awk '{print $2}')
echo -e "      Found Python ${GREEN}$PYVER${NC}"

# Verify version is >= 3.6
MAJOR=$($PYTHON_CMD -c "import sys; print(sys.version_info.major)")
MINOR=$($PYTHON_CMD -c "import sys; print(sys.version_info.minor)")
if [ "$MAJOR" -lt 3 ] || { [ "$MAJOR" -eq 3 ] && [ "$MINOR" -lt 6 ]; }; then
    echo -e "${RED}ERROR: Python 3.6+ required. Found $MAJOR.$MINOR${NC}"
    exit 1
fi

# Check/create virtual environment
echo -e "${BLUE}[2/4]${NC} Setting up virtual environment..."
if [ ! -d "venv" ]; then
    echo "      Creating virtual environment..."
    $PYTHON_CMD -m venv venv 2>/dev/null || {
        echo -e "${YELLOW}      Warning: Could not create venv, using global Python${NC}"
    }
fi

# Activate virtual environment
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
    echo -e "      Virtual environment ${GREEN}activated${NC}"
    PIP_CMD="pip"
else
    PIP_CMD="$PYTHON_CMD -m pip"
fi

# Install dependencies
echo -e "${BLUE}[3/4]${NC} Installing dependencies..."
$PIP_CMD install -q streamlit pandas openpyxl 2>/dev/null || {
    echo "      Trying with --user flag..."
    $PIP_CMD install --user -q streamlit pandas openpyxl 2>/dev/null || {
        echo -e "${RED}ERROR: Failed to install dependencies${NC}"
        echo "Please run: pip install streamlit pandas openpyxl"
        exit 1
    }
}

# Check if streamlit is available
if ! command -v streamlit &> /dev/null; then
    # Try to find it in user path
    export PATH="$HOME/.local/bin:$PATH"
fi

if ! command -v streamlit &> /dev/null; then
    echo -e "${RED}ERROR: Streamlit not found. Please install manually:${NC}"
    echo "pip install streamlit pandas openpyxl"
    exit 1
fi

# Start application
echo -e "${BLUE}[4/4]${NC} Starting application..."
echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║  Application starting...                                         ║"
echo "║                                                                  ║"
echo "║  Open your browser at:                                          ║"
echo -e "║  ${GREEN}http://localhost:8501${NC}                                          ║"
echo "║                                                                  ║"
echo "║  Press Ctrl+C to stop the application                           ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""

# Launch streamlit
streamlit run app.py --server.port 8501 --browser.gatherUsageStats false

# Cleanup on exit
if [ -f "venv/bin/deactivate" ]; then
    deactivate 2>/dev/null || true
fi
