# Troubleshooting Guide

## Common Issues & Solutions

---

## 🐍 Python Issues

### "Python is not installed" / "Python not found"

**Windows:**
1. Download Python from https://www.python.org/downloads/
2. Run the installer
3. ✅ **IMPORTANT: Check "Add Python to PATH"** during installation
4. Restart your computer
5. Verify: Open Command Prompt and type `python --version`

**macOS:**
```bash
# Using Homebrew (recommended)
brew install python3

# Or download from python.org
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv
```

**Linux (RHEL/CentOS):**
```bash
sudo yum install python3 python3-pip
```

---

## 📦 Dependency Issues

### "No module named streamlit/pandas/openpyxl"

```bash
# Method 1: Standard installation
pip install streamlit pandas openpyxl

# Method 2: User installation (no admin rights)
pip install --user streamlit pandas openpyxl

# Method 3: Using python -m pip
python -m pip install streamlit pandas openpyxl
```

### "pip: command not found"

```bash
# Windows
python -m ensurepip --upgrade

# Linux/Mac
python3 -m ensurepip --upgrade
# or
sudo apt install python3-pip   # Ubuntu/Debian
```

### Installation behind corporate proxy

```bash
pip install --proxy http://your-proxy:port streamlit pandas openpyxl
```

---

## 🚀 Application Won't Start

### "streamlit: command not found"

The streamlit executable is not in your PATH.

**Solution 1: Add to PATH**
```bash
# Linux/Mac
export PATH="$HOME/.local/bin:$PATH"

# Windows (add to System Environment Variables)
%APPDATA%\Python\Python3X\Scripts
```

**Solution 2: Run directly**
```bash
python -m streamlit run app.py
```

### "Address already in use" / Port 8501 busy

Another application is using port 8501.

```bash
# Use a different port
streamlit run app.py --server.port 8502

# Or find and kill the process using 8501
# Linux/Mac:
lsof -i :8501
kill -9 <PID>

# Windows:
netstat -ano | findstr :8501
taskkill /PID <PID> /F
```

### Application freezes / "Watching for changes..."

This is normal. The application is running!  
Open your browser to: **http://localhost:8501**

If it doesn't open automatically:
1. Open your browser manually
2. Go to: http://localhost:8501

---

## 📄 File Issues

### "No Excel files found in input folder"

1. Ensure your Excel file is in the `input/` folder
2. File must have `.xlsx` extension (not `.xls`)
3. File must not be open in Excel while running analysis

### "Column not found" errors

Your Excel file columns don't match the configuration.

1. Go to **Admin Mode** → **Column Mapping**
2. Verify column names match your Excel file headers
3. Or modify config/column_mapping.json

### Excel file is corrupted / can't read

```bash
pip install --upgrade openpyxl
```

If still failing, try re-saving the Excel file with a simple name (no special characters).

---

## 🖥️ Permission Issues

### "Permission denied" (Linux/Mac)

```bash
chmod +x START_Linux_Mac.sh
./START_Linux_Mac.sh
```

If `chmod` fails:
```bash
bash START_Linux_Mac.sh
```

### Cannot write to output folder

Check folder permissions:
```bash
# Linux/Mac
chmod -R 755 output/

# Or run with sudo (not recommended)
sudo ./START_Linux_Mac.sh
```

---

## 🌐 Browser Issues

### Blank page / Nothing displays

1. Try a different browser (Chrome recommended)
2. Clear browser cache: `Ctrl+Shift+Delete`
3. Try incognito/private mode
4. Check if JavaScript is enabled

### Charts not displaying

Requires internet connection for Chart.js CDN.  
On restricted networks, dashboards may not display charts.

---

## 💾 Memory Issues

### "MemoryError" / Application crashes with large files

For Excel files > 100MB:

1. Split into smaller files
2. Increase Python memory:
   ```bash
   # Linux/Mac
   export PYTHONMEM=2048m
   
   # Windows
   set PYTHONMEM=2048m
   ```

---

## 🔄 Reset to Default

If configuration is corrupted:

1. Delete the `config/` folder
2. Re-extract from the original ZIP file
3. Or copy from `samples/default_config/` if available

---

## 📧 Contact Support

If issues persist after trying these solutions:

1. Take a screenshot of the error
2. Note your Python version: `python --version`
3. Note your OS version
4. Contact your account manager

---

*Last updated: 2024*
