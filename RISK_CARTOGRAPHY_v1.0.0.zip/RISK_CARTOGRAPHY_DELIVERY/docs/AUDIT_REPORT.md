# AUDIT REPORT
## Risk Cartography Solution - AFA/Sapin II Compliance Tool
### Version 1.0.0

---

**Date:** April 11, 2026  
**Auditor:** Internal Control & Risk Management  
**Classification:** Internal Use Only  

---

## 1. EXECUTIVE SUMMARY

### 1.1 Audit Scope
Review of the Risk Cartography solution designed to automate corruption risk mapping in compliance with AFA (Agence Française Anticorruption) guidelines and Sapin II Article 17 requirements.

### 1.2 Overall Assessment

| Domain | Rating | Status |
|--------|--------|--------|
| Regulatory Compliance | ⭐⭐⭐⭐ | **Satisfactory** |
| Methodology | ⭐⭐⭐⭐ | **Satisfactory** |
| Data Integrity | ⭐⭐⭐ | **Needs Improvement** |
| Security Controls | ⭐⭐ | **Insufficient** |
| Audit Trail | ⭐⭐ | **Insufficient** |
| Documentation | ⭐⭐⭐⭐ | **Satisfactory** |

### 1.3 Key Findings Summary

| Priority | Finding | Recommendation |
|----------|---------|----------------|
| 🔴 HIGH | No authentication/authorization | Implement user access control |
| 🔴 HIGH | No audit trail logging | Add comprehensive logging |
| 🟠 MEDIUM | No data validation at input | Add Excel schema validation |
| 🟠 MEDIUM | No backup mechanism | Implement auto-backup |
| 🟡 LOW | No version control on configs | Add config versioning |
| 🟡 LOW | Limited error messages | Improve error diagnostics |

---

## 2. REGULATORY COMPLIANCE ANALYSIS

### 2.1 Sapin II Article 17 - 8 Pillars Coverage

| Pillar | Requirement | Solution Coverage | Gap |
|--------|-------------|-------------------|-----|
| 1️⃣ **Risk Mapping** | Document corruption risks | ✅ Full P×I scoring matrix | None |
| 2️⃣ **Code of Conduct** | Link risks to policies | ⚠️ Partial (via categories) | Add policy reference field |
| 3️⃣ **Whistleblowing** | Alert mechanisms | ❌ Not covered | Out of scope |
| 4️⃣ **Third-Party Evaluation** | Supplier risk assessment | ⚠️ Partial (Procurement category) | Add third-party rating |
| 5️⃣ **Accounting Controls** | Financial risk tracking | ✅ Finance category supported | None |
| 6️⃣ **Training** | Risk awareness | ⚠️ Wiki documentation only | Add training tracking |
| 7️⃣ **Disciplinary Sanctions** | Consequence framework | ❌ Not covered | Out of scope |
| 8️⃣ **Internal Control** | Control effectiveness | ✅ Mitigation rate calculated | None |

**Compliance Score: 62.5%** (5/8 pillars fully or partially addressed)

### 2.2 AFA Methodology Alignment

| AFA Requirement | Implementation | Conformity |
|-----------------|----------------|------------|
| Probability scale (1-4) | ✅ Configurable | Compliant |
| Impact scale (1-4) | ✅ Configurable | Compliant |
| Risk Score = P × I | ✅ Formula documented | Compliant |
| Gross vs Residual risk | ✅ Both captured | Compliant |
| Risk categories by process | ✅ 7 default categories | Compliant |
| Control effectiveness | ✅ Reduction % calculated | Compliant |
| Regular review cycle | ❌ No scheduling | **Gap** |

---

## 3. METHODOLOGY REVIEW

### 3.1 Risk Scoring Model

**Current Implementation:**
```
Risk Score = Probability × Impact (1-16 scale)

Level Classification:
- Critical: 12-16 (3×4, 4×3, 4×4)
- High: 8-9 (2×4, 4×2, 3×3)
- Moderate: 4-6 (1×4, 2×2, 2×3, 3×2, 4×1, 1×5, 1×6)
- Low: 1-3 (1×1, 1×2, 2×1, 1×3, 3×1)
```

**Assessment:** ✅ Compliant with AFA 4×4 matrix standard

**Observation:** Score 10 and 11 are not mapped (e.g., 2×5 impossible with 1-4 scale). Configuration is mathematically consistent.

### 3.2 Risk Categories

| Code | Category | AFA Alignment |
|------|----------|---------------|
| A | Procurement | ✅ Standard |
| B | Commercial/Sales | ✅ Standard |
| C | Human Resources | ✅ Standard |
| D | Finance | ✅ Standard |
| E | M&A / Joint Ventures | ✅ Standard |
| F | Sponsoring/Donations | ✅ Standard |
| G | Public Officials | ✅ Standard |

**Assessment:** ✅ All 7 standard AFA corruption risk categories covered

### 3.3 Mitigation Analysis

**Metrics Calculated:**
- Risk Reduction % = ((Gross - Residual) / Gross) × 100
- Mitigation Rate = (Improved Risks / Total Risks) × 100
- Urgency Score = Σ(Critical×4 + High×2 + Moderate×1)

**Assessment:** ✅ Standard control effectiveness measurements

---

## 4. DATA INTEGRITY CONTROLS

### 4.1 Input Validation

| Control | Status | Finding |
|---------|--------|---------|
| Excel file format check | ✅ | .xlsx only accepted |
| Column presence validation | ⚠️ | Silent fallback, no error |
| Numeric range validation | ⚠️ | No check for P/I in 1-4 |
| Required field validation | ❌ | Missing values accepted |
| Duplicate risk ID check | ❌ | Duplicates not detected |

**Risk:** Medium - Invalid data may produce incorrect dashboards

**Recommendation:**
```python
# Add validation in data_loader.py
def validate_risk_data(df):
    errors = []
    
    # Check probability range
    invalid_prob = df[~df['prob_gross'].between(1, 4)]
    if not invalid_prob.empty:
        errors.append(f"Invalid probability values: {invalid_prob['risk_id'].tolist()}")
    
    # Check for duplicates
    duplicates = df[df['risk_id'].duplicated()]
    if not duplicates.empty:
        errors.append(f"Duplicate risk IDs: {duplicates['risk_id'].tolist()}")
    
    return errors
```

### 4.2 Output Integrity

| Control | Status | Finding |
|---------|--------|---------|
| Calculation verification | ✅ | Score = P × I verified |
| Dashboard/PowerBI consistency | ✅ | Same data source |
| Export checksum | ❌ | No integrity hash |
| Output file overwrite protection | ❌ | Previous files overwritten |

---

## 5. SECURITY ASSESSMENT

### 5.1 Access Control

| Control | Status | Risk Level |
|---------|--------|------------|
| User authentication | ❌ None | 🔴 HIGH |
| Role-based authorization | ❌ None | 🔴 HIGH |
| Admin mode protection | ❌ None | 🔴 HIGH |
| Configuration change control | ❌ None | 🟠 MEDIUM |

**Finding:** Any user can access Admin mode and modify:
- Risk categories
- Scoring thresholds
- Column mappings
- Formulas

**Impact:** Unauthorized configuration changes could manipulate risk assessments

**Recommendation:** Implement authentication layer:
```python
# Add in app.py
def check_admin_access():
    password = st.text_input("Admin Password", type="password")
    if password != os.environ.get('ADMIN_PASSWORD', 'admin123'):
        st.error("Invalid password")
        st.stop()
```

### 5.2 Data Protection

| Control | Status | Risk Level |
|---------|--------|------------|
| Data encryption at rest | ❌ None | 🟠 MEDIUM |
| Data encryption in transit | ⚠️ HTTP only | 🟠 MEDIUM |
| Sensitive data masking | ❌ None | 🟡 LOW |
| Data retention policy | ❌ None | 🟡 LOW |

---

## 6. AUDIT TRAIL ANALYSIS

### 6.1 Current State

| Log Type | Implemented | Finding |
|----------|-------------|---------|
| Analysis execution log | ⚠️ Console only | Not persisted |
| Configuration changes | ❌ None | No history |
| User actions | ❌ None | No tracking |
| Error logs | ⚠️ Partial | Not structured |
| Data modifications | ❌ None | No versioning |

**Finding:** No audit trail exists for regulatory inspection

**AFA Requirement:** "Documentary evidence of risk mapping updates"

### 6.2 Recommended Audit Log Structure

```json
{
  "timestamp": "2026-04-11T10:30:00Z",
  "action": "ANALYSIS_RUN",
  "user": "system",
  "details": {
    "input_files": ["entity1.xlsx", "entity2.xlsx"],
    "risks_analyzed": 256,
    "critical_count": 12,
    "high_count": 45
  },
  "checksum": "sha256:abc123..."
}
```

**Recommendation:** Add `audit_logger.py` module:
```python
import json
from datetime import datetime
from pathlib import Path

class AuditLogger:
    def __init__(self, log_dir: Path):
        self.log_file = log_dir / f"audit_{datetime.now():%Y%m}.json"
    
    def log(self, action: str, details: dict):
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "action": action,
            "details": details
        }
        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry) + '\n')
```

---

## 7. ARCHITECTURE REVIEW

### 7.1 Component Analysis

```
┌─────────────────────────────────────────────────────────────────┐
│                      PRESENTATION LAYER                          │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  app.py (Streamlit)                                       │   │
│  │  - UI rendering                                           │   │
│  │  - User interaction                                       │   │
│  │  - Session state management                               │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                       BUSINESS LAYER                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │ analyzer.py │  │data_loader.py│  │config_loader│             │
│  │ Risk calcs  │  │ Excel I/O    │  │ JSON I/O    │             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                        OUTPUT LAYER                              │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │html_generator│  │ exporters   │  │ main.py     │             │
│  │ Dashboards  │  │ CSV/Excel   │  │ Orchestration│             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
└─────────────────────────────────────────────────────────────────┘
```

### 7.2 Strengths

| Aspect | Assessment |
|--------|------------|
| Modularity | ✅ Each module independent |
| Configuration-driven | ✅ JSON-based settings |
| No database dependency | ✅ File-based, portable |
| Cross-platform | ✅ Windows/Mac/Linux |

### 7.3 Weaknesses

| Aspect | Assessment | Improvement |
|--------|------------|-------------|
| Single-user | ❌ No concurrency | Add file locking |
| No caching | ❌ Recalculates each run | Add result caching |
| Monolithic app.py | ⚠️ 1000+ lines | Split into modules |
| No testing | ❌ No unit tests | Add pytest suite |

---

## 8. IMPROVEMENT ROADMAP

### Phase 1: Critical Security (Week 1-2)

| Task | Priority | Effort |
|------|----------|--------|
| Add Admin password protection | 🔴 HIGH | 2h |
| Implement audit logging | 🔴 HIGH | 4h |
| Add input data validation | 🟠 MEDIUM | 4h |

### Phase 2: Data Quality (Week 3-4)

| Task | Priority | Effort |
|------|----------|--------|
| Excel schema validation | 🟠 MEDIUM | 4h |
| Duplicate detection | 🟠 MEDIUM | 2h |
| Score range validation (1-4) | 🟠 MEDIUM | 2h |
| Add data quality report | 🟡 LOW | 4h |

### Phase 3: Compliance (Week 5-6)

| Task | Priority | Effort |
|------|----------|--------|
| Add policy reference field | 🟡 LOW | 2h |
| Add third-party risk rating | 🟡 LOW | 4h |
| Add review schedule tracking | 🟡 LOW | 4h |
| Export audit package (PDF) | 🟡 LOW | 8h |

### Phase 4: Enterprise (Future)

| Task | Priority | Effort |
|------|----------|--------|
| Multi-user with LDAP auth | 🟡 LOW | 2 weeks |
| Database backend (PostgreSQL) | 🟡 LOW | 2 weeks |
| REST API for integration | 🟡 LOW | 1 week |
| Unit test coverage >80% | 🟡 LOW | 1 week |

---

## 9. RECOMMENDATIONS SUMMARY

### 9.1 Immediate Actions (Before Production)

1. **Add Admin Password Protection**
   - Environment variable: `ADMIN_PASSWORD`
   - Hash storage, not plaintext

2. **Enable Audit Logging**
   - Log all analysis runs
   - Log configuration changes
   - Persist to `logs/audit_YYYYMM.json`

3. **Add Input Validation**
   - Probability/Impact must be 1-4
   - Risk ID must be unique
   - Required fields must not be empty

### 9.2 Short-Term (1-3 months)

4. **Config Version Control**
   - Save config snapshots with timestamp
   - Allow rollback to previous version

5. **Automated Backup**
   - Before each analysis, backup input files
   - Archive old outputs

6. **Enhanced Error Reporting**
   - User-friendly error messages
   - Actionable fix suggestions

### 9.3 Medium-Term (3-6 months)

7. **Compliance Package Export**
   - One-click AFA audit package
   - Include: Dashboard, Data, Config, Audit Log

8. **Multi-Entity Comparison**
   - Benchmark entities against each other
   - Highlight outliers

9. **Trend Analysis**
   - Track risk evolution over time
   - Quarter-over-quarter comparison

---

## 10. CONCLUSION

### 10.1 Fitness for Purpose

The Risk Cartography solution **meets the core functional requirements** for AFA/Sapin II risk mapping:
- ✅ Standard 4×4 risk matrix
- ✅ Gross/Residual risk tracking
- ✅ 7 standard corruption categories
- ✅ Control effectiveness measurement
- ✅ Interactive dashboards & PowerBI export

### 10.2 Readiness Assessment

| Scenario | Ready? | Notes |
|----------|--------|-------|
| Internal demo/POC | ✅ Yes | Current state sufficient |
| Department pilot | ⚠️ Conditional | Needs audit logging |
| Enterprise production | ❌ No | Needs authentication + logging |
| AFA inspection | ⚠️ Conditional | Needs audit trail + export |

### 10.3 Sign-Off

| Recommendation | Decision Required |
|----------------|-------------------|
| Deploy for pilot use with Phase 1 security controls | Management approval |
| Schedule Phase 2-3 before enterprise rollout | Resource allocation |
| Plan annual methodology review | Compliance calendar |

---

**Report Prepared By:** Internal Control & Risk Management  
**Review Date:** April 11, 2026  
**Next Review:** July 2026  

---

*End of Audit Report*
