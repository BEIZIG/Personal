# Risk Cartography Solution
## AFA & Sapin II Compliance Dashboard

**Version 1.0.0** | *Professional Risk Analysis Platform*

---

# 🎯 Executive Summary

**What We Deliver:**
- 🖥️ **Streamlit Web Application** — Run analysis from your browser
- ⚙️ **Admin Interface** — Configure columns, categories, formulas without coding
- 📊 **Interactive HTML Dashboards** — Real-time risk monitoring with Chart.js
- 📈 **PowerBI-Ready Exports** — Enterprise reporting integration
- 📖 **Built-in Documentation** — Wiki mode with user guides

**Key Feature:** One-click execution with full customization capability

**Try It:** `START_Windows.bat` or `./START_Linux_Mac.sh`

---

# 📱 Application Overview

## Three Operating Modes

| Mode | Purpose | Users |
|------|---------|-------|
| 🎯 **Executor** | Run risk analysis on Excel files | All users |
| ⚙️ **Admin** | Configure columns, categories, scoring | Administrators |
| 📖 **Wiki** | Built-in documentation and guides | All users |

## Streamlit Interface

- **Browser-Based:** No installation required beyond Python
- **Real-Time Feedback:** Instant validation on configuration changes
- **File Management:** Upload/select Excel files directly in the app
- **One-Click Analysis:** Generate dashboards with a single button

---

# 📋 Regulatory Context

## Sapin II Law (Article 17) - 8 Pillars

| Pillar | Our Coverage |
|--------|--------------|
| 1️⃣ **Risk Mapping** | ✅ Full cartography with P×I scoring |
| 2️⃣ Code of Conduct | ✅ Risk scenarios linked to policies |
| 3️⃣ Whistleblowing | ✅ Alert thresholds configured |
| 4️⃣ Third-Party Evaluation | ✅ Category-based risk assessment |
| 5️⃣ Accounting Controls | ✅ Financial risk category tracking |
| 6️⃣ Training | ✅ Risk awareness metrics |
| 7️⃣ Disciplinary Sanctions | ✅ Consequence framework mapping |
| 8️⃣ Internal Control | ✅ Control effectiveness measurement |

**AFA Compliance:** Methodology follows official AFA guidelines for corruption risk mapping

---

# 🔬 Methodology

## Risk Scoring Formula

```
Risk Score = Probability × Impact
```

| Scale | Probability | Impact |
|-------|-------------|--------|
| 1 | Rare | Minor |
| 2 | Unlikely | Moderate |
| 3 | Likely | Major |
| 4 | Very Likely | Critical |

## Risk Level Classification

| Level | Score Range | Action Required |
|-------|-------------|-----------------|
| 🟢 **Low** | 1-3 | Monitor |
| 🟡 **Moderate** | 4-6 | Control Review |
| 🟠 **High** | 8-9 | Action Plan |
| 🔴 **Critical** | 12-16 | Immediate Action |

---

# ⚙️ Admin Interface

## Column Mapping Configuration

| Feature | Capability |
|---------|------------|
| **15 Configurable Columns** | Map to any Excel header |
| **Reorder Columns** | ⬆️⬇️ buttons to change display order |
| **Add New Columns** | Define custom fields |
| **Delete Columns** | Remove unnecessary mappings |
| **Field Types** | text, numeric, level |

## Configuration Panels

| Panel | Controls |
|-------|----------|
| **Column Mapping** | Excel column ↔ analysis field |
| **Risk Categories** | A-corruption, B-favoritism, etc. |
| **Risk Levels** | High/Medium/Low thresholds |
| **Formulas** | Automatic calculations |

---

# 📊 Dashboard Capabilities

## 1. Global Dashboard View

| Feature | Description |
|---------|-------------|
| **KPI Cards** | Total risks, Critical count, High count, Mitigation rate |
| **Risk Heat Matrix** | 4×4 Sapin II compliant matrix (Gross & Residual) |
| **Chart Analytics** | Distribution by level, category, entity |
| **AFA Compliance Score** | Control coverage, effectiveness, urgency |

## 2. Entity Drill-Down

- Click any entity → dedicated dashboard
- Filtered risk registry
- Entity-specific KPIs and trends
- Category radar comparison (Gross vs Residual)

## 3. Interactive Features

- Dark/Light theme toggle
- Sortable & searchable risk registry
- Click-to-filter functionality
- Risk detail modal with full context
- PDF/CSV export capabilities

---

# 📈 Key Metrics Computed

## Summary Statistics

| Metric | Formula | Value |
|--------|---------|-------|
| **Risk Reduction** | ((Gross - Residual) / Gross) × 100 | Measures control effectiveness |
| **Mitigation Rate** | (Improved / Total) × 100 | % of risks reduced by controls |
| **Urgency Score** | Weighted priority index | Critical×4 + High×2 + Moderate×1 |
| **Control Coverage** | (Documented / Total) × 100 | Sapin II compliance indicator |

## Advanced Analytics

| Analysis | Purpose |
|----------|---------|
| **Herfindahl Index** | Risk concentration measurement |
| **Control Gap Analysis** | Identifies ineffective controls |
| **Risk Trends** | Period-over-period comparison |
| **Pillar Compliance** | Per-pillar Sapin II scoring |

---

# 💼 PowerBI Integration

## Exported Files Ready for Import

| File | Content | Use Case |
|------|---------|----------|
| `powerbi_risk_data.csv` | Complete risk registry | Main data source |
| `powerbi_kpi_summary.csv` | Dashboard KPIs | KPI cards visual |
| `powerbi_level_distribution.csv` | Risk level counts | Doughnut/bar chart |
| `powerbi_mitigation.csv` | Mitigation stats | Pie chart |
| `powerbi_top_risks.csv` | Highest residual risks | Top N table |
| `powerbi_analysis.json` | Full analysis object | Advanced dashboards |

## PowerBI ↔ HTML Dashboard Alignment

| Dashboard Feature | HTML | PowerBI CSV |
|-------------------|------|-------------|
| KPI Cards | ✅ | `powerbi_kpi_summary.csv` |
| Risk Level Chart | ✅ | `powerbi_level_distribution.csv` |
| Mitigation Pie | ✅ | `powerbi_mitigation.csv` |
| Top Risks List | ✅ | `powerbi_top_risks.csv` |

**→ Same data, same structure — HTML for preview, PowerBI for enterprise**

---

# ✨ Value Proposition

## For Compliance Teams

| Benefit | Impact |
|---------|--------|
| **Automated Analysis** | Significant reduction in manual cartography time |
| **AFA-Aligned** | Pre-built compliance with regulatory standards |
| **Audit-Ready** | Exportable evidence for AFA inspections |
| **Real-Time Visibility** | Instant KPIs vs. quarterly reports |

## For Management

| Benefit | Impact |
|---------|--------|
| **Executive Dashboard** | Key insights in 30 seconds |
| **Entity Comparison** | Identify highest-risk units |
| **Control Effectiveness** | ROI on mitigation investments |
| **Drill-Down Capability** | From overview to detail in 1 click |

## For IT/Data Teams

| Benefit | Impact |
|---------|--------|
| **No Infrastructure** | Runs locally on any machine |
| **PowerBI Native** | CSV exports ready for import |
| **Scalable** | Add entities without code changes |
| **Configuration-Driven** | JSON files for customization |

---

# 🔧 Technical Architecture

## Application Structure

```
┌─────────────────────────────────────────────────────────────┐
│                    STREAMLIT APPLICATION                     │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐          │
│  │  Executor   │  │   Admin     │  │    Wiki     │          │
│  │    Mode     │  │    Mode     │  │    Mode     │          │
│  └─────────────┘  └─────────────┘  └─────────────┘          │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                 PROCESSING ENGINE (lib/)                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │ data_loader  │  │  analyzer    │  │ html_generator│       │
│  │ (Excel I/O)  │  │ (Scoring)    │  │ (Dashboard)   │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │ config_loader│  │  exporters   │  │    main      │       │
│  │ (JSON mgmt)  │  │ (PowerBI)    │  │ (Orchestrate)│       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    OUTPUT FILES                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │ HTML         │  │ PowerBI      │  │ Excel        │       │
│  │ Dashboards   │  │ CSV/JSON     │  │ Report       │       │
│  │ (Interactive)│  │ (Integration)│  │ (Offline)    │       │
│  └──────────────┘  └──────────────┘  └──────────────┘       │
└─────────────────────────────────────────────────────────────┘
```

---

# 📁 Delivery Package Structure

```
RISK_CARTOGRAPHY_DELIVERY/
├── app.py                    # Streamlit application (48 KB)
├── requirements.txt          # Python dependencies
├── START_Windows.bat         # One-click Windows launcher
├── START_Linux_Mac.sh        # One-click Unix launcher
├── README.md                 # Documentation
│
├── lib/                      # Core processing modules
│   ├── main.py              # Analysis orchestrator
│   ├── analyzer.py          # Risk calculations (38 KB)
│   ├── data_loader.py       # Excel reader (17 KB)
│   ├── html_generator.py    # Dashboard generator (161 KB)
│   ├── exporters.py         # PowerBI/Excel export (47 KB)
│   ├── config_loader.py     # Configuration manager (20 KB)
│   └── __init__.py          # Module initialization
│
├── config/                   # Configuration files
│   ├── analysis_config.json # Master configuration
│   ├── column_mapping.json  # 15 column definitions
│   ├── column_order.json    # Display order
│   ├── categories.json      # Risk categories (A-E)
│   ├── risk_levels.json     # High/Medium/Low thresholds
│   └── formulas.json        # Calculation definitions
│
├── input/                    # Place Excel files here
├── output/                   # Generated reports
├── samples/                  # Sample data
│   └── sample_entity.xlsx   # Demo file (98 KB)
│
└── docs/                     # Documentation
    ├── TROUBLESHOOTING.md   # Common issues
    └── QUICK_START.md       # Quick reference
```

---

# 🚀 Quick Start Guide

## Installation (30 seconds)

**Windows:**
```
1. Extract ZIP file
2. Double-click START_Windows.bat
3. Browser opens at http://localhost:8501
```

**Linux/Mac:**
```bash
1. Extract ZIP file
2. chmod +x START_Linux_Mac.sh
3. ./START_Linux_Mac.sh
4. Browser opens at http://localhost:8501
```

## First Analysis (60 seconds)

1. Select **Executor Mode** from sidebar
2. Choose `sample_entity.xlsx` from dropdown
3. Click **🚀 Run Analysis**
4. Open `output/dashboard_sample_entity.html`

---

# 📖 Built-in Wiki Documentation

## 6 Documentation Sections

| Section | Content |
|---------|---------|
| **Overview** | What is Risk Cartography, key capabilities |
| **Dashboard Guide** | How to use the HTML dashboard |
| **Understanding Charts** | Interpreting visualizations |
| **Formulas Explained** | P×I calculation, mitigation rate |
| **Output Files** | What each file contains |
| **AFA/Sapin II** | Regulatory compliance mapping |

**Accessible directly in the application** via Wiki Mode

---

# 🏛️ Code Architecture

## Modular Design

```
lib/
├── config_loader.py    # Configuration management
├── data_loader.py      # Excel parsing & validation
├── analyzer.py         # Risk analysis engine
├── html_generator.py   # Dashboard rendering
├── exporters.py        # PowerBI/Excel exports
└── main.py             # Orchestration entry point
```

**Each module is independent** — modify one without breaking others

## Clean Code Principles

| Principle | Implementation |
|-----------|----------------|
| **Single Responsibility** | Each module handles one concern |
| **DRY (Don't Repeat)** | Shared utilities, no copy-paste |
| **Type Hints** | Python dataclasses for structures |
| **Error Handling** | Graceful failures with messages |

---

# ⚙️ Configuration-Driven

## External JSON Configuration Files

| File | Purpose | Editable By |
|------|---------|-------------|
| `column_mapping.json` | Excel columns, field types | Business Analyst |
| `categories.json` | Risk category definitions | SME |
| `risk_levels.json` | Scoring thresholds | Compliance |
| `formulas.json` | Automatic calculations | Admin |

## Example: Adding a New Risk Category

Use Admin Mode in the application:

1. Go to **⚙️ Admin Mode**
2. Open **Risk Categories** panel
3. Click **Add Category**
4. Fill in: Key (e.g., "F"), Name (e.g., "Cyber Risk"), Color
5. Click **💾 Save**

**→ Zero code changes required**

---

# 🔧 Easy Customization Points

## What Can Be Changed Without Coding

| Customization | How |
|---------------|-----|
| **Column mappings** | Admin Mode → Column Mapping |
| **Risk categories** | Admin Mode → Categories |
| **Risk thresholds** | Admin Mode → Risk Levels |
| **Formulas** | Admin Mode → Formulas |
| **Column order** | ⬆️⬇️ buttons in Column Mapping |

## What Requires Minor Code Changes

| Customization | Effort |
|---------------|--------|
| New chart type | Add method in `html_generator.py` |
| New export format | Add method in `exporters.py` |
| Custom KPI | Add calculation in `analyzer.py` |

---

# 💡 Why Choose This Solution?

| Criterion | Our Solution | Traditional Approach |
|-----------|--------------|---------------------|
| **Deployment** | Extract & Run | IT infrastructure |
| **Speed** | Minutes | Weeks |
| **Configuration** | Admin UI | Developer changes |
| **Consistency** | 100% formula-based | Manual interpretation |
| **Auditability** | Full traceability | Spreadsheet chaos |
| **Scalability** | Unlimited entities | Resource-constrained |
| **AFA Compliance** | Built-in | Custom development |
| **Updates** | Re-run analysis | Rebuild from scratch |

---

# 📞 Next Steps

## 1. Data Collection
- Provide risk cartography Excel files
- Define category mapping
- Specify language preferences

## 2. Configuration
- Review column mappings in Admin Mode
- Customize categories and thresholds
- Set branding requirements

## 3. Delivery
- Generate dashboards
- Provide PowerBI exports
- User training session

---

# 🎯 Summary

| Capability | Delivered |
|------------|-----------|
| 🖥️ Streamlit Web Application | ✅ |
| ⚙️ Admin Configuration Interface | ✅ |
| 📖 Built-in Wiki Documentation | ✅ |
| AFA/Sapin II Compliance | ✅ |
| Interactive HTML Dashboard | ✅ |
| Entity Drill-Down | ✅ |
| Risk Heat Matrix | ✅ |
| PowerBI Integration | ✅ |
| 15 Configurable Columns | ✅ |
| JSON Configuration (No-Code) | ✅ |
| One-Click Launchers (Win/Mac/Linux) | ✅ |
| Sample Data Included | ✅ |

**→ Production-ready risk cartography platform with full customization**

---

# 📦 Deliverable Package

| Item | Size |
|------|------|
| **RISK_CARTOGRAPHY_v1.0.0.zip** | ~155 KB |
| Python Modules | 7 files (~300 KB) |
| Configuration | 6 JSON files |
| Documentation | 4 files (README, Wiki, Troubleshooting) |
| Sample Data | 1 Excel file (98 KB) |
| Launchers | Windows + Linux/Mac |

**Requirements:** Python 3.8+ (Python 3.6 minimum supported)

---

# Contact

*[Your contact information here]*

---

*Solution: Risk Cartography v1.0.0*
*Methodology: AFA Guidelines + Sapin II Article 17*
*Technology: Python + Streamlit + Chart.js*
