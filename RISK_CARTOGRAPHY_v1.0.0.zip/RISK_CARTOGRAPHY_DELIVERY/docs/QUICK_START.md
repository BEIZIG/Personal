# Quick Start Guide

## ⚡ 5-Minute Setup

### Step 1: Launch

**Windows:** Double-click `START_Windows.bat`  
**Mac/Linux:** Run `./START_Linux_Mac.sh`

### Step 2: Wait

Browser opens automatically at http://localhost:8501

### Step 3: Analyze

1. Select **Executor Mode** (sidebar)
2. Choose file from dropdown
3. Click **🚀 Run Analysis**

---

## 📊 Sample Analysis

Try the included sample file:

1. Select `sample_entity.xlsx` from dropdown
2. Click **Run Analysis**
3. Check `output/` folder for:
   - `dashboard_sample_entity.html` (open in browser)
   - `powerbi_sample_entity.json` (import to PowerBI)

---

## 🔧 Customize

Go to **Admin Mode** to configure:

| Section | What you can change |
|---------|-------------------|
| Column Mapping | Excel columns, order, types |
| Categories | Risk category definitions |
| Risk Levels | High/Medium/Low thresholds |
| Formulas | Automatic calculations |

---

## 📁 Your Data

1. Place your `.xlsx` file in `input/` folder
2. Ensure column names match configuration
3. Run analysis from Executor Mode

---

## ❓ Need Help?

- **📖 Wiki Mode** - Built-in documentation
- **📄 docs/TROUBLESHOOTING.md** - Common issues
- **📧 Support** - Contact your account manager

---

*Happy analyzing!*
