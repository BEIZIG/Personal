# Risk Cartography - AFA/Sapin II Compliance Solution

## 📦 Delivery Package Contents

```
RISK_CARTOGRAPHY_DELIVERY_PACKAGE/
├── app.py                    # Streamlit web interface
├── diagnose.py               # Troubleshooting utility
├── requirements.txt          # Python dependencies
├── START_Windows.bat         # Windows launcher
├── START_Linux_Mac.sh        # Linux/Mac launcher
├── INSTALL.md                # Installation guide
├── README.md                 # This file
│
├── lib/                      # Core Python modules
│   ├── run_analysis.py       # Main entry point
│   ├── config_manager.py     # Configuration handling
│   ├── excel_reader.py       # Excel file loading
│   ├── risk_analyzer.py      # Risk calculations
│   ├── dashboard_builder.py  # HTML generation
│   ├── pdf_report_builder.py # PDF generation
│   ├── powerbi_exporter.py   # CSV exports
│   └── CODE_GUIDE.md         # Developer documentation
│
├── config/                   # Configuration files
│   ├── analysis_config.json  # Main configuration
│   ├── column_mapping.json   # Excel column positions
│   ├── risk_levels.json      # Score thresholds
│   ├── categories.json       # AFA categories
│   └── formulas.json         # Calculation formulas
│
├── docs/                     # Documentation
│   ├── SOLUTION_PRESENTATION.md   # Solution overview (Markdown)
│   ├── SOLUTION_PRESENTATION.pptx # Solution overview (PowerPoint)
│   ├── RUNBOOK.md            # Maintenance guide
│   ├── QUICK_START.md        # User guide
│   └── TROUBLESHOOTING.md    # Common issues
│
├── input/                    # Input files (place Excel here)
│   └── sample_entity.xlsx    # Sample data
│
├── output/                   # Generated outputs (auto-created)
│
└── samples/                  # Sample templates
```

---

## 🚀 Quick Start

### Windows

1. Double-click `START_Windows.bat`
2. Browser opens automatically at http://localhost:8501

### Linux / Mac

```bash
chmod +x START_Linux_Mac.sh
./START_Linux_Mac.sh
```

### Manual Start

```bash
pip install -r requirements.txt
streamlit run app.py
```

---

## 📋 Prerequisites

- Python 3.6 or higher
- pip (Python package manager)

---

## 📊 What This Solution Does

1. **Reads** risk cartography Excel files
2. **Analyzes** risks using AFA/Sapin II methodology
3. **Generates**:
   - Interactive HTML dashboards
   - PDF reports with charts
   - PowerBI-ready CSV exports
   - Excel summary report

---

## 📁 Input Format

Place Excel files in the `input/` folder with this structure:

| Column | Content |
|--------|---------|
| A | Risk ID (A1, B2, C3...) |
| B | Process/Category |
| C | Risk Scenario |
| D | Description |
| E | Aggravating Factors |
| F | Probability (1-4) |
| G | Impact (1-4) |
| H | Gross Score |
| I | Gross Level |
| J | Prevention Measures |
| K | Residual Probability |
| L | Residual Impact |
| M | Residual Score |
| N | Residual Level |
| O | Corrective Actions |

---

## 📞 Support

See `docs/TROUBLESHOOTING.md` for common issues.
See `docs/RUNBOOK.md` for maintenance procedures.

---

## 📄 Version

- **Version:** 1.0.0
- **Date:** April 2026
