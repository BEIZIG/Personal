# 🔧 Installation Guide

## Windows Installation

### Step 1: Install Python

1. Download Python from https://www.python.org/downloads/
2. **Important:** Check "Add Python to PATH" during installation
3. Click "Install Now"

### Step 2: Verify Installation

Open Command Prompt (cmd) and type:
```cmd
python --version
pip --version
```

Both should show version numbers.

### Step 3: Install Dependencies

Open Command Prompt in the delivery folder:
```cmd
cd path\to\RISK_CARTOGRAPHY_DELIVERY_PACKAGE
pip install -r requirements.txt
```

### Step 4: Run Application

**Option A:** Double-click `START_Windows.bat`

**Option B:** Command line:
```cmd
streamlit run app.py
```

Browser opens automatically at http://localhost:8501

---

## Linux / Mac Installation

### Step 1: Verify Python

```bash
python3 --version
pip3 --version
```

If not installed:
```bash
# Ubuntu/Debian
sudo apt install python3 python3-pip

# Mac (with Homebrew)
brew install python3
```

### Step 2: Install Dependencies

```bash
cd /path/to/RISK_CARTOGRAPHY_DELIVERY_PACKAGE
pip3 install -r requirements.txt
```

### Step 3: Run Application

```bash
chmod +x START_Linux_Mac.sh
./START_Linux_Mac.sh
```

Or manually:
```bash
streamlit run app.py
```

---

## Dependencies Installed

| Package | Purpose |
|---------|---------|
| pandas | Data manipulation |
| openpyxl | Excel file reading |
| streamlit | Web interface |
| reportlab | PDF generation |

---

## Troubleshooting

### "Python not found"
- Windows: Reinstall Python with "Add to PATH" checked
- Linux/Mac: Use `python3` instead of `python`

### "pip not found"
- Windows: `python -m pip install -r requirements.txt`
- Linux: `python3 -m pip install -r requirements.txt`

### "Module not found"
```bash
pip install --upgrade pandas openpyxl streamlit reportlab
```

### Port 8501 already in use
```bash
streamlit run app.py --server.port 8502
```

---

## Offline Installation

If the client PC has no internet access:

1. On a connected PC, download wheels:
```bash
pip download -d ./packages -r requirements.txt
```

2. Copy the `packages/` folder to client PC

3. Install from local files:
```bash
pip install --no-index --find-links=./packages -r requirements.txt
```

---

## Verify Installation

Run the diagnostic tool:
```bash
python diagnose.py
```

This checks:
- Python version
- Required packages
- File structure
- Configuration validity
