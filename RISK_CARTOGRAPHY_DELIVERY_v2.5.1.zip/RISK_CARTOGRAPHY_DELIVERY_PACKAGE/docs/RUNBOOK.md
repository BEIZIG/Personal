# 🔧 RUNBOOK - Maintenance Scenarios

This document provides step-by-step instructions for common maintenance tasks.

---

## Table of Contents

1. [Scenario A: Input Format Changes](#scenario-a-input-format-changes)
   - [A1: Different Sheet Name](#a1-different-sheet-name)
   - [A2: Different Column Names/Order](#a2-different-column-namesorder)
   - [A3: Different Data Types](#a3-different-data-types)
   - [A4: Additional Columns](#a4-additional-columns)
2. [Scenario B: Formula Personalization](#scenario-b-formula-personalization)
   - [B1: Change Score Calculation](#b1-change-score-calculation)
   - [B2: Change Risk Level Thresholds](#b2-change-risk-level-thresholds)
   - [B3: Add Custom Metrics](#b3-add-custom-metrics)

---

## Scenario A: Input Format Changes

When the client provides Excel files with a different structure than expected.

---

### A1: Different Sheet Name

**Symptom:** Error "Sheet 'All' not found" or empty data loaded.

**Solution:** Modify the configuration file.

#### Option 1: Configuration Only (No Code Change)

Edit `config/analysis_config.json`:

```json
{
  "input": {
    "files": [
      {
        "filename": "client_file.xlsx",
        "entity_name": "Client Entity",
        "enabled": true,
        "sheet_name": "RiskData",  // ← CHANGE THIS to match client's sheet name
        "skip_rows": 3
      }
    ]
  }
}
```

#### Option 2: Via Streamlit UI

1. Open the app: `streamlit run app.py`
2. Go to **Admin Mode** → **Files Configuration**
3. Edit the **Sheet Name** field for the file
4. Click **Save Configuration**

#### Option 3: Using Command Line (Legacy Mode)

```bash
cd lib
python run_analysis.py --legacy --sheet "RiskData"
```

---

### A2: Different Column Names/Order

**Symptom:** Data appears in wrong columns or shows `NaN` for critical fields.

**Root Cause:** Client's Excel has columns in different positions than expected.

#### Step 1: Identify the Client's Column Layout

Open the client's Excel file and note the column positions:

| Position | Client's Column Header |
|----------|------------------------|
| 0 | ? |
| 1 | ? |
| ... | ... |

#### Step 2: Update Column Mapping

Edit `config/analysis_config.json` → `columns.mapping`:

```json
{
  "columns": {
    "mapping": {
      "0": "risk_id",           // Column A = Risk ID
      "1": "scenario",          // Column B = Scenario (was "processus")
      "2": "description",       // Column C = Description
      "3": "aggravating_factors",
      "4": "prob_gross",        // ← CLIENT HAS PROBABILITY IN COLUMN E
      "5": "impact_gross",      // ← CLIENT HAS IMPACT IN COLUMN F
      "6": "score_gross",
      "7": "level_gross",
      "8": "prevention_measures",
      "9": "prob_residual",
      "10": "impact_residual",
      "11": "score_residual",
      "12": "level_residual",
      "13": "corrective_actions"
    }
  }
}
```

#### Step 3: Update Legacy Default (If Using Directory Mode)

If using `--legacy` mode or directory scanning, also update `lib/excel_reader.py`:

```python
# Line ~97 - DEFAULT_COLUMN_MAPPING
DEFAULT_COLUMN_MAPPING = {
    0: 'risk_id',
    1: 'scenario',           # Changed from 'processus'
    2: 'description',
    3: 'aggravating_factors',
    4: 'prob_gross',         # Probability at column 4
    5: 'impact_gross',       # Impact at column 5
    # ... continue mapping
}
```

#### Step 4: Verify the Mapping

Run a quick test:

```bash
cd lib
python3 -c "
import pandas as pd
df = pd.read_excel('../input/client_file.xlsx', sheet_name='All', header=None, skiprows=3)
print('Column 0:', df[0].head(3).tolist())
print('Column 4:', df[4].head(3).tolist())  # Should be probability values 1-4
print('Column 5:', df[5].head(3).tolist())  # Should be impact values 1-4
"
```

---

### A3: Different Data Types

**Symptom:** Numeric columns show as text, or calculations fail.

#### Issue: Probability/Impact as Text ("High", "Medium", "Low")

If client uses text labels instead of numbers:

**Solution:** Add a mapping function in `lib/excel_reader.py`:

```python
# Add after line ~340 in _clean_dataframe method

# Convert text probability to numeric
TEXT_TO_NUMERIC = {
    'very low': 1, 'low': 1, 'faible': 1,
    'medium': 2, 'moderate': 2, 'moyen': 2,
    'high': 3, 'élevé': 3,
    'very high': 4, 'critical': 4, 'critique': 4
}

def convert_text_to_score(value):
    if pd.isna(value):
        return None
    if isinstance(value, (int, float)):
        return int(value)
    text = str(value).lower().strip()
    return TEXT_TO_NUMERIC.get(text, None)

# In _clean_dataframe, add:
if 'prob_gross' in df.columns:
    df['prob_gross'] = df['prob_gross'].apply(convert_text_to_score)
if 'impact_gross' in df.columns:
    df['impact_gross'] = df['impact_gross'].apply(convert_text_to_score)
```

#### Issue: Dates in Wrong Format

If `last_review_date` column has unusual format:

```python
# In _clean_dataframe method
if 'last_review_date' in df.columns:
    df['last_review_date'] = pd.to_datetime(
        df['last_review_date'], 
        format='%d/%m/%Y',  # Adjust format as needed
        errors='coerce'
    )
```

---

### A4: Additional Columns

**Symptom:** Client has extra columns we want to capture.

#### Step 1: Add to Column Mapping

Edit `config/analysis_config.json`:

```json
{
  "columns": {
    "mapping": {
      // ... existing columns ...
      "15": "risk_owner",           // NEW COLUMN
      "16": "due_date",             // NEW COLUMN
      "17": "compliance_reference"  // NEW COLUMN
    }
  }
}
```

#### Step 2: Display in Dashboard (Optional)

Edit `lib/dashboard_builder.py` → `_prepare_risks_data` method (~line 651):

```python
def _prepare_risks_data(self, df: pd.DataFrame) -> str:
    risks = []
    for _, row in df.iterrows():
        risk = {
            # ... existing fields ...
            'risk_owner': str(row.get('risk_owner', '')),      # ADD
            'due_date': str(row.get('due_date', '')),          # ADD
            'compliance_ref': str(row.get('compliance_reference', '')),  # ADD
        }
        risks.append(risk)
    return json.dumps(risks, ensure_ascii=False)
```

#### Step 3: Add to PDF Report (Optional)

Edit `lib/pdf_report_builder.py` to include new columns in tables.

---

## Scenario B: Formula Personalization

When the client wants to customize how risks are calculated.

---

### B1: Change Score Calculation

**Current Formula:** `Score = Probability × Impact`

**Client Request:** Different formula (e.g., weighted, maximum, etc.)

#### Option 1: Weighted Score

Client wants: `Score = (Probability × 0.4) + (Impact × 0.6) × 4`

Edit `lib/excel_reader.py` → `_clean_dataframe` method:

```python
# Replace the score calculation (around line 366)

# OLD (simple P × I):
# df['score_gross'] = df['prob_gross'] * df['impact_gross']

# NEW (weighted formula):
def calculate_weighted_score(prob, impact):
    if pd.isna(prob) or pd.isna(impact):
        return None
    return round((prob * 0.4 + impact * 0.6) * 4)

if 'prob_gross' in df.columns and 'impact_gross' in df.columns:
    if 'score_gross' not in df.columns or df['score_gross'].isna().all():
        df['score_gross'] = df.apply(
            lambda row: calculate_weighted_score(row['prob_gross'], row['impact_gross']), 
            axis=1
        )
```

#### Option 2: Maximum of P and I

Client wants: `Score = max(Probability, Impact) × 4`

```python
if 'prob_gross' in df.columns and 'impact_gross' in df.columns:
    df['score_gross'] = df[['prob_gross', 'impact_gross']].max(axis=1) * 4
```

#### Option 3: Custom 5×5 Matrix

Client uses 5-level scale instead of 4:

```python
# Update probability/impact range
PROBABILITY_RANGE = (1, 5)  # Changed from (1, 4)
IMPACT_RANGE = (1, 5)

# Update score calculation (max score = 25)
df['score_gross'] = df['prob_gross'] * df['impact_gross']
```

Also update `config/risk_levels.json`:

```json
{
  "critical": {"min_score": 20, "max_score": 25, "label": "Critical"},
  "high": {"min_score": 15, "max_score": 19, "label": "High"},
  "moderate": {"min_score": 8, "max_score": 14, "label": "Moderate"},
  "low": {"min_score": 1, "max_score": 7, "label": "Low"}
}
```

---

### B2: Change Risk Level Thresholds

**Current Thresholds:**
- Critical: 12-16
- High: 8-11
- Moderate: 4-7
- Low: 1-3

**Client Request:** Different thresholds

#### Configuration Only (No Code Change)

Edit `config/risk_levels.json`:

```json
{
  "critical": {
    "min_score": 15,     // Changed from 12
    "max_score": 16,
    "label": "Critical",
    "color": "#dc3545",
    "emoji": "🔴"
  },
  "high": {
    "min_score": 10,     // Changed from 8
    "max_score": 14,     // Changed from 11
    "label": "High",
    "color": "#fd7e14",
    "emoji": "🟠"
  },
  "moderate": {
    "min_score": 5,      // Changed from 4
    "max_score": 9,      // Changed from 7
    "label": "Moderate",
    "color": "#ffc107",
    "emoji": "🟡"
  },
  "low": {
    "min_score": 1,
    "max_score": 4,      // Changed from 3
    "label": "Low",
    "color": "#28a745",
    "emoji": "🟢"
  }
}
```

#### Also Update Level Assignment Logic

Edit `lib/excel_reader.py` → `get_level` function (~line 380):

```python
def get_level(score):
    """Assign risk level based on score thresholds."""
    if pd.isna(score):
        return None
    score = int(score)
    
    # CLIENT'S CUSTOM THRESHOLDS:
    if score >= 15:
        return '🔴 Critical'
    elif score >= 10:
        return '🟠 High'
    elif score >= 5:
        return '🟡 Moderate'
    else:
        return '🟢 Low'
```

---

### B3: Add Custom Metrics

**Client Request:** New calculated field (e.g., "Urgency Score", "Risk Velocity")

#### Step 1: Add Calculation in Analyzer

Edit `lib/risk_analyzer.py`:

```python
# Add to RiskAnalysis dataclass (around line 200)
@dataclass
class CustomMetrics:
    """Client-specific custom metrics."""
    urgency_score: float = 0.0
    risk_velocity: float = 0.0
    compliance_gap: float = 0.0

# Add to RiskAnalysis class:
custom_metrics: CustomMetrics = field(default_factory=CustomMetrics)
```

#### Step 2: Calculate the Metric

In `lib/risk_analyzer.py` → `analyze` method:

```python
def analyze(self, df: pd.DataFrame) -> RiskAnalysis:
    # ... existing analysis code ...
    
    # CUSTOM METRICS
    custom = CustomMetrics()
    
    # Example: Urgency Score = Critical×4 + High×3 + Moderate×2 + Low×1
    custom.urgency_score = (
        analysis.by_level.get('Critical', LevelStats('', '', '', 0, 0)).count * 4 +
        analysis.by_level.get('High', LevelStats('', '', '', 0, 0)).count * 3 +
        analysis.by_level.get('Moderate', LevelStats('', '', '', 0, 0)).count * 2 +
        analysis.by_level.get('Low', LevelStats('', '', '', 0, 0)).count * 1
    ) / max(analysis.summary.total_risks, 1)
    
    # Example: Risk Velocity = (Gross Average - Residual Average) / Time
    custom.risk_velocity = analysis.summary.risk_reduction_pct / 100
    
    analysis.custom_metrics = custom
    return analysis
```

#### Step 3: Display in Dashboard

Edit `lib/dashboard_builder.py` → `_generate_kpi_cards`:

```python
# Add new KPI card
<div class="kpi-card">
    <div class="kpi-icon">⚡</div>
    <div class="kpi-content">
        <div class="kpi-value">{analysis.custom_metrics.urgency_score:.1f}</div>
        <div class="kpi-label">Urgency Score</div>
    </div>
</div>
```

---

## Quick Reference: File Locations

| What to Change | File to Edit |
|----------------|--------------|
| Sheet name, skip rows | `config/analysis_config.json` |
| Column positions | `config/analysis_config.json` → `columns.mapping` |
| Legacy column mapping | `lib/excel_reader.py` → `DEFAULT_COLUMN_MAPPING` |
| Risk level thresholds | `config/risk_levels.json` |
| Score calculation | `lib/excel_reader.py` → `_clean_dataframe` |
| Level assignment | `lib/excel_reader.py` → `get_level` |
| New analysis metrics | `lib/risk_analyzer.py` |
| Dashboard display | `lib/dashboard_builder.py` |
| PDF report content | `lib/pdf_report_builder.py` |

---

## Testing After Changes

Always test after making changes:

```bash
# 1. Validate data loading
cd lib
python3 -c "
from excel_reader import RiskDataLoader
loader = RiskDataLoader()
df = loader.load_directory('../input')
print(df[['risk_id', 'prob_gross', 'impact_gross', 'score_gross']].head())
"

# 2. Run full analysis
python run_analysis.py --legacy

# 3. Check outputs
ls -la ../output/*.html
ls -la ../output/*.pdf

# 4. Open dashboard in browser
xdg-open ../output/risk_dashboard.html  # Linux
# or
open ../output/risk_dashboard.html      # Mac
```

---

## Contact & Support

For issues not covered here:
1. Check `docs/TROUBLESHOOTING.md`
2. Run `python diagnose.py` for diagnostics
3. Review logs in terminal output

