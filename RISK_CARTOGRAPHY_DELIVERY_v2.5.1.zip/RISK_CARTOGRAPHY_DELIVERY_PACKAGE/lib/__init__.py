"""
================================================================================
RISK CARTOGRAPHY ANALYSIS PACKAGE
================================================================================

This package provides tools for analyzing corruption risk cartography data
from Excel files and generating interactive dashboards and reports.

MODULES:
    config_manager      - JSON configuration loading and validation
    excel_reader        - Excel file loading and data transformation
    risk_analyzer       - Risk analysis and statistics computation
    dashboard_builder   - Interactive HTML dashboard generation
    pdf_report_builder  - PDF report generation with charts
    powerbi_exporter    - PowerBI-compatible data export

QUICK START (Recommended):
    from lib import load_config, RiskDataLoader, RiskAnalyzer
    
    # 1. Load configuration
    config = load_config('configuration/analysis_config.json')
    
    # 2. Load Excel files
    loader = RiskDataLoader.from_config(config)
    df = loader.load_all()
    
    # 3. Analyze risks
    analyzer = RiskAnalyzer.from_config(config)
    analysis = analyzer.analyze(df)
    
    # 4. Generate outputs
    from lib import EnhancedDashboardGenerator
    generator = EnhancedDashboardGenerator()
    generator.generate_with_analysis(df, analysis, 'dashboard.html')

COMMAND LINE USAGE:
    python lib/run_analysis.py                    # Run with default config
    python lib/run_analysis.py -c my_config.json  # Custom config
    python lib/run_analysis.py --init             # Create new config

SEE ALSO:
    CODE_GUIDE.md - Detailed documentation for maintainers

VERSION: 2.0.0
================================================================================
"""

__version__ = '2.0.0'
__author__ = 'Risk Management Team'

# =============================================================================
# IMPORTS FROM NEW MODULE NAMES
# =============================================================================

# Configuration loading (was: config_loader)
from .config_manager import (
    load_config,
    create_default_config,
    AnalysisConfiguration,
    ConfigLoader
)

# Data loading (was: data_loader)
from .excel_reader import (
    RiskDataLoader,
    load_risk_data,
    load_risk_data_from_config
)

# Analysis (was: analyzer)
from .risk_analyzer import (
    RiskAnalyzer,
    RiskAnalysis,
    analyze_risks
)

# Dashboard generation (was: html_generator)
from .dashboard_builder import (
    EnhancedDashboardGenerator,
    EnhancedDashboardGenerator as DashboardGenerator,  # Alias for compatibility
    generate_enhanced_dashboard,
    generate_enhanced_dashboard as generate_dashboard  # Alias for compatibility
)

# Data export (was: exporters)
from .powerbi_exporter import (
    DataExporter,
    export_to_powerbi
)

# =============================================================================
# BACKWARD COMPATIBILITY ALIASES
# =============================================================================
# These allow old code using the original module names to still work

# Old module name aliases (for backward compatibility)
config_loader = __import__('config_manager', globals(), locals(), level=1)
data_loader = __import__('excel_reader', globals(), locals(), level=1)
analyzer = __import__('risk_analyzer', globals(), locals(), level=1)
html_generator = __import__('dashboard_builder', globals(), locals(), level=1)
exporters = __import__('powerbi_exporter', globals(), locals(), level=1)

# =============================================================================
# PUBLIC API
# =============================================================================

__all__ = [
    # Configuration
    'load_config',
    'create_default_config',
    'AnalysisConfiguration',
    'ConfigLoader',
    
    # Data Loading
    'RiskDataLoader',
    'load_risk_data',
    'load_risk_data_from_config',
    
    # Analysis
    'RiskAnalyzer',
    'RiskAnalysis',
    'analyze_risks',
    
    # Dashboard (enhanced)
    'EnhancedDashboardGenerator',
    'DashboardGenerator',  # Alias
    'generate_enhanced_dashboard',
    'generate_dashboard',  # Alias
    
    # Export
    'DataExporter',
    'export_to_powerbi',
]
