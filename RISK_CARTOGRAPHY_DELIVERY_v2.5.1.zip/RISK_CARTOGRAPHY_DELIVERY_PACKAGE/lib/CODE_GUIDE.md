# 📚 Code Guide for Risk Cartography

This guide explains how the code is organized and how to maintain it.

> 📖 **For maintenance scenarios** (input format changes, formula customization), see: [`docs/RUNBOOK.md`](../docs/RUNBOOK.md)

---

## 🗂️ File Overview

| File Name | Purpose | When to Edit |
|-----------|---------|--------------|
| `run_analysis.py` | **Main entry point** - runs the analysis | Rarely |
| `config_manager.py` | Loads JSON configuration | When changing config format |
| `excel_reader.py` | Reads Excel files | When Excel format changes |
| `risk_analyzer.py` | Calculates statistics | When adding new metrics |
| `dashboard_builder.py` | Creates HTML dashboard | When changing dashboard design |
| `pdf_report_builder.py` | Creates PDF reports | When changing PDF format |
| `powerbi_exporter.py` | Creates PowerBI exports | When adding new exports |

---

## 🔄 Data Flow

```
┌─────────────────┐
│ Excel Files     │  (input/*.xlsx)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ excel_reader.py │  → Reads Excel, cleans data
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│risk_analyzer.py │  → Calculates statistics
└────────┬────────┘
         │
    ┌────┴────┬──────────────┐
    ▼         ▼              ▼
┌────────┐ ┌────────┐ ┌─────────────┐
│ HTML   │ │  PDF   │ │   CSV       │
│Dashboard│ │Report │ │(PowerBI)    │
└────────┘ └────────┘ └─────────────┘
```

---

## 📁 Directory Structure

```
RISK_CARTOGRAPHY_DELIVERY/
├── lib/                     # Source code modules
│   ├── run_analysis.py      # Main script - START HERE
│   ├── config_manager.py    # Configuration handling
│   ├── excel_reader.py      # Excel file loading
│   ├── risk_analyzer.py     # Risk calculations
│   ├── dashboard_builder.py # HTML generation
│   ├── pdf_report_builder.py# PDF generation
│   └── powerbi_exporter.py  # CSV exports
│
├── configuration/           # JSON config files
│   ├── analysis_config.json # Main configuration
│   ├── dashboard_labels.json# Text labels for dashboard
│   └── dashboard_help.json  # Help tooltip texts
│
├── input/                   # Excel files go here
│   └── *.xlsx               # Your risk cartography files
│
├── output/                  # Generated files appear here
│   ├── *.html               # HTML dashboards
│   ├── *.pdf                # PDF reports
│   └── powerbi_*.csv        # PowerBI data files
│
├── app.py                   # Streamlit web interface
└── diagnose.py              # Troubleshooting tool
```

---

## 🔧 Common Tasks

### 1. Add a New Excel File

1. Place the file in `input/` directory
2. Edit `configuration/analysis_config.json`
3. Add to the `"files"` list:

```json
{
  "filename": "your_file.xlsx",
  "entity_name": "Your Entity Name",
  "enabled": true
}
```

### 2. Change Column Mappings

Edit `configuration/analysis_config.json` → `"column_mapping"` section:

```json
"score_gross": {
  "source_name": "Score Brut",    ← Change this to your column name
  "aliases": ["Risk Score", "S_Brut"],
  "required": true
}
```

### 3. Modify Risk Levels

Edit `configuration/analysis_config.json` → `"risk_levels"` section:

```json
"risk_levels": {
  "🔴 Critical": {"label": "Critical", "color": "#dc3545", "min": 13, "max": 16},
  "🟠 High":     {"label": "High",     "color": "#fd7e14", "min": 9,  "max": 12},
  "🟡 Moderate": {"label": "Moderate", "color": "#ffc107", "min": 5,  "max": 8},
  "🟢 Low":      {"label": "Low",      "color": "#28a745", "min": 1,  "max": 4}
}
```

### 4. Change Dashboard Labels

Edit `configuration/dashboard_labels.json`:

```json
{
  "title": "My Custom Dashboard Title",
  "kpi_total_risks": "Total des Risques"
}
```

---

## 🏃 Running the Analysis

### Command Line

```bash
# Basic run (uses default config)
python lib/run_analysis.py

# With custom config
python lib/run_analysis.py -c my_config.json

# Create new config from Excel files
python lib/run_analysis.py --init

# Verbose output
python lib/run_analysis.py -v
```

### From Streamlit

```bash
streamlit run app.py
```

Then open `http://localhost:8501` in your browser.

---

## 🐛 Troubleshooting

### "Module not found" Error

Make sure you're running from the correct directory:
```bash
cd /path/to/RISK_CARTOGRAPHY_DELIVERY
python lib/run_analysis.py
```

### Excel File Not Loading

1. Check the file is in `input/` directory
2. Check it's listed in `analysis_config.json`
3. Check `enabled: true` in the config
4. Run diagnostic tool:
```bash
python diagnose.py
```

### PDF Not Generated

PDF requires `reportlab` library:
```bash
pip install reportlab
```

---

## 📝 Code Conventions

### Adding Comments

When you modify code, add comments like this:

```python
# =====================================================
# SECTION: Load Excel Files
# PURPOSE: Read all configured Excel files into memory
# MODIFIED BY: Your Name, 2026-04-11
# =====================================================
```

### Variable Names

- Use descriptive names: `risk_count` not `rc`
- Use snake_case: `total_risks` not `totalRisks`

### Functions

Every function should have a docstring:

```python
def calculate_score(probability, impact):
    """
    Calculate risk score from probability and impact.
    
    Args:
        probability: Integer 1-4 (likelihood of risk)
        impact: Integer 1-4 (severity if risk occurs)
    
    Returns:
        Integer: Score = probability × impact (1-16)
    
    Example:
        score = calculate_score(3, 4)  # Returns 12
    """
    return probability * impact
```

---

## 📊 Key Data Structures

### Risk Record (DataFrame Row)

| Field | Type | Description |
|-------|------|-------------|
| `risk_id` | str | Unique ID (e.g., "A1", "B2") |
| `entity` | str | Business unit name |
| `category_code` | str | AFA category (A, C, F, M, P, R, S) |
| `scenario` | str | Risk description |
| `prob_gross` | int | Gross probability (1-4) |
| `impact_gross` | int | Gross impact (1-4) |
| `score_gross` | int | Gross score (1-16) |
| `level_gross` | str | Gross level (Low/Moderate/High/Critical) |
| `prob_residual` | int | Residual probability (1-4) |
| `impact_residual` | int | Residual impact (1-4) |
| `score_residual` | int | Residual score (1-16) |
| `level_residual` | str | Residual level |

### Analysis Result

```python
analysis.summary.total_risks      # Total count
analysis.summary.total_entities   # Number of entities
analysis.by_level['Critical']     # Stats for Critical risks
analysis.by_entity['Entity A']    # Stats for Entity A
analysis.top_risks                # Top 10 highest risks
```

---

## 🔒 Backup Before Modifying

Before making changes, always backup:

```bash
# Backup the lib folder
cp -r lib lib_backup_YYYYMMDD

# Backup configuration
cp configuration/analysis_config.json configuration/analysis_config.json.bak
```

---

## 📧 Getting Help

If you encounter issues:

1. Run `python diagnose.py` for automatic checks
2. Check the log output for error messages
3. Verify JSON configuration is valid (use jsonlint.com)
4. Check Excel files have expected columns

---

*Last updated: 2026-04-11*
*Version: 2.0.0*
