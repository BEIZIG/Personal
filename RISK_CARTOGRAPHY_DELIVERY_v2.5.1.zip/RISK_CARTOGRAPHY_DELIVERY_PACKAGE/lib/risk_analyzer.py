"""
================================================================================
RISK ANALYZER MODULE
================================================================================

PURPOSE:
    This module analyzes risk data loaded from Excel files and calculates
    statistics, distributions, and metrics for the dashboard.

WHAT IT DOES:
    1. Calculates summary statistics (total risks, average scores, etc.)
    2. Groups risks by level (Low, Moderate, High, Critical)
    3. Groups risks by entity (different business units/subsidiaries)
    4. Groups risks by AFA category (Procurement, Finance, etc.)
    5. Identifies top critical risks
    6. Calculates mitigation effectiveness
    7. Computes AFA/Sapin II compliance metrics

KEY CLASSES:
    - RiskAnalyzer: Main class that performs all analysis
    - RiskAnalysis: Result object containing all computed statistics

EXAMPLE USAGE:
    # Basic usage
    from risk_analyzer import RiskAnalyzer
    
    analyzer = RiskAnalyzer()
    analysis = analyzer.analyze(dataframe)
    
    # Access results
    print(f"Total risks: {analysis.summary.total_risks}")
    print(f"Critical risks: {analysis.by_level['Critical'].count}")

RISK LEVELS:
    - Low (🟢): Score 1-4, acceptable risk level
    - Moderate (🟡): Score 5-8, monitor and manage
    - High (🟠): Score 9-12, requires action plan
    - Critical (🔴): Score 13-16, immediate action required

AFA CATEGORIES (Sapin II):
    A = Procurement (Achats)         - Supplier relationships
    C = Commercial/Sales             - Customer interactions
    F = Finance                      - Financial operations
    M = M&A / JV                     - Mergers, acquisitions, joint ventures
    P = Public Officials             - Government interactions
    R = Human Resources (RH)         - HR and recruitment
    S = Sponsoring                   - Sponsorship and donations

AUTHOR: Risk Management Team
VERSION: 2.0.0
================================================================================
"""

import pandas as pd
from datetime import datetime
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, field, asdict
import logging

logger = logging.getLogger(__name__)


# =============================================================================
# DEFAULT VALUES (used when no JSON config provided)
# =============================================================================

DEFAULT_RISK_LEVELS = {
    '🟢 Low': {'label': 'Low', 'color': '#28a745', 'order': 1},
    '🟡 Moderate': {'label': 'Moderate', 'color': '#ffc107', 'order': 2},
    '🟠 High': {'label': 'High', 'color': '#fd7e14', 'order': 3},
    '🔴 Critical': {'label': 'Critical', 'color': '#dc3545', 'order': 4}
}

DEFAULT_RISK_CATEGORIES = {
    'A': {'name': 'Procurement (Achats)', 'color': '#3498db'},
    'C': {'name': 'Commercial/Sales', 'color': '#9b59b6'},
    'R': {'name': 'Human Resources (RH)', 'color': '#e74c3c'},
    'F': {'name': 'Finance', 'color': '#2ecc71'},
    'M': {'name': 'M&A / JV', 'color': '#f39c12'},
    'S': {'name': 'Sponsoring', 'color': '#1abc9c'},
    'P': {'name': 'Public Officials', 'color': '#34495e'}
}

DEFAULT_TOP_RISKS_COUNT = 10


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class SummaryStats:
    """Overall summary statistics."""
    total_risks: int = 0
    total_entities: int = 0
    avg_gross_score: float = 0.0
    avg_residual_score: float = 0.0
    risk_reduction_pct: float = 0.0
    max_gross_score: float = 0.0
    max_residual_score: float = 0.0


@dataclass
class EntityStats:
    """Statistics for a single entity."""
    entity_name: str
    total_risks: int
    avg_gross_score: float
    avg_residual_score: float
    critical_count: int
    high_count: int
    moderate_count: int
    low_count: int
    risk_reduction_pct: float


@dataclass
class CategoryStats:
    """Statistics for a risk category."""
    category_code: str
    category_name: str
    color: str
    count: int
    avg_gross_score: float
    avg_residual_score: float


@dataclass
class LevelStats:
    """Statistics for a risk level."""
    level_key: str
    label: str
    color: str
    count: int
    percentage: float


@dataclass
class MitigationStats:
    """Mitigation effectiveness statistics."""
    improved: int
    unchanged: int
    worsened: int
    improvement_rate: float


@dataclass
class AFAComplianceStats:
    """AFA (Agence Française Anticorruption) / Sapin II compliance statistics."""
    # Risk Coverage
    total_processes_covered: int = 0
    total_scenarios_mapped: int = 0
    scenarios_per_process_avg: float = 0.0
    
    # Control Coverage
    risks_with_controls: int = 0
    control_coverage_rate: float = 0.0
    risks_without_controls: int = 0
    
    # Risk Acceptance
    accepted_risks: int = 0  # Low risks that are acceptable
    risks_requiring_action: int = 0  # High/Critical requiring remediation
    risk_acceptance_rate: float = 0.0
    
    # Control Effectiveness (Inherent → Residual)
    avg_risk_reduction: float = 0.0
    highly_effective_controls: int = 0  # >50% reduction
    moderately_effective_controls: int = 0  # 25-50% reduction
    ineffective_controls: int = 0  # <25% reduction or worsened
    control_effectiveness_score: float = 0.0  # 0-100 score
    
    # Remediation Status
    risks_with_action_plans: int = 0
    remediation_coverage_rate: float = 0.0


@dataclass
class RiskConcentrationStats:
    """Risk concentration and distribution analysis."""
    # Concentration Index (Herfindahl-Hirschman Index style)
    entity_concentration_index: float = 0.0  # 0-1, higher = more concentrated
    category_concentration_index: float = 0.0
    
    # Distribution
    highest_risk_entity: str = ""
    highest_risk_entity_count: int = 0
    highest_risk_entity_pct: float = 0.0
    
    highest_risk_category: str = ""
    highest_risk_category_count: int = 0
    highest_risk_category_pct: float = 0.0
    
    # Critical Risk Distribution
    entities_with_critical_risks: int = 0
    entities_without_critical_risks: int = 0
    critical_risk_concentration: float = 0.0


@dataclass 
class ControlGapStats:
    """Control gap analysis for remediation prioritization."""
    # Gap Analysis
    total_control_gaps: int = 0
    high_priority_gaps: int = 0  # Critical/High risks with weak controls
    medium_priority_gaps: int = 0
    low_priority_gaps: int = 0
    
    # Residual Risk Profile
    residual_critical_pct: float = 0.0
    residual_high_pct: float = 0.0
    residual_moderate_pct: float = 0.0
    residual_low_pct: float = 0.0
    
    # Target State Gap (vs acceptable risk profile)
    target_critical_max_pct: float = 5.0  # Target: max 5% critical
    target_high_max_pct: float = 15.0  # Target: max 15% high
    gap_to_target_critical: float = 0.0
    gap_to_target_high: float = 0.0
    
    # Prioritization Score
    urgency_score: float = 0.0  # 0-100, higher = more urgent action needed


@dataclass
class RiskTrendStats:
    """Risk trend and velocity indicators."""
    # Score Trends
    inherent_risk_index: float = 0.0  # Weighted average of inherent risks
    residual_risk_index: float = 0.0  # Weighted average of residual risks
    risk_treatment_effectiveness: float = 0.0  # % improvement
    
    # Risk Appetite Alignment
    risks_within_appetite: int = 0  # Low/Moderate
    risks_exceeding_appetite: int = 0  # High/Critical
    appetite_breach_rate: float = 0.0


@dataclass
class SapinIIPillarStats:
    """Sapin II 8 Pillar compliance indicators (based on available data)."""
    # Pillar 1: Risk Mapping - measured by this cartography
    risk_mapping_coverage: float = 0.0  # % of processes with risk scenarios
    risk_mapping_depth: float = 0.0  # avg scenarios per process
    
    # Pillar 4: Third-party due diligence (estimated from category coverage)
    third_party_exposure_pct: float = 0.0  # % risks involving third parties (Procurement, Commercial, M&A, Sponsoring)
    
    # Pillar 5: Internal controls - measured by risk reduction
    internal_control_effectiveness: float = 0.0
    
    # Overall Compliance Score (simplified)
    overall_compliance_score: float = 0.0  # 0-100


@dataclass
class RiskAnalysis:
    """Complete risk analysis results with AFA/Sapin II compliance metrics."""
    generated_at: str
    summary: SummaryStats
    by_entity: Dict[str, EntityStats] = field(default_factory=dict)
    by_category: Dict[str, CategoryStats] = field(default_factory=dict)
    by_level: Dict[str, LevelStats] = field(default_factory=dict)
    risk_matrix_gross: Dict[str, int] = field(default_factory=dict)
    risk_matrix_residual: Dict[str, int] = field(default_factory=dict)
    top_risks: List[Dict] = field(default_factory=list)
    mitigation: MitigationStats = None
    
    # AFA/Sapin II Compliance Stats
    afa_compliance: AFAComplianceStats = field(default_factory=AFAComplianceStats)
    risk_concentration: RiskConcentrationStats = field(default_factory=RiskConcentrationStats)
    control_gaps: ControlGapStats = field(default_factory=ControlGapStats)
    risk_trends: RiskTrendStats = field(default_factory=RiskTrendStats)
    sapin_ii_pillars: SapinIIPillarStats = field(default_factory=SapinIIPillarStats)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization."""
        result = {
            'generated_at': self.generated_at,
            'summary': asdict(self.summary),
            'by_entity': {k: asdict(v) for k, v in self.by_entity.items()},
            'by_category': {k: asdict(v) for k, v in self.by_category.items()},
            'by_level': {k: asdict(v) for k, v in self.by_level.items()},
            'risk_matrix_gross': self.risk_matrix_gross,
            'risk_matrix_residual': self.risk_matrix_residual,
            'top_risks': self.top_risks,
            'mitigation': asdict(self.mitigation) if self.mitigation else {},
            # AFA/Sapin II Compliance
            'afa_compliance': asdict(self.afa_compliance) if self.afa_compliance else {},
            'risk_concentration': asdict(self.risk_concentration) if self.risk_concentration else {},
            'control_gaps': asdict(self.control_gaps) if self.control_gaps else {},
            'risk_trends': asdict(self.risk_trends) if self.risk_trends else {},
            'sapin_ii_pillars': asdict(self.sapin_ii_pillars) if self.sapin_ii_pillars else {}
        }
        return result


# =============================================================================
# RISK ANALYZER
# =============================================================================

class RiskAnalyzer:
    """
    Analyzes risk cartography data.
    
    Supports two modes:
    
    1. With JSON configuration:
        from config_loader import load_config
        config = load_config('analysis_config.json')
        analyzer = RiskAnalyzer.from_config(config)
        analysis = analyzer.analyze(df)
    
    2. Standalone with defaults:
        analyzer = RiskAnalyzer()
        analysis = analyzer.analyze(df)
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize analyzer with optional config overrides.
        
        Args:
            config: Optional dict with 'top_risks_count', 'risk_levels', 'risk_categories'
        """
        self.config = config or {}
        self.top_risks_count = self.config.get('top_risks_count', DEFAULT_TOP_RISKS_COUNT)
        self._risk_levels = self.config.get('risk_levels', DEFAULT_RISK_LEVELS)
        self._risk_categories = self.config.get('risk_categories', DEFAULT_RISK_CATEGORIES)
    
    @classmethod
    def from_config(cls, json_config) -> 'RiskAnalyzer':
        """
        Create analyzer from JSON configuration object.
        
        Args:
            json_config: AnalysisConfiguration from config_loader
            
        Returns:
            Configured RiskAnalyzer
        """
        # Convert JSON config to internal format
        risk_levels = {}
        for level in json_config.risk_levels:
            risk_levels[level.key] = {
                'label': level.label_en,
                'color': level.color,
                'order': level.order
            }
        
        risk_categories = {}
        for cat in json_config.risk_categories:
            risk_categories[cat.prefix] = {
                'name': f"{cat.name_en} ({cat.name_fr})",
                'color': cat.color
            }
        
        config = {
            'top_risks_count': json_config.analysis.top_risks_count,
            'risk_levels': risk_levels,
            'risk_categories': risk_categories
        }
        
        return cls(config)
    
    def analyze(self, df: pd.DataFrame) -> RiskAnalysis:
        """
        Perform comprehensive risk analysis including AFA/Sapin II compliance metrics.
        
        Args:
            df: DataFrame with risk data
            
        Returns:
            RiskAnalysis with all computed statistics
        """
        if df.empty:
            logger.warning("Empty DataFrame provided for analysis")
            return RiskAnalysis(
                generated_at=datetime.now().isoformat(),
                summary=SummaryStats()
            )
        
        analysis = RiskAnalysis(
            generated_at=datetime.now().isoformat(),
            summary=self._compute_summary(df),
            by_entity=self._analyze_by_entity(df),
            by_category=self._analyze_by_category(df),
            by_level=self._analyze_by_level(df),
            risk_matrix_gross=self._compute_risk_matrix(df, 'gross'),
            risk_matrix_residual=self._compute_risk_matrix(df, 'residual'),
            top_risks=self._get_top_risks(df),
            mitigation=self._analyze_mitigation(df),
            # AFA/Sapin II Compliance Analysis
            afa_compliance=self._analyze_afa_compliance(df),
            risk_concentration=self._analyze_risk_concentration(df),
            control_gaps=self._analyze_control_gaps(df),
            risk_trends=self._analyze_risk_trends(df),
            sapin_ii_pillars=self._analyze_sapin_ii_pillars(df)
        )
        
        return analysis
    
    def _compute_summary(self, df: pd.DataFrame) -> SummaryStats:
        """Compute overall summary statistics."""
        avg_gross = df['score_gross'].mean() if 'score_gross' in df.columns else 0
        avg_residual = df['score_residual'].mean() if 'score_residual' in df.columns else 0
        
        # Handle NaN values
        if pd.isna(avg_gross):
            avg_gross = 0.0
        if pd.isna(avg_residual):
            avg_residual = 0.0
        
        reduction_pct = 0
        if avg_gross > 0:
            reduction_pct = ((avg_gross - avg_residual) / avg_gross) * 100
        
        max_gross = df['score_gross'].max() if 'score_gross' in df.columns else 0
        max_residual = df['score_residual'].max() if 'score_residual' in df.columns else 0
        
        # Handle NaN for max values
        if pd.isna(max_gross):
            max_gross = 0.0
        if pd.isna(max_residual):
            max_residual = 0.0
        
        return SummaryStats(
            total_risks=len(df),
            total_entities=df['entity'].nunique() if 'entity' in df.columns else 0,
            avg_gross_score=round(avg_gross, 2),
            avg_residual_score=round(avg_residual, 2),
            risk_reduction_pct=round(reduction_pct, 1),
            max_gross_score=float(max_gross),
            max_residual_score=float(max_residual)
        )
    
    def _analyze_by_entity(self, df: pd.DataFrame) -> Dict[str, EntityStats]:
        """Analyze risks grouped by entity."""
        results = {}
        
        if 'entity' not in df.columns:
            return results
        
        for entity in df['entity'].unique():
            entity_df = df[df['entity'] == entity]
            
            avg_gross = entity_df['score_gross'].mean()
            avg_residual = entity_df['score_residual'].mean()
            
            # Handle NaN values - default to 0.0
            if pd.isna(avg_gross):
                avg_gross = 0.0
            if pd.isna(avg_residual):
                avg_residual = 0.0
            
            reduction_pct = ((avg_gross - avg_residual) / avg_gross * 100) if avg_gross > 0 else 0
            
            results[entity] = EntityStats(
                entity_name=entity,
                total_risks=len(entity_df),
                avg_gross_score=round(avg_gross, 2),
                avg_residual_score=round(avg_residual, 2),
                critical_count=len(entity_df[entity_df['level_residual'] == '🔴 Critical']),
                high_count=len(entity_df[entity_df['level_residual'] == '🟠 High']),
                moderate_count=len(entity_df[entity_df['level_residual'] == '🟡 Moderate']),
                low_count=len(entity_df[entity_df['level_residual'] == '🟢 Low']),
                risk_reduction_pct=round(reduction_pct, 1)
            )
        
        return results
    
    def _analyze_by_category(self, df: pd.DataFrame) -> Dict[str, CategoryStats]:
        """Analyze risks grouped by category."""
        results = {}
        
        if 'category' not in df.columns:
            return results
        
        for cat_code, cat_info in self._risk_categories.items():
            cat_df = df[df['category'] == cat_code]
            
            if len(cat_df) > 0:
                avg_gross = cat_df['score_gross'].mean()
                avg_residual = cat_df['score_residual'].mean()
                
                # Handle NaN values
                if pd.isna(avg_gross):
                    avg_gross = 0.0
                if pd.isna(avg_residual):
                    avg_residual = 0.0
                
                results[cat_code] = CategoryStats(
                    category_code=cat_code,
                    category_name=cat_info['name'],
                    color=cat_info['color'],
                    count=len(cat_df),
                    avg_gross_score=round(avg_gross, 2),
                    avg_residual_score=round(avg_residual, 2)
                )
        
        return results
    
    def _analyze_by_level(self, df: pd.DataFrame) -> Dict[str, LevelStats]:
        """Analyze risks grouped by risk level."""
        results = {}
        total = len(df)
        
        if 'level_residual' not in df.columns or total == 0:
            return results
        
        for level_key, level_info in self._risk_levels.items():
            level_df = df[df['level_residual'] == level_key]
            count = len(level_df)
            
            results[level_key] = LevelStats(
                level_key=level_key,
                label=level_info['label'],
                color=level_info['color'],
                count=count,
                percentage=round(count / total * 100, 1)
            )
        
        return results
    
    def _compute_risk_matrix(self, df: pd.DataFrame, risk_type: str) -> Dict[str, int]:
        """
        Compute risk matrix (probability x impact).
        
        Args:
            df: DataFrame with risk data
            risk_type: 'gross' or 'residual'
            
        Returns:
            Dictionary with matrix cell counts (e.g., '1x2': 5)
        """
        matrix = {}
        prob_col = f'prob_{risk_type}'
        impact_col = f'impact_{risk_type}'
        
        if prob_col not in df.columns or impact_col not in df.columns:
            return matrix
        
        # Standard 4x4 matrix
        for prob in range(1, 5):
            for impact in range(1, 5):
                key = f"{prob}x{impact}"
                count = len(df[(df[prob_col] == prob) & (df[impact_col] == impact)])
                matrix[key] = count
        
        return matrix
    
    def _get_top_risks(self, df: pd.DataFrame) -> List[Dict]:
        """Get top N highest residual risks."""
        if 'score_residual' not in df.columns:
            return []
        
        top_df = df.nlargest(self.top_risks_count, 'score_residual')
        
        columns = ['entity', 'risk_id', 'scenario', 'score_gross', 'score_residual', 'level_residual']
        available_cols = [c for c in columns if c in top_df.columns]
        
        return top_df[available_cols].to_dict('records')
    
    def _analyze_mitigation(self, df: pd.DataFrame) -> MitigationStats:
        """Analyze mitigation effectiveness."""
        if 'score_gross' not in df.columns or 'score_residual' not in df.columns:
            return MitigationStats(0, 0, 0, 0.0)
        
        improved = len(df[df['score_residual'] < df['score_gross']])
        unchanged = len(df[df['score_residual'] == df['score_gross']])
        worsened = len(df[df['score_residual'] > df['score_gross']])
        
        total = len(df)
        improvement_rate = (improved / total * 100) if total > 0 else 0
        
        return MitigationStats(
            improved=improved,
            unchanged=unchanged,
            worsened=worsened,
            improvement_rate=round(improvement_rate, 1)
        )
    
    # =========================================================================
    # AFA / SAPIN II COMPLIANCE ANALYSIS METHODS
    # =========================================================================
    
    def _analyze_afa_compliance(self, df: pd.DataFrame) -> AFAComplianceStats:
        """
        Analyze AFA (Agence Française Anticorruption) compliance metrics.
        Based on Sapin II law requirements for risk cartography.
        """
        total = len(df)
        if total == 0:
            return AFAComplianceStats()
        
        # Process/Category coverage
        processes_covered = df['category'].nunique() if 'category' in df.columns else 0
        scenarios_mapped = total
        scenarios_per_process = total / processes_covered if processes_covered > 0 else 0
        
        # Control coverage analysis (based on prevention_measures field)
        if 'prevention_measures' in df.columns:
            risks_with_controls = len(df[df['prevention_measures'].notna() & (df['prevention_measures'] != '')])
        else:
            risks_with_controls = 0
        
        risks_without_controls = total - risks_with_controls
        control_coverage = (risks_with_controls / total * 100) if total > 0 else 0
        
        # Risk acceptance analysis (Low risks = acceptable)
        if 'level_residual' in df.columns:
            accepted = len(df[df['level_residual'].isin(['🟢 Low', '🟢 Faible'])])
            requiring_action = len(df[df['level_residual'].isin(['🔴 Critical', '🟠 High', '🔴 Critique', '🟠 Élevé'])])
        else:
            accepted = 0
            requiring_action = 0
        
        acceptance_rate = (accepted / total * 100) if total > 0 else 0
        
        # Control effectiveness analysis
        if 'score_gross' in df.columns and 'score_residual' in df.columns:
            valid_mask = df['score_gross'].notna() & df['score_residual'].notna() & (df['score_gross'] > 0)
            valid_df = df[valid_mask]
            
            if len(valid_df) > 0:
                reduction_pct = (valid_df['score_gross'] - valid_df['score_residual']) / valid_df['score_gross'] * 100
                
                highly_effective = len(reduction_pct[reduction_pct >= 50])
                moderately_effective = len(reduction_pct[(reduction_pct >= 25) & (reduction_pct < 50)])
                ineffective = len(reduction_pct[reduction_pct < 25])
                
                avg_reduction = reduction_pct.mean()
                
                # Control effectiveness score (0-100)
                # Based on: % highly effective × 1.0 + % moderately effective × 0.5
                total_valid = len(valid_df)
                effectiveness_score = (
                    (highly_effective / total_valid * 100) * 1.0 +
                    (moderately_effective / total_valid * 100) * 0.5
                ) if total_valid > 0 else 0
            else:
                highly_effective = moderately_effective = ineffective = 0
                avg_reduction = 0
                effectiveness_score = 0
        else:
            highly_effective = moderately_effective = ineffective = 0
            avg_reduction = 0
            effectiveness_score = 0
        
        # Remediation coverage (based on corrective_actions field)
        if 'corrective_actions' in df.columns:
            risks_with_actions = len(df[df['corrective_actions'].notna() & (df['corrective_actions'] != '')])
        else:
            risks_with_actions = 0
        
        remediation_coverage = (risks_with_actions / requiring_action * 100) if requiring_action > 0 else 100
        
        return AFAComplianceStats(
            total_processes_covered=processes_covered,
            total_scenarios_mapped=scenarios_mapped,
            scenarios_per_process_avg=round(scenarios_per_process, 1),
            risks_with_controls=risks_with_controls,
            control_coverage_rate=round(control_coverage, 1),
            risks_without_controls=risks_without_controls,
            accepted_risks=accepted,
            risks_requiring_action=requiring_action,
            risk_acceptance_rate=round(acceptance_rate, 1),
            avg_risk_reduction=round(avg_reduction, 1) if not pd.isna(avg_reduction) else 0,
            highly_effective_controls=highly_effective,
            moderately_effective_controls=moderately_effective,
            ineffective_controls=ineffective,
            control_effectiveness_score=round(effectiveness_score, 1),
            risks_with_action_plans=risks_with_actions,
            remediation_coverage_rate=round(remediation_coverage, 1)
        )
    
    def _analyze_risk_concentration(self, df: pd.DataFrame) -> RiskConcentrationStats:
        """
        Analyze risk concentration using Herfindahl-Hirschman Index style metrics.
        Helps identify if risks are concentrated in specific entities/categories.
        """
        total = len(df)
        if total == 0:
            return RiskConcentrationStats()
        
        # Entity concentration (HHI-style)
        if 'entity' in df.columns:
            entity_counts = df['entity'].value_counts()
            entity_shares = entity_counts / total
            entity_hhi = (entity_shares ** 2).sum()  # 0-1, higher = more concentrated
            
            highest_entity = entity_counts.index[0]
            highest_entity_count = entity_counts.iloc[0]
            highest_entity_pct = (highest_entity_count / total * 100)
        else:
            entity_hhi = 0
            highest_entity = ""
            highest_entity_count = 0
            highest_entity_pct = 0
        
        # Category concentration
        if 'category' in df.columns:
            cat_counts = df['category'].value_counts()
            cat_shares = cat_counts / total
            cat_hhi = (cat_shares ** 2).sum()
            
            highest_cat = cat_counts.index[0]
            highest_cat_count = cat_counts.iloc[0]
            highest_cat_pct = (highest_cat_count / total * 100)
        else:
            cat_hhi = 0
            highest_cat = ""
            highest_cat_count = 0
            highest_cat_pct = 0
        
        # Critical risk distribution
        if 'level_residual' in df.columns and 'entity' in df.columns:
            critical_df = df[df['level_residual'].isin(['🔴 Critical', '🔴 Critique'])]
            entities_with_critical = critical_df['entity'].nunique()
            total_entities = df['entity'].nunique()
            entities_without_critical = total_entities - entities_with_critical
            
            critical_concentration = (len(critical_df) / total * 100) if total > 0 else 0
        else:
            entities_with_critical = 0
            entities_without_critical = 0
            critical_concentration = 0
        
        return RiskConcentrationStats(
            entity_concentration_index=round(entity_hhi, 3),
            category_concentration_index=round(cat_hhi, 3),
            highest_risk_entity=highest_entity,
            highest_risk_entity_count=highest_entity_count,
            highest_risk_entity_pct=round(highest_entity_pct, 1),
            highest_risk_category=highest_cat,
            highest_risk_category_count=highest_cat_count,
            highest_risk_category_pct=round(highest_cat_pct, 1),
            entities_with_critical_risks=entities_with_critical,
            entities_without_critical_risks=entities_without_critical,
            critical_risk_concentration=round(critical_concentration, 1)
        )
    
    def _analyze_control_gaps(self, df: pd.DataFrame) -> ControlGapStats:
        """
        Analyze control gaps for remediation prioritization.
        Identifies priority gaps based on residual risk vs target state.
        """
        total = len(df)
        if total == 0:
            return ControlGapStats()
        
        # Residual risk distribution
        if 'level_residual' in df.columns:
            critical_count = len(df[df['level_residual'].isin(['🔴 Critical', '🔴 Critique'])])
            high_count = len(df[df['level_residual'].isin(['🟠 High', '🟠 Élevé'])])
            moderate_count = len(df[df['level_residual'].isin(['🟡 Moderate', '🟡 Modéré'])])
            low_count = len(df[df['level_residual'].isin(['🟢 Low', '🟢 Faible'])])
            
            critical_pct = critical_count / total * 100
            high_pct = high_count / total * 100
            moderate_pct = moderate_count / total * 100
            low_pct = low_count / total * 100
        else:
            critical_count = high_count = moderate_count = low_count = 0
            critical_pct = high_pct = moderate_pct = low_pct = 0
        
        # Gap analysis - risks that exceed target thresholds
        # Target: max 5% critical, max 15% high
        target_critical_max = 5.0
        target_high_max = 15.0
        
        gap_critical = max(0, critical_pct - target_critical_max)
        gap_high = max(0, high_pct - target_high_max)
        
        # Priority gaps (high/critical risks that haven't been reduced)
        if 'score_gross' in df.columns and 'score_residual' in df.columns:
            high_prio_mask = (
                df['level_residual'].isin(['🔴 Critical', '🔴 Critique']) &
                (df['score_residual'] >= df['score_gross'] * 0.75)  # Less than 25% reduction
            )
            high_priority_gaps = len(df[high_prio_mask])
            
            medium_prio_mask = (
                df['level_residual'].isin(['🟠 High', '🟠 Élevé']) &
                (df['score_residual'] >= df['score_gross'] * 0.75)
            )
            medium_priority_gaps = len(df[medium_prio_mask])
            
            low_priority_gaps = critical_count + high_count - high_priority_gaps - medium_priority_gaps
            low_priority_gaps = max(0, low_priority_gaps)
        else:
            high_priority_gaps = critical_count
            medium_priority_gaps = high_count
            low_priority_gaps = 0
        
        total_gaps = high_priority_gaps + medium_priority_gaps + low_priority_gaps
        
        # Urgency score (0-100)
        # Based on: gap to target + proportion of high-priority gaps
        urgency_score = min(100, (
            gap_critical * 3 +  # Weight critical gap heavily
            gap_high * 1.5 +
            (high_priority_gaps / total * 100) if total > 0 else 0
        ))
        
        return ControlGapStats(
            total_control_gaps=total_gaps,
            high_priority_gaps=high_priority_gaps,
            medium_priority_gaps=medium_priority_gaps,
            low_priority_gaps=low_priority_gaps,
            residual_critical_pct=round(critical_pct, 1),
            residual_high_pct=round(high_pct, 1),
            residual_moderate_pct=round(moderate_pct, 1),
            residual_low_pct=round(low_pct, 1),
            target_critical_max_pct=target_critical_max,
            target_high_max_pct=target_high_max,
            gap_to_target_critical=round(gap_critical, 1),
            gap_to_target_high=round(gap_high, 1),
            urgency_score=round(urgency_score, 1)
        )
    
    def _analyze_risk_trends(self, df: pd.DataFrame) -> RiskTrendStats:
        """
        Analyze risk trends and velocity indicators.
        Provides risk appetite alignment metrics.
        """
        total = len(df)
        if total == 0:
            return RiskTrendStats()
        
        # Risk indices (weighted average scores)
        if 'score_gross' in df.columns:
            inherent_index = df['score_gross'].mean()
            inherent_index = 0 if pd.isna(inherent_index) else inherent_index
        else:
            inherent_index = 0
        
        if 'score_residual' in df.columns:
            residual_index = df['score_residual'].mean()
            residual_index = 0 if pd.isna(residual_index) else residual_index
        else:
            residual_index = 0
        
        # Treatment effectiveness
        treatment_effectiveness = 0
        if inherent_index > 0:
            treatment_effectiveness = ((inherent_index - residual_index) / inherent_index) * 100
        
        # Risk appetite alignment
        # Assuming Low/Moderate are within appetite, High/Critical exceed it
        if 'level_residual' in df.columns:
            within_appetite = len(df[df['level_residual'].isin([
                '🟢 Low', '🟢 Faible', '🟡 Moderate', '🟡 Modéré'
            ])])
            exceeding_appetite = len(df[df['level_residual'].isin([
                '🟠 High', '🟠 Élevé', '🔴 Critical', '🔴 Critique'
            ])])
        else:
            within_appetite = 0
            exceeding_appetite = 0
        
        breach_rate = (exceeding_appetite / total * 100) if total > 0 else 0
        
        return RiskTrendStats(
            inherent_risk_index=round(inherent_index, 2),
            residual_risk_index=round(residual_index, 2),
            risk_treatment_effectiveness=round(treatment_effectiveness, 1),
            risks_within_appetite=within_appetite,
            risks_exceeding_appetite=exceeding_appetite,
            appetite_breach_rate=round(breach_rate, 1)
        )
    
    def _analyze_sapin_ii_pillars(self, df: pd.DataFrame) -> SapinIIPillarStats:
        """
        Analyze Sapin II 8-pillar compliance indicators.
        Based on available data from risk cartography.
        
        Sapin II Pillars:
        1. Risk Mapping (cartographie des risques)
        2. Code of Conduct
        3. Whistleblowing system
        4. Third-party due diligence
        5. Internal accounting controls
        6. Training program
        7. Disciplinary sanctions
        8. Monitoring and evaluation
        
        This analysis covers pillars 1, 4, 5 based on cartography data.
        """
        total = len(df)
        if total == 0:
            return SapinIIPillarStats()
        
        # Pillar 1: Risk Mapping Coverage
        processes_covered = df['category'].nunique() if 'category' in df.columns else 0
        expected_processes = 7  # Sapin II typically covers 7-8 process types
        mapping_coverage = min(100, (processes_covered / expected_processes * 100))
        
        # Mapping depth (scenarios per process)
        mapping_depth = total / processes_covered if processes_covered > 0 else 0
        
        # Pillar 4: Third-party exposure
        # Categories involving third parties: A (Procurement), B/C (Commercial), E (M&A), F (Sponsoring)
        third_party_categories = ['A', 'B', 'C', 'E', 'F']
        if 'category' in df.columns:
            third_party_risks = len(df[df['category'].isin(third_party_categories)])
            third_party_pct = (third_party_risks / total * 100) if total > 0 else 0
        else:
            third_party_pct = 0
        
        # Pillar 5: Internal control effectiveness
        if 'score_gross' in df.columns and 'score_residual' in df.columns:
            valid_mask = df['score_gross'].notna() & df['score_residual'].notna() & (df['score_gross'] > 0)
            valid_df = df[valid_mask]
            
            if len(valid_df) > 0:
                avg_reduction = ((valid_df['score_gross'] - valid_df['score_residual']) / valid_df['score_gross'] * 100).mean()
                control_effectiveness = max(0, min(100, avg_reduction))
            else:
                control_effectiveness = 0
        else:
            control_effectiveness = 0
        
        # Overall compliance score (simplified)
        # Weighted average of measurable pillars
        overall_score = (
            mapping_coverage * 0.35 +  # Pillar 1 weight
            (100 - third_party_pct * 0.5) * 0.25 +  # Pillar 4 - lower exposure = better
            control_effectiveness * 0.40  # Pillar 5 weight
        )
        
        return SapinIIPillarStats(
            risk_mapping_coverage=round(mapping_coverage, 1),
            risk_mapping_depth=round(mapping_depth, 1),
            third_party_exposure_pct=round(third_party_pct, 1),
            internal_control_effectiveness=round(control_effectiveness, 1) if not pd.isna(control_effectiveness) else 0,
            overall_compliance_score=round(overall_score, 1)
        )


# =============================================================================
# CONVENIENCE FUNCTION
# =============================================================================

def analyze_risks(df: pd.DataFrame, config=None) -> RiskAnalysis:
    """
    Convenience function to analyze risk data.
    
    Args:
        df: DataFrame with risk data
        config: Optional JSON config (AnalysisConfiguration) or dict
        
    Returns:
        RiskAnalysis object
    """
    if config is not None and hasattr(config, 'risk_levels'):
        # JSON configuration object
        analyzer = RiskAnalyzer.from_config(config)
    elif isinstance(config, dict):
        # Dict configuration
        analyzer = RiskAnalyzer(config)
    else:
        # Default
        analyzer = RiskAnalyzer()
    
    return analyzer.analyze(df)


if __name__ == "__main__":
    # Test with sample data
    import sys
    from pathlib import Path
    
    logging.basicConfig(level=logging.INFO)
    
    lib_dir = Path(__file__).parent
    config_path = lib_dir / "analysis_config.json"
    
    if config_path.exists():
        print("=== Testing with JSON Configuration ===")
        from config_loader import load_config
        from data_loader import load_risk_data_from_config
        
        config = load_config(str(config_path))
        df, _ = load_risk_data_from_config(config)
        
        analyzer = RiskAnalyzer.from_config(config)
        analysis = analyzer.analyze(df)
    else:
        print("=== Testing with Default Configuration ===")
        from data_loader import load_risk_data
        
        test_dir = lib_dir.parent
        df, _ = load_risk_data(str(test_dir))
        
        analysis = analyze_risks(df)
    
    print("\n=== ANALYSIS SUMMARY ===")
    print(f"Total Risks: {analysis.summary.total_risks}")
    print(f"Total Entities: {analysis.summary.total_entities}")
    print(f"Avg Gross Score: {analysis.summary.avg_gross_score}")
    print(f"Avg Residual Score: {analysis.summary.avg_residual_score}")
    print(f"Risk Reduction: {analysis.summary.risk_reduction_pct}%")
    
    print("\n=== BY LEVEL ===")
    for level, stats in analysis.by_level.items():
        print(f"  {level}: {stats.count} ({stats.percentage}%)")
