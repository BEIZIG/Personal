"""
================================================================================
PDF REPORT BUILDER MODULE
================================================================================

PURPOSE:
    This module generates professional PDF reports from risk analysis data.
    The PDFs contain charts, tables, and executive summaries suitable for
    management presentations.

WHAT IT DOES:
    1. Creates multi-page PDF reports
    2. Generates pie charts for risk distribution
    3. Creates bar charts for comparisons
    4. Draws radar charts for category analysis
    5. Builds formatted tables with color coding
    6. Adds executive summary with KPIs

OUTPUT INCLUDES:
    - Title page with generation date
    - KPI cards (Total Risks, Critical, High, etc.)
    - Risk level distribution pie chart
    - Entity comparison bar charts
    - Category Risk Radar chart
    - Top Priority Risks table
    - AFA Compliance metrics table

KEY CLASSES:
    - PDFReportGenerator: Creates the PDF content
    - PDFExporter: High-level interface for exporting

EXAMPLE USAGE:
    from pdf_report_builder import PDFExporter, is_pdf_available
    
    if is_pdf_available():
        exporter = PDFExporter(output_dir='output/')
        exporter.export_analysis_pdf(
            analysis=analysis,
            df=dataframe,
            filename='risk_report.pdf'
        )

DEPENDENCIES:
    pip install reportlab  (usually pre-installed on most systems)
    
    Note: This module gracefully handles missing reportlab - it will
    just skip PDF generation if not installed.

PAGE LAYOUT:
    - Landscape A4 format for better chart visibility
    - Professional styling with consistent colors
    - Company-ready formatting

AUTHOR: Risk Management Team
VERSION: 2.0.0
================================================================================
"""

import logging
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime
from dataclasses import dataclass

logger = logging.getLogger(__name__)

# Check for reportlab availability
REPORTLAB_AVAILABLE = False
try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch, cm
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, 
        PageBreak, Image, KeepTogether, Flowable
    )
    from reportlab.graphics.shapes import Drawing, Rect, String, Line
    from reportlab.graphics.charts.barcharts import VerticalBarChart, HorizontalBarChart
    from reportlab.graphics.charts.piecharts import Pie
    from reportlab.graphics.charts.legends import Legend
    from reportlab.graphics.widgets.markers import makeMarker
    from reportlab.graphics import renderPDF
    REPORTLAB_AVAILABLE = True
except ImportError:
    logger.warning("ReportLab not available. Install: pip install reportlab")


def is_pdf_available() -> bool:
    """Check if PDF export is available."""
    return REPORTLAB_AVAILABLE


# Color definitions matching dashboard
COLORS = {
    'primary': colors.HexColor('#0066cc'),
    'secondary': colors.HexColor('#004999'),
    'success': colors.HexColor('#10b981'),
    'warning': colors.HexColor('#f59e0b'),
    'orange': colors.HexColor('#f97316'),
    'danger': colors.HexColor('#ef4444'),
    'gray': colors.HexColor('#6b7280'),
    'light_gray': colors.HexColor('#f3f4f6'),
    'dark': colors.HexColor('#1f2937'),
    'white': colors.white,
}

LEVEL_COLORS = {
    'Critical': COLORS['danger'],
    'High': COLORS['orange'],
    'Moderate': COLORS['warning'],
    'Low': COLORS['success'],
}

LEVEL_COLORS_HEX = {
    'Critical': colors.HexColor('#ef4444'),
    'High': colors.HexColor('#f97316'),
    'Moderate': colors.HexColor('#f59e0b'),
    'Low': colors.HexColor('#10b981'),
}

CHART_COLORS = [
    colors.HexColor('#0066cc'),  # Blue
    colors.HexColor('#10b981'),  # Green
    colors.HexColor('#f59e0b'),  # Yellow
    colors.HexColor('#ef4444'),  # Red
    colors.HexColor('#8b5cf6'),  # Purple
    colors.HexColor('#ec4899'),  # Pink
    colors.HexColor('#14b8a6'),  # Teal
    colors.HexColor('#f97316'),  # Orange
]


class PDFReportGenerator:
    """
    Generates professional PDF reports from risk analysis data.
    
    Usage:
        generator = PDFReportGenerator()
        generator.generate_report(analysis, df, 'output/report.pdf')
    """
    
    def __init__(self):
        """Initialize the PDF generator."""
        if not REPORTLAB_AVAILABLE:
            raise ImportError("ReportLab is required. Install: pip install reportlab")
        
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
        self.elements = []
        
    def _add_style(self, name, **kwargs):
        """Add or update a custom style."""
        try:
            self.styles.add(ParagraphStyle(name=name, **kwargs))
        except KeyError:
            # Style already exists, update it
            pass
    
    def _setup_custom_styles(self):
        """Set up custom paragraph styles."""
        self._add_style(
            'ReportTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            textColor=COLORS['primary'],
            spaceAfter=20,
            alignment=1  # Center
        )
        
        self._add_style(
            'Subtitle',
            parent=self.styles['Normal'],
            fontSize=12,
            textColor=COLORS['gray'],
            spaceAfter=30,
            alignment=1  # Center
        )
        
        self._add_style(
            'SectionHeader',
            parent=self.styles['Heading2'],
            fontSize=14,
            textColor=COLORS['primary'],
            spaceBefore=20,
            spaceAfter=10,
            borderPadding=5,
        )
        
        self._add_style(
            'KPIValue',
            parent=self.styles['Normal'],
            fontSize=20,
            textColor=COLORS['primary'],
            alignment=1,  # Center
        )
        
        self._add_style(
            'KPILabel',
            parent=self.styles['Normal'],
            fontSize=9,
            textColor=COLORS['gray'],
            alignment=1,  # Center
        )
    
    def _create_pie_chart(self, data: Dict[str, int], width=280, height=200, title="") -> Drawing:
        """Create a pie chart with legend."""
        drawing = Drawing(width, height)
        
        # Filter out zero values
        filtered_data = {k: v for k, v in data.items() if v > 0}
        if not filtered_data:
            return drawing
        
        # Create pie
        pie = Pie()
        pie.x = 70
        pie.y = 30
        pie.width = 120
        pie.height = 120
        pie.data = list(filtered_data.values())
        pie.labels = [f"{k}\n({v})" for k, v in filtered_data.items()]
        
        # Assign colors based on level
        level_order = ['Low', 'Moderate', 'High', 'Critical']
        for i, label in enumerate(filtered_data.keys()):
            clean_label = label.replace('🔴 ', '').replace('🟠 ', '').replace('🟡 ', '').replace('🟢 ', '')
            if clean_label in LEVEL_COLORS_HEX:
                pie.slices[i].fillColor = LEVEL_COLORS_HEX[clean_label]
            else:
                pie.slices[i].fillColor = CHART_COLORS[i % len(CHART_COLORS)]
            pie.slices[i].strokeWidth = 1
            pie.slices[i].strokeColor = colors.white
        
        # Style labels
        pie.sideLabels = True
        pie.simpleLabels = False
        pie.slices.fontName = 'Helvetica'
        pie.slices.fontSize = 8
        
        drawing.add(pie)
        
        # Add title
        if title:
            drawing.add(String(width/2, height - 10, title, 
                               textAnchor='middle', fontSize=10, fontName='Helvetica-Bold'))
        
        return drawing
    
    def _create_bar_chart(self, labels: List[str], data: List[List[float]], 
                          legend_names: List[str] = None, width=500, height=180,
                          title="", bar_colors=None) -> Drawing:
        """Create a vertical bar chart."""
        drawing = Drawing(width, height)
        
        if not data or not data[0]:
            return drawing
        
        bc = VerticalBarChart()
        bc.x = 60
        bc.y = 40
        bc.width = width - 100
        bc.height = height - 70
        
        bc.data = data
        bc.categoryAxis.categoryNames = labels
        
        # Style
        # Handle empty or all-zero data
        max_val = max(max(d) for d in data) if data and any(max(d) > 0 for d in data) else 10
        bc.valueAxis.valueMin = 0
        bc.valueAxis.valueMax = max(max_val * 1.2, 1)  # Ensure at least 1
        bc.valueAxis.valueStep = max(bc.valueAxis.valueMax / 5, 0.2)
        
        bc.categoryAxis.labels.boxAnchor = 'ne'
        bc.categoryAxis.labels.dx = -5
        bc.categoryAxis.labels.dy = -5
        bc.categoryAxis.labels.angle = 30
        bc.categoryAxis.labels.fontSize = 7
        bc.categoryAxis.labels.fontName = 'Helvetica'
        
        bc.valueAxis.labels.fontSize = 8
        bc.valueAxis.labels.fontName = 'Helvetica'
        
        # Bar colors
        if bar_colors:
            for i, color in enumerate(bar_colors):
                if i < len(bc.bars):
                    bc.bars[i].fillColor = color
        else:
            bc.bars[0].fillColor = COLORS['primary']
            if len(data) > 1:
                bc.bars[1].fillColor = COLORS['success']
        
        bc.barWidth = 15
        bc.groupSpacing = 10
        bc.barSpacing = 2
        
        drawing.add(bc)
        
        # Add title
        if title:
            drawing.add(String(width/2, height - 5, title,
                               textAnchor='middle', fontSize=10, fontName='Helvetica-Bold'))
        
        # Add legend if multiple series
        if legend_names and len(legend_names) > 1:
            legend = Legend()
            legend.x = width - 120
            legend.y = height - 25
            legend.dx = 8
            legend.dy = 8
            legend.fontSize = 7
            legend.fontName = 'Helvetica'
            legend.alignment = 'right'
            legend.columnMaximum = 1
            legend.colorNamePairs = [
                (bar_colors[i] if bar_colors and i < len(bar_colors) else CHART_COLORS[i], name) 
                for i, name in enumerate(legend_names)
            ]
            drawing.add(legend)
        
        return drawing
    
    def _create_horizontal_bar_chart(self, labels: List[str], values: List[float],
                                      width=400, height=180, title="",
                                      bar_colors=None) -> Drawing:
        """Create a horizontal bar chart for level distribution."""
        drawing = Drawing(width, height)
        
        if not values:
            return drawing
        
        bc = HorizontalBarChart()
        bc.x = 80
        bc.y = 20
        bc.width = width - 120
        bc.height = height - 50
        
        bc.data = [values]
        bc.categoryAxis.categoryNames = labels
        
        bc.valueAxis.valueMin = 0
        bc.valueAxis.valueMax = max(values) * 1.2 if max(values) > 0 else 10
        
        bc.categoryAxis.labels.fontSize = 9
        bc.categoryAxis.labels.fontName = 'Helvetica'
        bc.valueAxis.labels.fontSize = 8
        
        # Apply colors per bar
        for i, label in enumerate(labels):
            clean_label = label.replace('🔴 ', '').replace('🟠 ', '').replace('🟡 ', '').replace('🟢 ', '')
            if clean_label in LEVEL_COLORS_HEX:
                bc.bars[0].fillColor = None  # Will use per-slice
                bc.bars[(0, i)].fillColor = LEVEL_COLORS_HEX.get(clean_label, CHART_COLORS[0])
            elif bar_colors and i < len(bar_colors):
                bc.bars[(0, i)].fillColor = bar_colors[i]
        
        bc.barWidth = 20
        
        drawing.add(bc)
        
        if title:
            drawing.add(String(width/2, height - 5, title,
                               textAnchor='middle', fontSize=10, fontName='Helvetica-Bold'))
        
        return drawing
    
    def _create_gauge_chart(self, value: float, max_val: float = 100, 
                            width=120, height=80, label="") -> Drawing:
        """Create a simple gauge/progress indicator."""
        drawing = Drawing(width, height)
        
        # Background bar
        drawing.add(Rect(10, 30, width - 20, 20, 
                        fillColor=colors.HexColor('#e5e7eb'), 
                        strokeColor=None))
        
        # Progress bar
        progress_width = min((value / max_val) * (width - 20), width - 20)
        fill_color = COLORS['success'] if value < 50 else (COLORS['warning'] if value < 75 else COLORS['danger'])
        drawing.add(Rect(10, 30, progress_width, 20,
                        fillColor=fill_color,
                        strokeColor=None))
        
        # Value label
        drawing.add(String(width/2, 55, f"{value:.0f}%",
                          textAnchor='middle', fontSize=12, fontName='Helvetica-Bold'))
        
        # Description
        if label:
            drawing.add(String(width/2, 15, label,
                              textAnchor='middle', fontSize=8, fontName='Helvetica'))
        
        return drawing
    
    def _create_radar_chart(self, labels: List[str], datasets: List[Dict], 
                            width=350, height=280, title="", max_value=16) -> Drawing:
        """
        Create a radar/spider chart.
        
        Args:
            labels: List of axis labels (categories)
            datasets: List of dicts with 'name', 'values', 'color', 'fill_color'
            width: Chart width
            height: Chart height
            title: Chart title
            max_value: Maximum value on each axis
        """
        import math
        
        drawing = Drawing(width, height)
        
        if not labels or not datasets:
            return drawing
        
        n = len(labels)
        if n < 3:
            return drawing  # Need at least 3 points for radar
        
        # Chart center and radius
        cx = width / 2
        cy = (height - 30) / 2 + 10  # Leave room for title at top
        radius = min(width, height - 40) / 2 - 30
        
        # Calculate angles for each axis (starting from top, going clockwise)
        angles = []
        for i in range(n):
            angle = (2 * math.pi * i / n) - (math.pi / 2)  # Start from top
            angles.append(angle)
        
        # Draw grid circles (background)
        grid_levels = [0.25, 0.5, 0.75, 1.0]
        for level in grid_levels:
            r = radius * level
            # Draw circle using line segments
            segments = 60
            from reportlab.graphics.shapes import Polygon
            circle_points = []
            for j in range(segments + 1):
                a = 2 * math.pi * j / segments
                px = cx + r * math.cos(a)
                py = cy + r * math.sin(a)
                circle_points.extend([px, py])
            
            # Just draw as thin lines connecting points
            for j in range(segments):
                a1 = 2 * math.pi * j / segments
                a2 = 2 * math.pi * (j + 1) / segments
                x1, y1 = cx + r * math.cos(a1), cy + r * math.sin(a1)
                x2, y2 = cx + r * math.cos(a2), cy + r * math.sin(a2)
                drawing.add(Line(x1, y1, x2, y2, 
                                strokeColor=colors.HexColor('#e5e7eb'), 
                                strokeWidth=0.5))
        
        # Draw axis lines and labels
        for i, angle in enumerate(angles):
            # Axis line from center to edge
            x_end = cx + radius * math.cos(angle)
            y_end = cy + radius * math.sin(angle)
            drawing.add(Line(cx, cy, x_end, y_end, 
                            strokeColor=colors.HexColor('#d1d5db'), 
                            strokeWidth=1))
            
            # Label position (slightly beyond the edge)
            label_r = radius + 15
            lx = cx + label_r * math.cos(angle)
            ly = cy + label_r * math.sin(angle)
            
            # Adjust text anchor based on position
            if angle < -math.pi/4 and angle > -3*math.pi/4:
                anchor = 'middle'  # Top
            elif angle >= -math.pi/4 and angle <= math.pi/4:
                anchor = 'start'   # Right
            elif angle > 3*math.pi/4 or angle < -3*math.pi/4:
                anchor = 'end'     # Left
            else:
                anchor = 'middle'  # Bottom
            
            # Truncate label
            label_text = labels[i][:10] if len(labels[i]) > 10 else labels[i]
            drawing.add(String(lx, ly, label_text, 
                              textAnchor=anchor, 
                              fontSize=7, 
                              fontName='Helvetica'))
        
        # Draw datasets (filled polygons)
        from reportlab.graphics.shapes import Polygon
        
        for dataset in datasets:
            values = dataset.get('values', [])
            fill_color = dataset.get('fill_color', colors.Color(0.1, 0.5, 0.8, alpha=0.2))
            stroke_color = dataset.get('color', COLORS['primary'])
            
            if len(values) != n:
                continue
            
            # Calculate points for polygon
            points = []
            for i, val in enumerate(values):
                # Normalize value to radius
                normalized = min(val / max_value, 1.0) if max_value > 0 else 0
                r = radius * normalized
                px = cx + r * math.cos(angles[i])
                py = cy + r * math.sin(angles[i])
                points.extend([px, py])
            
            # Draw filled polygon
            polygon = Polygon(points, 
                             fillColor=fill_color,
                             strokeColor=stroke_color,
                             strokeWidth=2)
            drawing.add(polygon)
            
            # Draw data points
            for i, val in enumerate(values):
                normalized = min(val / max_value, 1.0) if max_value > 0 else 0
                r = radius * normalized
                px = cx + r * math.cos(angles[i])
                py = cy + r * math.sin(angles[i])
                
                # Draw point marker
                from reportlab.graphics.shapes import Circle
                drawing.add(Circle(px, py, 3, 
                                  fillColor=stroke_color, 
                                  strokeColor=colors.white,
                                  strokeWidth=1))
        
        # Add title
        if title:
            drawing.add(String(width/2, height - 10, title,
                              textAnchor='middle', fontSize=10, fontName='Helvetica-Bold'))
        
        # Add legend at bottom
        legend_y = 10
        legend_x = width / 2 - 60
        for i, dataset in enumerate(datasets):
            name = dataset.get('name', f'Series {i+1}')
            color = dataset.get('color', COLORS['primary'])
            
            # Legend marker
            drawing.add(Rect(legend_x + i * 80, legend_y, 12, 8, 
                            fillColor=color, strokeColor=None))
            drawing.add(String(legend_x + i * 80 + 16, legend_y + 1, name,
                              textAnchor='start', fontSize=8, fontName='Helvetica'))
        
        return drawing
    
    def _add_header(self, title: str, subtitle: str = None):
        """Add report header."""
        self.elements.append(Paragraph(title, self.styles['ReportTitle']))
        if subtitle:
            self.elements.append(Paragraph(subtitle, self.styles['Subtitle']))
        
        # Generation timestamp
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M')
        self.elements.append(Paragraph(
            f"Generated: {timestamp}",
            self.styles['Subtitle']
        ))
        self.elements.append(Spacer(1, 20))
    
    def _add_kpi_section(self, analysis):
        """Add KPI cards section with visual indicators."""
        self.elements.append(Paragraph(
            "📈 Key Performance Indicators",
            self.styles['SectionHeader']
        ))
        
        s = analysis.summary
        m = analysis.mitigation
        rt = analysis.risk_trends if hasattr(analysis, 'risk_trends') else None
        
        # Get level counts
        critical = 0
        high = 0
        moderate = 0
        low = 0
        for key, stats in analysis.by_level.items():
            if 'Critical' in key:
                critical = stats.count
            elif 'High' in key:
                high = stats.count
            elif 'Moderate' in key:
                moderate = stats.count
            elif 'Low' in key:
                low = stats.count
        
        # Calculate appetite breach
        appetite_breach = rt.appetite_breach_rate if rt else 0
        mitigated = m.improved if m else 0
        mitigation_rate = (mitigated / s.total_risks * 100) if s.total_risks > 0 else 0
        
        # Create visual KPI cards using a table with colored backgrounds
        kpi_cards = []
        
        # Row 1: Main metrics with large numbers
        kpi_row1 = [
            self._create_kpi_card("Total Risks", str(s.total_risks), COLORS['primary']),
            self._create_kpi_card("Critical", str(critical), COLORS['danger']),
            self._create_kpi_card("High", str(high), COLORS['orange']),
            self._create_kpi_card("Moderate", str(moderate), COLORS['warning']),
            self._create_kpi_card("Low", str(low), COLORS['success']),
        ]
        
        card_table1 = Table([kpi_row1], colWidths=[1.7*inch]*5)
        card_table1.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))
        self.elements.append(card_table1)
        self.elements.append(Spacer(1, 10))
        
        # Row 2: Performance indicators with gauges
        gauge1 = self._create_gauge_chart(appetite_breach, 100, 140, 70, "Appetite Breach")
        gauge2 = self._create_gauge_chart(mitigation_rate, 100, 140, 70, "Mitigation Rate")
        gauge3 = self._create_gauge_chart(abs(s.risk_reduction_pct), 100, 140, 70, "Risk Reduction")
        
        gauge_table = Table([[gauge1, gauge2, gauge3, 
                             self._create_kpi_card("Entities", str(s.total_entities), COLORS['secondary'])]], 
                           colWidths=[1.8*inch, 1.8*inch, 1.8*inch, 1.7*inch])
        gauge_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))
        self.elements.append(gauge_table)
        self.elements.append(Spacer(1, 20))
    
    def _create_kpi_card(self, label: str, value: str, color) -> Drawing:
        """Create a KPI card drawing."""
        w, h = 100, 60
        d = Drawing(w, h)
        
        # Background rounded rectangle
        d.add(Rect(5, 5, w-10, h-10, 
                   fillColor=color, 
                   strokeColor=None,
                   rx=5, ry=5))
        
        # Value text (large)
        d.add(String(w/2, h/2 + 5, value, 
                    textAnchor='middle', 
                    fontSize=20, 
                    fontName='Helvetica-Bold',
                    fillColor=colors.white))
        
        # Label text
        d.add(String(w/2, h/2 - 15, label, 
                    textAnchor='middle', 
                    fontSize=9, 
                    fontName='Helvetica',
                    fillColor=colors.white))
        
        return d
    
    def _add_level_distribution(self, analysis):
        """Add risk level distribution section with pie chart and table."""
        self.elements.append(Paragraph(
            "📊 Risk Level Distribution",
            self.styles['SectionHeader']
        ))
        
        # Collect level data
        level_counts = {}
        level_order = ['Low', 'Moderate', 'High', 'Critical']
        
        for key, stats in analysis.by_level.items():
            clean_key = key.replace('🔴 ', '').replace('🟠 ', '').replace('🟡 ', '').replace('🟢 ', '')
            level_counts[clean_key] = stats.count
        
        # Create pie chart
        pie_chart = self._create_pie_chart(
            level_counts, 
            width=300, 
            height=180,
            title="Risk Level Distribution"
        )
        
        # Create horizontal bar chart
        labels = []
        values = []
        for level in level_order:
            if level in level_counts:
                labels.append(level)
                values.append(level_counts[level])
        
        bar_chart = self._create_horizontal_bar_chart(
            labels=labels,
            values=values,
            width=400,
            height=160,
            title="Risk Count by Level"
        )
        
        # Layout: charts side by side
        chart_table = Table([[pie_chart, bar_chart]], colWidths=[4*inch, 5.5*inch])
        chart_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ]))
        self.elements.append(chart_table)
        self.elements.append(Spacer(1, 10))
        
        # Data table
        level_data = [['Level', 'Count', 'Percentage']]
        total = sum(level_counts.values())
        
        for level in level_order:
            if level in level_counts:
                count = level_counts[level]
                pct = (count / total * 100) if total > 0 else 0
                level_data.append([level, str(count), f"{pct:.1f}%"])
        
        level_table = Table(level_data, colWidths=[2*inch, 1.5*inch, 1.5*inch])
        level_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), COLORS['primary']),
            ('TEXTCOLOR', (0, 0), (-1, 0), COLORS['white']),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 0.5, COLORS['light_gray']),
            # Row colors based on level
            ('BACKGROUND', (0, 1), (-1, 1), colors.HexColor('#dcfce7')),  # Low
            ('BACKGROUND', (0, 2), (-1, 2), colors.HexColor('#fef9c3')),  # Moderate
            ('BACKGROUND', (0, 3), (-1, 3), colors.HexColor('#fed7aa')),  # High
            ('BACKGROUND', (0, 4), (-1, 4), colors.HexColor('#fecaca')),  # Critical
        ]))
        
        self.elements.append(level_table)
        self.elements.append(Spacer(1, 20))
    
    def _add_entity_summary(self, analysis):
        """Add entity summary with bar chart and table."""
        self.elements.append(Paragraph(
            "🏢 Entity Summary",
            self.styles['SectionHeader']
        ))
        
        # Prepare data for chart
        entity_names = []
        gross_scores = []
        residual_scores = []
        
        for name, stats in sorted(analysis.by_entity.items()):
            entity_names.append(name[:15])  # Truncate for chart
            gross_scores.append(stats.avg_gross_score)
            residual_scores.append(stats.avg_residual_score)
        
        # Create Gross vs Residual bar chart
        if entity_names:
            comparison_chart = self._create_bar_chart(
                labels=entity_names,
                data=[gross_scores, residual_scores],
                legend_names=['Gross Score', 'Residual Score'],
                width=700,
                height=180,
                title="Gross vs Residual Score by Entity",
                bar_colors=[COLORS['orange'], COLORS['success']]
            )
            self.elements.append(comparison_chart)
            self.elements.append(Spacer(1, 15))
        
        # Data table
        entity_data = [['Entity', 'Risks', 'Critical', 'High', 'Gross Avg', 'Residual Avg', 'Reduction']]
        
        for name, stats in sorted(analysis.by_entity.items()):
            entity_data.append([
                name[:30],  # Truncate long names
                str(stats.total_risks),
                str(stats.critical_count),
                str(stats.high_count),
                f"{stats.avg_gross_score:.1f}",
                f"{stats.avg_residual_score:.1f}",
                f"{stats.risk_reduction_pct:+.1f}%"
            ])
        
        entity_table = Table(entity_data, colWidths=[2.2*inch, 0.6*inch, 0.7*inch, 0.6*inch, 0.9*inch, 1*inch, 0.9*inch])
        entity_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), COLORS['primary']),
            ('TEXTCOLOR', (0, 0), (-1, 0), COLORS['white']),
            ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 0.5, COLORS['light_gray']),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [COLORS['white'], COLORS['light_gray']]),
        ]))
        
        self.elements.append(entity_table)
        self.elements.append(Spacer(1, 20))
    
    def _add_category_summary(self, analysis):
        """Add category/process summary with radar chart and bar chart."""
        self.elements.append(Paragraph(
            "📁 Risk by AFA Category",
            self.styles['SectionHeader']
        ))
        
        # Prepare data for charts
        cat_names = []
        cat_labels = []
        cat_counts = []
        gross_avgs = []
        residual_avgs = []
        
        for code, stats in sorted(analysis.by_category.items()):
            cat_names.append(f"{code} {stats.category_name[:10]}")
            cat_labels.append(stats.category_name[:12])
            cat_counts.append(stats.count)
            gross_avgs.append(stats.avg_gross_score)
            residual_avgs.append(stats.avg_residual_score)
        
        # Create radar chart and bar chart side by side
        if cat_names and len(cat_names) >= 3:
            # Radar chart with Gross vs Residual
            radar_datasets = [
                {
                    'name': 'Gross',
                    'values': gross_avgs,
                    'color': COLORS['orange'],
                    'fill_color': colors.Color(0.976, 0.451, 0.086, alpha=0.2)  # Orange with alpha
                },
                {
                    'name': 'Residual',
                    'values': residual_avgs,
                    'color': COLORS['success'],
                    'fill_color': colors.Color(0.063, 0.725, 0.506, alpha=0.2)  # Green with alpha
                }
            ]
            
            radar_chart = self._create_radar_chart(
                labels=cat_labels,
                datasets=radar_datasets,
                width=350,
                height=280,
                title="🕸️ Category Risk Radar",
                max_value=16
            )
            
            # Bar chart
            bar_chart = self._create_bar_chart(
                labels=cat_names,
                data=[gross_avgs, residual_avgs],
                legend_names=['Gross Score', 'Residual Score'],
                width=450,
                height=220,
                title="Average Risk Score by Category",
                bar_colors=[COLORS['warning'], COLORS['success']]
            )
            
            # Layout: Radar and Bar chart side by side
            chart_table = Table([[radar_chart, bar_chart]], colWidths=[4.5*inch, 6*inch])
            chart_table.setStyle(TableStyle([
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ]))
            self.elements.append(chart_table)
            self.elements.append(Spacer(1, 15))
        elif cat_names:
            # Fallback to just bar chart if less than 3 categories
            cat_chart = self._create_bar_chart(
                labels=cat_names,
                data=[gross_avgs, residual_avgs],
                legend_names=['Gross Score', 'Residual Score'],
                width=700,
                height=180,
                title="Average Risk Score by Category (Gross vs Residual)",
                bar_colors=[COLORS['warning'], COLORS['success']]
            )
            self.elements.append(cat_chart)
            self.elements.append(Spacer(1, 15))
        
        # Data table
        cat_data = [['Code', 'Category', 'Risks', 'Gross Avg', 'Residual Avg', 'Reduction']]
        
        for code, stats in sorted(analysis.by_category.items()):
            reduction = 0
            if stats.avg_gross_score > 0:
                reduction = ((stats.avg_gross_score - stats.avg_residual_score) / stats.avg_gross_score) * 100
            
            cat_data.append([
                code,
                stats.category_name[:25],
                str(stats.count),
                f"{stats.avg_gross_score:.1f}",
                f"{stats.avg_residual_score:.1f}",
                f"{reduction:+.0f}%"
            ])
        
        cat_table = Table(cat_data, colWidths=[0.5*inch, 2.5*inch, 0.7*inch, 1*inch, 1.2*inch, 1*inch])
        cat_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), COLORS['primary']),
            ('TEXTCOLOR', (0, 0), (-1, 0), COLORS['white']),
            ('ALIGN', (0, 0), (0, -1), 'CENTER'),
            ('ALIGN', (2, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 0.5, COLORS['light_gray']),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [COLORS['white'], COLORS['light_gray']]),
        ]))
        
        self.elements.append(cat_table)
        self.elements.append(Spacer(1, 20))
    
    def _add_top_risks(self, analysis, max_risks: int = 10):
        """Add top critical/high risks section."""
        self.elements.append(Paragraph(
            "🎯 Top Priority Risks (Highest Residual)",
            self.styles['SectionHeader']
        ))
        
        risk_data = [['ID', 'Entity', 'Scenario', 'Gross', 'Residual', 'Level']]
        
        for risk in analysis.top_risks[:max_risks]:
            level = risk.get('level_residual', '').replace('🔴 ', '').replace('🟠 ', '').replace('🟡 ', '').replace('🟢 ', '')
            scenario = str(risk.get('scenario', ''))[:40]
            if len(str(risk.get('scenario', ''))) > 40:
                scenario += '...'
            
            risk_data.append([
                risk.get('risk_id', ''),
                str(risk.get('entity', ''))[:20],
                scenario,
                str(risk.get('score_gross', '')),
                str(risk.get('score_residual', '')),
                level
            ])
        
        risk_table = Table(risk_data, colWidths=[0.5*inch, 1.3*inch, 3*inch, 0.6*inch, 0.7*inch, 0.9*inch])
        risk_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), COLORS['danger']),
            ('TEXTCOLOR', (0, 0), (-1, 0), COLORS['white']),
            ('ALIGN', (0, 0), (0, -1), 'CENTER'),
            ('ALIGN', (3, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('GRID', (0, 0), (-1, -1), 0.5, COLORS['light_gray']),
        ]))
        
        self.elements.append(risk_table)
        self.elements.append(Spacer(1, 20))
    
    def _add_afa_compliance(self, analysis):
        """Add AFA compliance metrics if available."""
        if not hasattr(analysis, 'afa_compliance') or not analysis.afa_compliance:
            return
        
        self.elements.append(PageBreak())
        self.elements.append(Paragraph(
            "📋 AFA / Sapin II Compliance Metrics",
            self.styles['SectionHeader']
        ))
        
        afa = analysis.afa_compliance
        
        compliance_data = [
            ['Metric', 'Value', 'Status'],
            ['Processes Covered', str(afa.total_processes_covered), '✓' if afa.total_processes_covered >= 7 else '⚠'],
            ['Scenarios Mapped', str(afa.total_scenarios_mapped), '✓' if afa.total_scenarios_mapped > 0 else '✗'],
            ['Control Coverage', f"{afa.control_coverage_rate:.1f}%", '✓' if afa.control_coverage_rate >= 80 else '⚠'],
            ['Remediation Rate', f"{afa.remediation_coverage_rate:.1f}%", '✓' if afa.remediation_coverage_rate >= 80 else '⚠'],
            ['Risk Reduction Avg', f"{afa.avg_risk_reduction:.1f}%", '✓' if afa.avg_risk_reduction >= 30 else '⚠'],
        ]
        
        afa_table = Table(compliance_data, colWidths=[2.5*inch, 1.5*inch, 0.8*inch])
        afa_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), COLORS['primary']),
            ('TEXTCOLOR', (0, 0), (-1, 0), COLORS['white']),
            ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 0.5, COLORS['light_gray']),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [COLORS['white'], COLORS['light_gray']]),
        ]))
        
        self.elements.append(afa_table)
    
    def _add_footer(self):
        """Add report footer."""
        self.elements.append(Spacer(1, 40))
        self.elements.append(Paragraph(
            "─" * 80,
            self.styles['Normal']
        ))
        self.elements.append(Paragraph(
            "<i>Confidential - Internal Use Only | Generated by Risk Cartography Tool | AFA/Sapin II Compliance</i>",
            ParagraphStyle(
                name='Footer',
                parent=self.styles['Normal'],
                fontSize=8,
                textColor=COLORS['gray'],
                alignment=1  # Center
            )
        ))
    
    def generate_report(
        self,
        analysis,
        df=None,
        output_path: str = 'risk_report.pdf',
        title: str = 'Risk Cartography Report',
        subtitle: str = 'AFA/Sapin II Corruption Risk Analysis'
    ) -> str:
        """
        Generate complete PDF report.
        
        Args:
            analysis: RiskAnalysis object
            df: Optional DataFrame with risk data
            output_path: Output file path
            title: Report title
            subtitle: Report subtitle
            
        Returns:
            Path to generated PDF
        """
        self.elements = []
        
        # Build document
        doc = SimpleDocTemplate(
            output_path,
            pagesize=landscape(A4),
            rightMargin=0.5*inch,
            leftMargin=0.5*inch,
            topMargin=0.5*inch,
            bottomMargin=0.5*inch
        )
        
        # Add sections
        self._add_header(title, subtitle)
        self._add_kpi_section(analysis)
        self._add_level_distribution(analysis)
        
        self.elements.append(PageBreak())
        
        self._add_entity_summary(analysis)
        self._add_category_summary(analysis)
        
        # Top risks continues on same page if space available
        self._add_top_risks(analysis)
        self._add_afa_compliance(analysis)
        self._add_footer()
        
        # Generate PDF
        doc.build(self.elements)
        logger.info(f"PDF report generated: {output_path}")
        
        return output_path


class PDFExporter:
    """
    High-level PDF export interface.
    
    Usage:
        exporter = PDFExporter(output_dir='output')
        exporter.export_analysis_pdf(analysis, df)
    """
    
    def __init__(self, output_dir: str):
        """Initialize exporter."""
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.exported_files: List[str] = []
    
    def is_available(self) -> bool:
        """Check if PDF export is available."""
        return REPORTLAB_AVAILABLE
    
    def export_analysis_pdf(
        self,
        analysis,
        df=None,
        filename: str = 'risk_report.pdf',
        title: str = None,
        entity_name: str = None
    ) -> Optional[str]:
        """
        Export analysis to PDF.
        
        Args:
            analysis: RiskAnalysis object
            df: Optional DataFrame
            filename: Output filename
            title: Custom title
            entity_name: Entity name for entity-specific reports
            
        Returns:
            Path to PDF or None
        """
        if not self.is_available():
            logger.warning("PDF export not available. Install: pip install reportlab")
            return None
        
        try:
            generator = PDFReportGenerator()
            
            output_path = str(self.output_dir / filename)
            
            # Customize title for entity reports
            if entity_name:
                title = title or f"{entity_name} - Risk Report"
            else:
                title = title or "Risk Cartography Report"
            
            result = generator.generate_report(
                analysis=analysis,
                df=df,
                output_path=output_path,
                title=title
            )
            
            self.exported_files.append(result)
            return result
            
        except Exception as e:
            logger.error(f"PDF export failed: {e}")
            return None
    
    def export_html_file_to_pdf(self, html_filepath: str, pdf_filename: str = None) -> Optional[str]:
        """
        Note: HTML to PDF conversion requires WeasyPrint which has system dependencies.
        This method provides a fallback message.
        
        For HTML files, use the browser's Print to PDF feature, or install WeasyPrint:
            pip install weasyprint
            
        System requirements for WeasyPrint:
            - Linux: sudo apt install libpango-1.0-0 libpangocairo-1.0-0
            - Mac: brew install pango
            - Windows: GTK3 runtime
        """
        logger.warning("HTML to PDF conversion requires WeasyPrint with system libraries.")
        logger.info("Alternative: Open HTML in browser and use Print > Save as PDF")
        return None


def generate_pdf_report(analysis, df=None, output_dir: str = '.', filename: str = 'risk_report.pdf') -> Optional[str]:
    """
    Convenience function to generate PDF report.
    
    Args:
        analysis: RiskAnalysis object
        df: Optional DataFrame
        output_dir: Output directory
        filename: Output filename
        
    Returns:
        Path to PDF or None
    """
    exporter = PDFExporter(output_dir)
    return exporter.export_analysis_pdf(analysis, df, filename)


# Quick test
if __name__ == '__main__':
    print(f"PDF Available: {is_pdf_available()}")
    print(f"ReportLab: {REPORTLAB_AVAILABLE}")
