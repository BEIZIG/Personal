#!/usr/bin/env python3
"""
DIAGNOSTIC SCRIPT - Run this to check your environment
Usage: python diagnose.py
"""

import sys
import os

def check_item(name, condition, fix_hint=""):
    """Check a condition and print result."""
    status = "[OK]" if condition else "[FAIL]"
    print(f"{status} {name}")
    if not condition and fix_hint:
        print(f"     FIX: {fix_hint}")
    return condition

def main():
    print("=" * 60)
    print("  RISK CARTOGRAPHY - DIAGNOSTIC CHECK")
    print("=" * 60)
    print()
    
    all_ok = True
    
    # 1. Python Version
    print("[1] PYTHON VERSION")
    py_version = sys.version_info
    version_ok = py_version.major == 3 and py_version.minor >= 6
    all_ok &= check_item(
        f"Python {py_version.major}.{py_version.minor}.{py_version.micro}",
        version_ok,
        "Python 3.6+ required. Download from python.org"
    )
    print()
    
    # 2. Required Packages
    print("[2] REQUIRED PACKAGES")
    packages = ['pandas', 'openpyxl', 'reportlab', 'xlsxwriter']
    for pkg in packages:
        try:
            module = __import__(pkg)
            version = getattr(module, '__version__', 'unknown')
            all_ok &= check_item(f"{pkg} ({version})", True)
        except ImportError:
            all_ok &= check_item(f"{pkg}", False, f"pip install {pkg}")
    
    # Optional packages
    print("\n[2b] OPTIONAL PACKAGES (for Web UI)")
    try:
        import streamlit
        check_item(f"streamlit ({streamlit.__version__})", True)
    except ImportError:
        print("[INFO] streamlit not installed - CLI will work, Web UI won't")
        print("       FIX: pip install streamlit (requires Python 3.8+)")
    print()
    
    # 3. Directory Structure
    print("[3] DIRECTORY STRUCTURE")
    from pathlib import Path
    app_dir = Path(__file__).parent
    
    dirs_to_check = ['lib', 'config', 'input', 'output', 'samples']
    for d in dirs_to_check:
        exists = (app_dir / d).exists()
        all_ok &= check_item(f"{d}/", exists, f"Create folder: {d}")
    print()
    
    # 4. Required Files
    print("[4] REQUIRED FILES")
    files_to_check = [
        'app.py',
        'lib/run_analysis.py',
        'lib/risk_analyzer.py',
        'lib/excel_reader.py',
        'lib/dashboard_builder.py',
        'lib/powerbi_exporter.py',
        'lib/config_manager.py',
        'lib/pdf_report_builder.py',
        'config/column_mapping.json'
    ]
    for f in files_to_check:
        exists = (app_dir / f).exists()
        all_ok &= check_item(f, exists, f"Missing file: {f}")
    print()
    
    # 5. Encoding Settings
    print("[5] ENCODING SETTINGS")
    encoding_ok = True
    
    # Check environment variables
    pythonioencoding = os.environ.get('PYTHONIOENCODING', 'not set')
    pythonutf8 = os.environ.get('PYTHONUTF8', 'not set')
    print(f"     PYTHONIOENCODING = {pythonioencoding}")
    print(f"     PYTHONUTF8 = {pythonutf8}")
    
    # Test encoding
    try:
        test_str = "Test accents: cafe resume naive"
        encoded = test_str.encode('utf-8')
        decoded = encoded.decode('utf-8')
        check_item("UTF-8 encoding works", True)
    except Exception as e:
        check_item("UTF-8 encoding", False, str(e))
        encoding_ok = False
    
    # Test file writing
    try:
        test_file = app_dir / 'output' / '_test_encoding.txt'
        with open(test_file, 'w', encoding='utf-8') as f:
            f.write("Test: cafe, resume, naive\n")
        test_file.unlink()  # Delete test file
        check_item("File writing with UTF-8", True)
    except Exception as e:
        check_item("File writing", False, str(e))
        encoding_ok = False
    
    all_ok &= encoding_ok
    print()
    
    # 6. Sample Data
    print("[6] SAMPLE DATA")
    samples = list((app_dir / 'samples').glob('*.xlsx'))
    if samples:
        for s in samples:
            print(f"     Found: {s.name}")
        check_item(f"Sample files ({len(samples)} found)", True)
    else:
        check_item("Sample files", False, "No .xlsx files in samples/")
        all_ok = False
    print()
    
    # 7. Config Validation
    print("[7] CONFIG VALIDATION")
    try:
        import json
        config_path = app_dir / 'config' / 'column_mapping.json'
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        check_item(f"column_mapping.json ({len(config)} columns)", True)
    except FileNotFoundError:
        check_item("column_mapping.json", False, "File not found. Run Admin mode to create it.")
        all_ok = False
    except json.JSONDecodeError as e:
        check_item("column_mapping.json", False, f"Invalid JSON: {e}")
        all_ok = False
    except Exception as e:
        check_item("column_mapping.json", False, str(e))
        all_ok = False
    print()
    
    # Summary
    print("=" * 60)
    if all_ok:
        print("  ALL CHECKS PASSED!")
        print("  You can run: python -m streamlit run app.py")
    else:
        print("  SOME CHECKS FAILED")
        print("  Please fix the issues above and run this script again.")
    print("=" * 60)
    
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
