#!/usr/bin/env python3
"""
PLAN B: Simple Excel Risk Cartography Solution
Generates a single Excel workbook from input files.

Usage:
    python generate_simple_excel.py [input_folder] [output_file]
    
Examples:
    python generate_simple_excel.py                           # Uses defaults
    python generate_simple_excel.py demo_input                # Custom input
    python generate_simple_excel.py demo_input my_report.xlsx # Custom output
"""

import sys
import pandas as pd
from pathlib import Path
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.chart import BarChart, PieChart, Reference
from openpyxl.chart.label import DataLabelList

def get_risk_level(score):
    """Convert score to risk level."""
    if score >= 12: return "Critical"
    elif score >= 8: return "High"
    elif score >= 4: return "Moderate"
    else: return "Low"

def load_all_data(input_dir):
    """Load all Excel files from input directory."""
    all_data = []
    input_path = Path(input_dir)
    
    for xlsx in sorted(input_path.glob("*.xlsx")):
        try:
            df = pd.read_excel(xlsx, sheet_name='All', skiprows=3, engine='openpyxl')
            entity_name = xlsx.stem.replace("risk_cartography_", "")
            df['Entity'] = entity_name
            all_data.append(df)
            print(f"  ✓ Loaded: {entity_name} ({len(df)} risks)")
        except Exception as e:
            print(f"  ⚠ Skipped: {xlsx.name} - {e}")
    
    if not all_data:
        raise ValueError(f"No valid Excel files found in {input_dir}")
    
    return pd.concat(all_data, ignore_index=True)

def process_data(df):
    """Add calculated fields and standardize columns."""
    # Standardize column names
    df.columns = [c.replace('\n', ' ').strip() for c in df.columns]
    
    # Add calculated fields
    df['Gross Level'] = df['Score brut'].apply(get_risk_level)
    df['Residual Level'] = df['Score réel'].apply(get_risk_level)
    df['Reduction %'] = ((df['Score brut'] - df['Score réel']) / df['Score brut'] * 100).round(1)
    
    return df

def create_summaries(df):
    """Create summary DataFrames."""
    # Entity summary
    entity_summary = df.groupby('Entity').agg({
        'N°': 'count',
        'Score brut': 'mean',
        'Score réel': 'mean'
    }).round(2)
    entity_summary.columns = ['Total Risks', 'Avg Gross Score', 'Avg Residual Score']
    entity_summary['Reduction %'] = (
        (entity_summary['Avg Gross Score'] - entity_summary['Avg Residual Score']) 
        / entity_summary['Avg Gross Score'] * 100
    ).round(1)
    
    # Category summary
    category_summary = df.groupby('Process').agg({
        'N°': 'count',
        'Score brut': 'mean',
        'Score réel': 'mean'
    }).round(2)
    category_summary.columns = ['Total Risks', 'Avg Gross Score', 'Avg Residual Score']
    category_summary['Reduction %'] = (
        (category_summary['Avg Gross Score'] - category_summary['Avg Residual Score']) 
        / category_summary['Avg Gross Score'] * 100
    ).round(1)
    
    # Risk distribution
    level_order = ['Critical', 'High', 'Moderate', 'Low']
    level_dist = df.groupby('Residual Level')['N°'].count().reindex(level_order).fillna(0).astype(int)
    level_dist = level_dist.reset_index()
    level_dist.columns = ['Risk Level', 'Count']
    
    # KPIs
    kpis = pd.DataFrame({
        'KPI': ['Total Risks', 'Total Entities', 'Total Categories',
                'Avg Gross Score', 'Avg Residual Score', 'Risk Reduction %', 
                'Critical Risks', 'High Risks', 'Moderate Risks', 'Low Risks'],
        'Value': [
            len(df),
            df['Entity'].nunique(),
            df['Process'].nunique(),
            round(df['Score brut'].mean(), 2),
            round(df['Score réel'].mean(), 2),
            round((df['Score brut'].mean() - df['Score réel'].mean()) / df['Score brut'].mean() * 100, 1),
            len(df[df['Residual Level'] == 'Critical']),
            len(df[df['Residual Level'] == 'High']),
            len(df[df['Residual Level'] == 'Moderate']),
            len(df[df['Residual Level'] == 'Low'])
        ]
    })
    
    # Top risks
    top_risks = df[df['Score réel'] >= 6][
        ['Entity', 'N°', 'Process', 'Corruption Scenario', 'Score brut', 'Score réel', 'Residual Level']
    ].sort_values('Score réel', ascending=False)
    
    return {
        'entity': entity_summary,
        'category': category_summary,
        'distribution': level_dist,
        'kpis': kpis,
        'top_risks': top_risks
    }

def write_excel(df, summaries, output_path):
    """Write data to Excel with formatting and charts."""
    print(f"\n📝 Writing to {output_path}...")
    
    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='All Risks', index=False)
        summaries['kpis'].to_excel(writer, sheet_name='KPIs', index=False)
        summaries['entity'].to_excel(writer, sheet_name='By Entity')
        summaries['category'].to_excel(writer, sheet_name='By Category')
        summaries['distribution'].to_excel(writer, sheet_name='Risk Distribution', index=False)
        summaries['top_risks'].to_excel(writer, sheet_name='Top Risks', index=False)
    
    # Add formatting and charts
    add_formatting(output_path, len(summaries['entity']), len(summaries['category']))
    add_instructions(output_path)
    
    print(f"✅ Created: {output_path}")

def add_formatting(filepath, num_entities, num_categories):
    """Add formatting and charts to workbook."""
    wb = load_workbook(filepath)
    
    header_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
    header_font = Font(color="FFFFFF", bold=True)
    
    # Style all headers
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(wrap_text=True)
        ws.freeze_panes = 'A2'
    
    # Entity chart
    ws_entity = wb['By Entity']
    chart = BarChart()
    chart.type = "col"
    chart.title = "Risk Scores by Entity"
    chart.y_axis.title = "Score"
    data = Reference(ws_entity, min_col=2, min_row=1, max_col=3, max_row=num_entities+1)
    cats = Reference(ws_entity, min_col=1, min_row=2, max_row=num_entities+1)
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(cats)
    ws_entity.add_chart(chart, "F2")
    
    # Category chart
    ws_cat = wb['By Category']
    chart2 = BarChart()
    chart2.type = "col"
    chart2.title = "Risk Scores by Category"
    data2 = Reference(ws_cat, min_col=2, min_row=1, max_col=3, max_row=num_categories+1)
    cats2 = Reference(ws_cat, min_col=1, min_row=2, max_row=num_categories+1)
    chart2.add_data(data2, titles_from_data=True)
    chart2.set_categories(cats2)
    ws_cat.add_chart(chart2, "F2")
    
    # Risk distribution pie chart
    ws_dist = wb['Risk Distribution']
    pie = PieChart()
    pie.title = "Risk Distribution"
    labels = Reference(ws_dist, min_col=1, min_row=2, max_row=5)
    data3 = Reference(ws_dist, min_col=2, min_row=1, max_row=5)
    pie.add_data(data3, titles_from_data=True)
    pie.set_categories(labels)
    pie.dataLabels = DataLabelList()
    pie.dataLabels.showPercent = True
    pie.dataLabels.showVal = True
    ws_dist.add_chart(pie, "D2")
    
    # Color scale for scores
    ws_all = wb['All Risks']
    for idx, cell in enumerate(ws_all[1], 1):
        if 'Score' in str(cell.value) and 'réel' in str(cell.value):
            col = cell.column_letter
            ws_all.conditional_formatting.add(
                f'{col}2:{col}300',
                ColorScaleRule(
                    start_type='num', start_value=1, start_color='00FF00',
                    mid_type='num', mid_value=6, mid_color='FFFF00',
                    end_type='num', end_value=12, end_color='FF0000'
                )
            )
            break
    
    wb.save(filepath)

def add_instructions(filepath):
    """Add instructions sheet."""
    wb = load_workbook(filepath)
    ws = wb.create_sheet("Instructions", 0)
    
    instructions = [
        ["RISK CARTOGRAPHY - SIMPLE EXCEL SOLUTION"],
        ["AFA / SAPIN II Compliance Tool"],
        [""],
        ["HOW TO USE:"],
        ["• Use Excel filters and slicers to analyze data"],
        ["• Charts update automatically when data changes"],
        ["• Share this single file with stakeholders"],
        [""],
        ["SHEETS:"],
        ["• All Risks - Complete risk register"],
        ["• KPIs - Key performance indicators"],
        ["• By Entity - Summary by business unit"],
        ["• By Category - Summary by risk category"],
        ["• Risk Distribution - Risk level breakdown"],
        ["• Top Risks - High priority risks (score >= 6)"],
        [""],
        ["TO REFRESH DATA:"],
        ["1. Place new Excel files in input folder"],
        ["2. Run: python generate_simple_excel.py"],
        [""],
        ["RISK LEVELS:"],
        ["• Critical (12-16): Immediate action required"],
        ["• High (8-11): Priority mitigation needed"],
        ["• Moderate (4-7): Monitor and review"],
        ["• Low (1-3): Acceptable risk level"],
    ]
    
    for row_idx, row_data in enumerate(instructions, 1):
        cell = ws.cell(row=row_idx, column=1, value=row_data[0] if row_data else "")
        if row_idx == 1:
            cell.font = Font(bold=True, size=14, color="1F4E79")
        elif row_idx == 2:
            cell.font = Font(italic=True, size=11)
    
    ws.column_dimensions['A'].width = 50
    wb.save(filepath)

def main():
    print("=" * 50)
    print("  PLAN B: Simple Excel Risk Cartography")
    print("=" * 50)
    
    # Parse arguments
    input_dir = sys.argv[1] if len(sys.argv) > 1 else "demo_input"
    output_file = sys.argv[2] if len(sys.argv) > 2 else "Risk_Cartography_Report.xlsx"
    
    print(f"\n📂 Input:  {input_dir}")
    print(f"📄 Output: {output_file}")
    print()
    
    # Load data
    print("Loading Excel files...")
    df = load_all_data(input_dir)
    
    # Process
    print("\nProcessing data...")
    df = process_data(df)
    summaries = create_summaries(df)
    
    # Write
    write_excel(df, summaries, output_file)
    
    # Summary
    print("\n" + "=" * 50)
    print("  SUMMARY")
    print("=" * 50)
    print(f"  Total Risks:     {len(df)}")
    print(f"  Entities:        {df['Entity'].nunique()}")
    print(f"  Categories:      {df['Process'].nunique()}")
    print(f"  Avg Gross:       {df['Score brut'].mean():.2f}")
    print(f"  Avg Residual:    {df['Score réel'].mean():.2f}")
    print(f"  Risk Reduction:  {(df['Score brut'].mean() - df['Score réel'].mean()) / df['Score brut'].mean() * 100:.1f}%")
    print("=" * 50)

if __name__ == "__main__":
    main()
