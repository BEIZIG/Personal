#!/usr/bin/env python3
"""
Generate PowerPoint presentation from Markdown file.
Converts PRESENTATION_RISK_MANAGEMENT_DEMO.md to PPTX format.
"""

import re
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE


# === Configuration ===
COLORS = {
    'primary': RGBColor(0, 82, 147),      # Dark blue
    'secondary': RGBColor(0, 150, 199),    # Cyan
    'accent': RGBColor(0, 212, 255),       # Bright cyan
    'success': RGBColor(16, 185, 129),     # Green
    'warning': RGBColor(245, 158, 11),     # Orange
    'danger': RGBColor(239, 68, 68),       # Red
    'dark': RGBColor(30, 41, 59),          # Dark slate
    'light': RGBColor(248, 250, 252),      # Light gray
    'text': RGBColor(51, 65, 85),          # Slate gray
    'white': RGBColor(255, 255, 255),
}

FONTS = {
    'title': 'Calibri Light',
    'body': 'Calibri',
    'code': 'Consolas',
}


def parse_markdown(md_path: str) -> list:
    """Parse Markdown file into slide structures."""
    with open(md_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Split by slide separator (---)
    raw_slides = re.split(r'\n---\n', content)
    
    slides = []
    for raw in raw_slides:
        raw = raw.strip()
        if not raw:
            continue
        
        slide = parse_slide_content(raw)
        if slide:
            slides.append(slide)
    
    return slides


def parse_slide_content(raw: str) -> dict:
    """Parse a single slide's content."""
    lines = raw.split('\n')
    
    slide = {
        'title': '',
        'subtitle': '',
        'content': [],
        'tables': [],
        'code_blocks': [],
        'type': 'content'  # content, title, two_column
    }
    
    i = 0
    while i < len(lines):
        line = lines[i]
        
        # Main title (# )
        if line.startswith('# '):
            slide['title'] = clean_text(line[2:])
            # Check if next line is subtitle
            if i + 1 < len(lines) and lines[i + 1].startswith('## '):
                slide['subtitle'] = clean_text(lines[i + 1][3:])
                i += 1
        
        # Subtitle (## )
        elif line.startswith('## '):
            if not slide['title']:
                slide['title'] = clean_text(line[3:])
            else:
                slide['content'].append({
                    'type': 'heading',
                    'text': clean_text(line[3:])
                })
        
        # Sub-heading (### )
        elif line.startswith('### '):
            slide['content'].append({
                'type': 'subheading',
                'text': clean_text(line[4:])
            })
        
        # Code block
        elif line.startswith('```'):
            code_lines = []
            i += 1
            while i < len(lines) and not lines[i].startswith('```'):
                code_lines.append(lines[i])
                i += 1
            slide['code_blocks'].append('\n'.join(code_lines))
            slide['content'].append({
                'type': 'code',
                'index': len(slide['code_blocks']) - 1
            })
        
        # Table
        elif line.startswith('|'):
            table_lines = [line]
            i += 1
            while i < len(lines) and lines[i].startswith('|'):
                if not lines[i].startswith('|---') and not lines[i].startswith('| ---'):
                    table_lines.append(lines[i])
                i += 1
            i -= 1  # Back up one
            table = parse_table(table_lines)
            if table:
                slide['tables'].append(table)
                slide['content'].append({
                    'type': 'table',
                    'index': len(slide['tables']) - 1
                })
        
        # Bullet point
        elif line.startswith('- ') or line.startswith('* '):
            slide['content'].append({
                'type': 'bullet',
                'text': clean_text(line[2:]),
                'level': 0
            })
        
        # Numbered list
        elif re.match(r'^\d+\.\s', line):
            text = re.sub(r'^\d+\.\s', '', line)
            slide['content'].append({
                'type': 'bullet',
                'text': clean_text(text),
                'level': 0
            })
        
        # Indented bullet
        elif line.startswith('  - ') or line.startswith('  * '):
            slide['content'].append({
                'type': 'bullet',
                'text': clean_text(line[4:]),
                'level': 1
            })
        
        # Bold text as key point
        elif line.startswith('**') and line.endswith('**'):
            slide['content'].append({
                'type': 'highlight',
                'text': clean_text(line[2:-2])
            })
        
        # Regular text
        elif line.strip() and not line.startswith('#'):
            slide['content'].append({
                'type': 'text',
                'text': clean_text(line)
            })
        
        i += 1
    
    # Determine slide type
    if not slide['content'] and not slide['tables'] and slide['subtitle']:
        slide['type'] = 'title'
    
    return slide if slide['title'] else None


def parse_table(lines: list) -> list:
    """Parse table lines into rows of cells."""
    rows = []
    for line in lines:
        cells = [clean_text(c.strip()) for c in line.split('|')[1:-1]]
        if cells and any(c for c in cells):
            rows.append(cells)
    return rows


def clean_text(text: str) -> str:
    """Clean markdown formatting from text."""
    # Remove emoji at start (keep for titles)
    # text = re.sub(r'^[\U0001F300-\U0001F9FF]\s*', '', text)
    
    # Convert **bold** to just text (PowerPoint handles bold separately)
    text = re.sub(r'\*\*([^*]+)\*\*', r'\1', text)
    
    # Convert `code` to text
    text = re.sub(r'`([^`]+)`', r'\1', text)
    
    # Clean up arrows
    text = text.replace('→', '→').replace('-->', '→')
    
    return text.strip()


def create_presentation(slides: list, output_path: str):
    """Create PowerPoint presentation from parsed slides."""
    prs = Presentation()
    prs.slide_width = Inches(13.333)  # 16:9 aspect ratio
    prs.slide_height = Inches(7.5)
    
    for i, slide_data in enumerate(slides):
        if i == 0:
            # Title slide
            add_title_slide(prs, slide_data)
        elif slide_data['type'] == 'title':
            add_section_slide(prs, slide_data)
        else:
            add_content_slide(prs, slide_data)
    
    prs.save(output_path)
    print(f"✅ Presentation saved: {output_path}")
    print(f"   Total slides: {len(prs.slides)}")


def add_title_slide(prs: Presentation, data: dict):
    """Add title slide."""
    slide_layout = prs.slide_layouts[6]  # Blank
    slide = prs.slides.add_slide(slide_layout)
    
    # Background
    add_gradient_background(slide, COLORS['dark'], COLORS['primary'])
    
    # Title
    title_box = slide.shapes.add_textbox(
        Inches(0.5), Inches(2.5), Inches(12.333), Inches(1.5)
    )
    tf = title_box.text_frame
    tf.paragraphs[0].alignment = PP_ALIGN.CENTER
    run = tf.paragraphs[0].add_run()
    run.text = data['title']
    run.font.name = FONTS['title']
    run.font.size = Pt(44)
    run.font.color.rgb = COLORS['white']
    run.font.bold = True
    
    # Subtitle
    if data['subtitle']:
        sub_box = slide.shapes.add_textbox(
            Inches(0.5), Inches(4.2), Inches(12.333), Inches(1)
        )
        tf = sub_box.text_frame
        tf.paragraphs[0].alignment = PP_ALIGN.CENTER
        run = tf.paragraphs[0].add_run()
        run.text = data['subtitle']
        run.font.name = FONTS['body']
        run.font.size = Pt(24)
        run.font.color.rgb = COLORS['accent']


def add_section_slide(prs: Presentation, data: dict):
    """Add section divider slide."""
    slide_layout = prs.slide_layouts[6]  # Blank
    slide = prs.slides.add_slide(slide_layout)
    
    # Background
    add_solid_background(slide, COLORS['secondary'])
    
    # Title
    title_box = slide.shapes.add_textbox(
        Inches(0.5), Inches(3), Inches(12.333), Inches(1.5)
    )
    tf = title_box.text_frame
    tf.paragraphs[0].alignment = PP_ALIGN.CENTER
    run = tf.paragraphs[0].add_run()
    run.text = data['title']
    run.font.name = FONTS['title']
    run.font.size = Pt(40)
    run.font.color.rgb = COLORS['white']
    run.font.bold = True


def add_content_slide(prs: Presentation, data: dict):
    """Add content slide with title and body."""
    slide_layout = prs.slide_layouts[6]  # Blank
    slide = prs.slides.add_slide(slide_layout)
    
    # White background
    add_solid_background(slide, COLORS['white'])
    
    # Header bar
    header = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(0), Inches(0), Inches(13.333), Inches(1.1)
    )
    header.fill.solid()
    header.fill.fore_color.rgb = COLORS['primary']
    header.line.fill.background()
    
    # Title
    title_box = slide.shapes.add_textbox(
        Inches(0.5), Inches(0.25), Inches(12.333), Inches(0.7)
    )
    tf = title_box.text_frame
    run = tf.paragraphs[0].add_run()
    run.text = data['title']
    run.font.name = FONTS['title']
    run.font.size = Pt(28)
    run.font.color.rgb = COLORS['white']
    run.font.bold = True
    
    # Content area
    y_pos = 1.3
    
    for item in data['content']:
        if item['type'] == 'heading':
            y_pos = add_heading(slide, item['text'], y_pos)
        elif item['type'] == 'subheading':
            y_pos = add_subheading(slide, item['text'], y_pos)
        elif item['type'] == 'bullet':
            y_pos = add_bullet(slide, item['text'], y_pos, item.get('level', 0))
        elif item['type'] == 'text':
            y_pos = add_text(slide, item['text'], y_pos)
        elif item['type'] == 'highlight':
            y_pos = add_highlight(slide, item['text'], y_pos)
        elif item['type'] == 'table':
            table_data = data['tables'][item['index']]
            y_pos = add_table(slide, table_data, y_pos)
        elif item['type'] == 'code':
            code = data['code_blocks'][item['index']]
            y_pos = add_code_block(slide, code, y_pos)
        
        # Prevent overflow
        if y_pos > 7:
            break


def add_heading(slide, text: str, y_pos: float) -> float:
    """Add section heading."""
    box = slide.shapes.add_textbox(
        Inches(0.5), Inches(y_pos), Inches(12.333), Inches(0.5)
    )
    tf = box.text_frame
    run = tf.paragraphs[0].add_run()
    run.text = text
    run.font.name = FONTS['body']
    run.font.size = Pt(20)
    run.font.color.rgb = COLORS['primary']
    run.font.bold = True
    return y_pos + 0.5


def add_subheading(slide, text: str, y_pos: float) -> float:
    """Add sub-heading."""
    box = slide.shapes.add_textbox(
        Inches(0.5), Inches(y_pos), Inches(12.333), Inches(0.4)
    )
    tf = box.text_frame
    run = tf.paragraphs[0].add_run()
    run.text = text
    run.font.name = FONTS['body']
    run.font.size = Pt(16)
    run.font.color.rgb = COLORS['secondary']
    run.font.bold = True
    return y_pos + 0.4


def add_bullet(slide, text: str, y_pos: float, level: int = 0) -> float:
    """Add bullet point."""
    indent = 0.5 + (level * 0.3)
    bullet = "•" if level == 0 else "◦"
    
    box = slide.shapes.add_textbox(
        Inches(indent), Inches(y_pos), Inches(12.333 - indent), Inches(0.35)
    )
    tf = box.text_frame
    tf.word_wrap = True
    run = tf.paragraphs[0].add_run()
    run.text = f"{bullet} {text}"
    run.font.name = FONTS['body']
    run.font.size = Pt(14)
    run.font.color.rgb = COLORS['text']
    return y_pos + 0.35


def add_text(slide, text: str, y_pos: float) -> float:
    """Add regular text."""
    if not text.strip():
        return y_pos + 0.1
    
    box = slide.shapes.add_textbox(
        Inches(0.5), Inches(y_pos), Inches(12.333), Inches(0.35)
    )
    tf = box.text_frame
    tf.word_wrap = True
    run = tf.paragraphs[0].add_run()
    run.text = text
    run.font.name = FONTS['body']
    run.font.size = Pt(14)
    run.font.color.rgb = COLORS['text']
    return y_pos + 0.35


def add_highlight(slide, text: str, y_pos: float) -> float:
    """Add highlighted text box."""
    box = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE,
        Inches(0.5), Inches(y_pos), Inches(12.333), Inches(0.5)
    )
    box.fill.solid()
    box.fill.fore_color.rgb = COLORS['secondary']
    box.line.fill.background()
    
    # Add text
    tf = box.text_frame
    tf.paragraphs[0].alignment = PP_ALIGN.CENTER
    run = tf.paragraphs[0].add_run()
    run.text = text
    run.font.name = FONTS['body']
    run.font.size = Pt(14)
    run.font.color.rgb = COLORS['white']
    run.font.bold = True
    
    return y_pos + 0.6


def add_table(slide, table_data: list, y_pos: float) -> float:
    """Add table to slide."""
    if not table_data:
        return y_pos
    
    rows = len(table_data)
    cols = len(table_data[0]) if table_data else 0
    
    if rows == 0 or cols == 0:
        return y_pos
    
    # Limit table size
    max_rows = min(rows, 10)
    table_height = 0.35 * max_rows
    
    # Calculate column widths
    available_width = 12.333
    col_width = available_width / cols
    
    table = slide.shapes.add_table(
        max_rows, cols,
        Inches(0.5), Inches(y_pos),
        Inches(available_width), Inches(table_height)
    ).table
    
    # Style header row
    for j, cell_text in enumerate(table_data[0][:cols]):
        cell = table.cell(0, j)
        cell.text = cell_text
        cell.fill.solid()
        cell.fill.fore_color.rgb = COLORS['primary']
        
        para = cell.text_frame.paragraphs[0]
        para.font.name = FONTS['body']
        para.font.size = Pt(11)
        para.font.color.rgb = COLORS['white']
        para.font.bold = True
        para.alignment = PP_ALIGN.CENTER
    
    # Data rows
    for i, row_data in enumerate(table_data[1:max_rows], start=1):
        for j, cell_text in enumerate(row_data[:cols]):
            cell = table.cell(i, j)
            cell.text = cell_text
            
            # Alternating row colors
            if i % 2 == 0:
                cell.fill.solid()
                cell.fill.fore_color.rgb = COLORS['light']
            else:
                cell.fill.solid()
                cell.fill.fore_color.rgb = COLORS['white']
            
            para = cell.text_frame.paragraphs[0]
            para.font.name = FONTS['body']
            para.font.size = Pt(10)
            para.font.color.rgb = COLORS['text']
    
    return y_pos + table_height + 0.2


def add_code_block(slide, code: str, y_pos: float) -> float:
    """Add code block."""
    lines = code.split('\n')[:12]  # Limit lines
    code_text = '\n'.join(lines)
    
    height = min(0.25 * len(lines), 3)
    
    # Background box
    box = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(0.5), Inches(y_pos), Inches(12.333), Inches(height)
    )
    box.fill.solid()
    box.fill.fore_color.rgb = COLORS['dark']
    box.line.fill.background()
    
    # Code text
    text_box = slide.shapes.add_textbox(
        Inches(0.6), Inches(y_pos + 0.1), Inches(12.133), Inches(height - 0.2)
    )
    tf = text_box.text_frame
    tf.word_wrap = False
    run = tf.paragraphs[0].add_run()
    run.text = code_text
    run.font.name = FONTS['code']
    run.font.size = Pt(9)
    run.font.color.rgb = COLORS['accent']
    
    return y_pos + height + 0.2


def add_gradient_background(slide, color1: RGBColor, color2: RGBColor):
    """Add gradient background (simplified as solid for compatibility)."""
    background = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(0), Inches(0), Inches(13.333), Inches(7.5)
    )
    background.fill.solid()
    background.fill.fore_color.rgb = color1
    background.line.fill.background()
    
    # Send to back
    slide.shapes._spTree.remove(background._element)
    slide.shapes._spTree.insert(2, background._element)


def add_solid_background(slide, color: RGBColor):
    """Add solid background."""
    background = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(0), Inches(0), Inches(13.333), Inches(7.5)
    )
    background.fill.solid()
    background.fill.fore_color.rgb = color
    background.line.fill.background()
    
    # Send to back
    slide.shapes._spTree.remove(background._element)
    slide.shapes._spTree.insert(2, background._element)


def main():
    """Main entry point."""
    script_dir = Path(__file__).parent
    md_path = script_dir / 'output' / 'PRESENTATION_RISK_MANAGEMENT_DEMO.md'
    output_path = script_dir / 'output' / 'PRESENTATION_RISK_MANAGEMENT_DEMO.pptx'
    
    print("=" * 60)
    print("  📊 PowerPoint Generator")
    print("  Converting Markdown to PPTX")
    print("=" * 60)
    
    print(f"\n📄 Source: {md_path}")
    
    # Parse markdown
    slides = parse_markdown(str(md_path))
    print(f"📑 Parsed {len(slides)} slides")
    
    # Generate presentation
    create_presentation(slides, str(output_path))
    
    print("\n" + "=" * 60)
    print("  ✅ DONE")
    print("=" * 60)


if __name__ == '__main__':
    main()
