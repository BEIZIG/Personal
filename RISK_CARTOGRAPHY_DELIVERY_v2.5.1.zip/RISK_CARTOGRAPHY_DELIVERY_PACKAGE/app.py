"""
Risk Cartography Application
AFA/Sapin II Compliance Dashboard Generator

Version: 1.0
Entry Point: streamlit run app.py
"""

import streamlit as st
import pandas as pd
import json
import os
import sys
import traceback
from pathlib import Path
from datetime import datetime
import subprocess

# === Fix Windows encoding issues (safe for Streamlit) ===
# This must be set BEFORE any imports that might print to stdout
os.environ['PYTHONIOENCODING'] = 'utf-8'
os.environ['PYTHONUTF8'] = '1'
os.environ['LC_ALL'] = 'en_US.UTF-8'

# === Application Paths ===
APP_DIR = Path(__file__).parent.resolve()
CONFIG_DIR = APP_DIR / "config"
OUTPUT_DIR = APP_DIR / "output"
INPUT_DIR = APP_DIR / "input"
LIB_DIR = APP_DIR / "lib"
SAMPLES_DIR = APP_DIR / "samples"

# Add lib to path for imports
sys.path.insert(0, str(LIB_DIR))

# Ensure directories exist
CONFIG_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)
INPUT_DIR.mkdir(exist_ok=True)

# === HELPER: Safe string handling for Windows ===
def safe_str(text):
    """Convert text to safe ASCII for Windows console output."""
    if text is None:
        return ''
    try:
        return str(text)
    except:
        return str(text).encode('ascii', 'replace').decode('ascii')

# Page config
st.set_page_config(
    page_title="Risk Cartography - AFA/Sapin II",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)


# === Default Configurations ===
def get_defaults():
    """Return default configuration dictionaries."""
    return {
        "column_mapping": {
            "risk_id": {"source_name": "Risk ID", "aliases": ["ID", "Risk_ID", "RiskID", "N°"], "required": True, "description": "Unique identifier (e.g., A1, B2)", "field_type": "text", "index": 0},
            "processus": {"source_name": "Process", "aliases": ["Processus", "Business Process"], "required": False, "description": "Business process name", "field_type": "text", "index": 1},
            "scenario": {"source_name": "Risk Scenario", "aliases": ["Scenario", "Description", "Risk Description"], "required": True, "description": "Description of the risk scenario", "field_type": "text", "index": 2},
            "description": {"source_name": "Detailed Description", "aliases": ["Details", "Full Description"], "required": False, "description": "Detailed risk description", "field_type": "text", "index": 3},
            "aggravating_factors": {"source_name": "Aggravating Factors", "aliases": ["Factors", "Risk Factors"], "required": False, "description": "Factors that increase risk", "field_type": "text", "index": 4},
            "prob_gross": {"source_name": "Probability (Gross)", "aliases": ["P_Brut", "Prob_Gross", "P Inherent"], "required": True, "description": "Inherent probability (1-4)", "field_type": "numeric", "index": 5},
            "impact_gross": {"source_name": "Impact (Gross)", "aliases": ["I_Brut", "Impact_Gross", "I Inherent"], "required": True, "description": "Inherent impact (1-4)", "field_type": "numeric", "index": 6},
            "score_gross": {"source_name": "Score (Gross)", "aliases": ["S_Brut", "Score_Gross", "Risk Score Inherent"], "required": True, "description": "Inherent risk score (P×I)", "field_type": "numeric", "index": 7},
            "level_gross": {"source_name": "Level (Gross)", "aliases": ["Level_Brut", "Risk Level Inherent"], "required": False, "description": "Inherent risk level label", "field_type": "level", "index": 8},
            "prevention_measures": {"source_name": "Prevention Measures", "aliases": ["Controls", "Preventive Controls", "Mesures Préventives"], "required": False, "description": "Preventive control measures in place", "field_type": "text", "index": 9},
            "prob_residual": {"source_name": "Probability (Residual)", "aliases": ["P_Residuel", "Prob_Residual", "P Net"], "required": True, "description": "Residual probability after controls (1-4)", "field_type": "numeric", "index": 10},
            "impact_residual": {"source_name": "Impact (Residual)", "aliases": ["I_Residuel", "Impact_Residual", "I Net"], "required": True, "description": "Residual impact after controls (1-4)", "field_type": "numeric", "index": 11},
            "score_residual": {"source_name": "Score (Residual)", "aliases": ["S_Residuel", "Score_Residual", "Risk Score Net"], "required": True, "description": "Residual risk score (P×I)", "field_type": "numeric", "index": 12},
            "level_residual": {"source_name": "Level (Residual)", "aliases": ["Level_Residuel", "Risk Level Net"], "required": False, "description": "Residual risk level label", "field_type": "level", "index": 13},
            "corrective_actions": {"source_name": "Corrective Actions", "aliases": ["Action Plan", "Remediation", "Actions Correctives"], "required": False, "description": "Corrective action plans", "field_type": "text", "index": 14}
        },
        "categories": {
            "A": {"name": "Procurement", "color": "#3498db"},
            "B": {"name": "Commercial/Sales", "color": "#9b59b6"},
            "C": {"name": "Human Resources", "color": "#e74c3c"},
            "D": {"name": "Finance", "color": "#2ecc71"},
            "E": {"name": "M&A / JV", "color": "#f39c12"},
            "F": {"name": "Sponsoring", "color": "#1abc9c"},
            "G": {"name": "Public Officials", "color": "#34495e"}
        },
        "risk_levels": {
            "critical": {"min_score": 12, "max_score": 16, "label": "Critical", "color": "#dc3545", "emoji": "🔴"},
            "high": {"min_score": 8, "max_score": 9, "label": "High", "color": "#fd7e14", "emoji": "🟠"},
            "moderate": {"min_score": 4, "max_score": 6, "label": "Moderate", "color": "#ffc107", "emoji": "🟡"},
            "low": {"min_score": 1, "max_score": 3, "label": "Low", "color": "#28a745", "emoji": "🟢"}
        },
        "formulas": {
            "score_calculation": {"name": "Risk Score", "formula": "Probability × Impact", "description": "P × I = Score (1-16)", "min_value": 1, "max_value": 16},
            "risk_reduction": {"name": "Risk Reduction %", "formula": "((Gross - Residual) / Gross) × 100", "description": "Percentage improvement"},
            "mitigation_rate": {"name": "Mitigation Rate", "formula": "(Improved / Total) × 100", "description": "% risks mitigated"},
            "urgency_score": {"name": "Urgency Score", "formula": "Weighted severity index", "description": "Priority indicator"}
        },
        "column_order": [
            "risk_id", "processus", "scenario", "description", "aggravating_factors",
            "prob_gross", "impact_gross", "score_gross", "level_gross",
            "prevention_measures",
            "prob_residual", "impact_residual", "score_residual", "level_residual",
            "corrective_actions"
        ]
    }


def load_config(filename: str, default_key: str) -> dict:
    """Load configuration from file or return default."""
    filepath = CONFIG_DIR / filename
    if filepath.exists():
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            st.warning(f"Error loading {filename}: {e}")
    return get_defaults().get(default_key, {})


def save_config(filename: str, config: dict):
    """Save configuration to file."""
    filepath = CONFIG_DIR / filename
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def init_session_state():
    """Initialize session state with configurations."""
    if 'initialized' not in st.session_state:
        st.session_state.column_mapping = load_config('column_mapping.json', 'column_mapping')
        st.session_state.categories = load_config('categories.json', 'categories')
        st.session_state.risk_levels = load_config('risk_levels.json', 'risk_levels')
        st.session_state.formulas = load_config('formulas.json', 'formulas')
        
        # Load column order (or derive from mapping)
        order_path = CONFIG_DIR / 'column_order.json'
        if order_path.exists():
            try:
                with open(order_path, 'r', encoding='utf-8') as f:
                    st.session_state.column_order = json.load(f)
            except:
                st.session_state.column_order = list(st.session_state.column_mapping.keys())
        else:
            st.session_state.column_order = list(st.session_state.column_mapping.keys())
        
        st.session_state.initialized = True


def render_sidebar():
    """Render sidebar with mode selection."""
    st.sidebar.title("🛡️ Risk Cartography")
    st.sidebar.markdown("**AFA / Sapin II Compliance**")
    st.sidebar.markdown("---")
    
    mode = st.sidebar.radio(
        "Select Mode",
        ["🚀 Executor", "⚙️ Admin", "📖 Wiki"],
        help="Executor: Run analysis | Admin: Configure settings | Wiki: Documentation"
    )
    
    st.sidebar.markdown("---")
    
    if mode == "⚙️ Admin":
        admin_section = st.sidebar.selectbox(
            "Configuration Section",
            ["Column Mapping", "Categories", "Risk Levels", "Formulas", "Dashboard Labels"]
        )
        return "admin", admin_section
    elif mode == "📖 Wiki":
        wiki_section = st.sidebar.selectbox(
            "Documentation Section",
            ["Overview", "Dashboard Guide", "Charts & Graphs", "Formulas", "Output Files", "AFA/Sapin II"]
        )
        return "wiki", wiki_section
    return "executor", None


# === ADMIN MODE ===

def render_column_mapping_admin():
    """Admin interface for column mapping with reordering."""
    st.header("📋 Column Mapping Configuration")
    st.markdown("Define Excel columns, their order, and mapping to system fields.")
    
    # Initialize column order if not present
    if 'column_order' not in st.session_state:
        st.session_state.column_order = list(st.session_state.column_mapping.keys())
    
    mapping = st.session_state.column_mapping
    order = st.session_state.column_order
    
    # Ensure all keys are in order list
    for key in mapping.keys():
        if key not in order:
            order.append(key)
    # Remove deleted keys from order
    order = [k for k in order if k in mapping]
    st.session_state.column_order = order
    
    st.info("📌 **Column Index** = Position in Excel file (0-indexed). Use ⬆️⬇️ to reorder.")
    
    # Display columns in order
    updated = {}
    new_order = order.copy()
    
    for idx, field_key in enumerate(order):
        config = mapping.get(field_key, {})
        badge = "🔴" if config.get('required') else "🟢"
        
        # Single row per column
        with st.expander(f"`{idx}` {badge} **{config.get('source_name', field_key)}**", expanded=False):
            # Reorder buttons at top
            btn_col1, btn_col2, btn_col3 = st.columns([1, 1, 2])
            with btn_col1:
                if idx > 0:
                    if st.button(f"⬆️ Move Up", key=f"up_{field_key}"):
                        new_order[idx], new_order[idx-1] = new_order[idx-1], new_order[idx]
                        st.session_state.column_order = new_order
                        st.experimental_rerun()
            with btn_col2:
                if idx < len(order) - 1:
                    if st.button(f"⬇️ Move Down", key=f"down_{field_key}"):
                        new_order[idx], new_order[idx+1] = new_order[idx+1], new_order[idx]
                        st.session_state.column_order = new_order
                        st.experimental_rerun()
            with btn_col3:
                if not config.get('required', False):
                    if st.button(f"🗑️ Delete Column", key=f"del_{field_key}"):
                        del mapping[field_key]
                        new_order.remove(field_key)
                        st.session_state.column_mapping = mapping
                        st.session_state.column_order = new_order
                        st.experimental_rerun()
            
            st.markdown("---")
            
            # Field details
            name = st.text_input("Display Name", value=config.get('source_name', ''), key=f"src_{field_key}")
            aliases = st.text_input("Aliases (comma-separated)", value=", ".join(config.get('aliases', [])), key=f"ali_{field_key}")
            desc = st.text_area("Description", value=config.get('description', ''), key=f"desc_{field_key}", height=60)
            
            type_col, req_col = st.columns(2)
            with type_col:
                # Safely get field_type with validation
                valid_types = ["text", "numeric", "level", "boolean", "date"]
                raw_type = config.get('field_type', 'text')
                field_type_value = raw_type if raw_type in valid_types else 'text'
                field_type = st.selectbox("Field Type", valid_types, 
                                          index=valid_types.index(field_type_value),
                                          key=f"type_{field_key}")
            with req_col:
                # Safely convert required to bool
                req_value = config.get('required', False)
                req_value = bool(req_value) if isinstance(req_value, bool) else req_value == True
                req = st.checkbox("Required Field", value=req_value, key=f"req_{field_key}")
            
            updated[field_key] = {
                'source_name': name,
                'aliases': [a.strip() for a in aliases.split(',') if a.strip()],
                'required': req,
                'description': desc,
                'field_type': field_type,
                'index': idx
            }
    
    # Add new column section
    st.markdown("---")
    st.subheader("➕ Add New Column")
    
    with st.expander("Create Custom Column", expanded=False):
        new_key = st.text_input("Internal Key (no spaces)", placeholder="my_column", key="new_col_key")
        new_name = st.text_input("Display Name", placeholder="My Column", key="new_col_name")
        new_aliases = st.text_input("Excel Column Names (comma-separated)", placeholder="Col1, Column 1", key="new_col_aliases")
        new_desc = st.text_area("Description", placeholder="What this column contains", key="new_col_desc", height=60)
        new_type = st.selectbox("Field Type", ["text", "numeric", "level"], key="new_col_type")
        new_required = st.checkbox("Required Field", key="new_col_req")
        
        if st.button("➕ Add Column"):
            if new_key and new_name:
                # Clean key (no spaces, lowercase)
                clean_key = new_key.lower().replace(" ", "_")
                if clean_key not in mapping:
                    mapping[clean_key] = {
                        'source_name': new_name,
                        'aliases': [a.strip() for a in new_aliases.split(',') if a.strip()],
                        'required': new_required,
                        'description': new_desc,
                        'field_type': new_type,
                        'index': len(order)
                    }
                    order.append(clean_key)
                    st.session_state.column_mapping = mapping
                    st.session_state.column_order = order
                    st.success(f"✅ Added column: {new_name}")
                    st.experimental_rerun()
                else:
                    st.error(f"❌ Key '{clean_key}' already exists")
            else:
                st.warning("⚠️ Key and Name are required")
    
    # Preview generated mapping
    st.markdown("---")
    st.subheader("👁️ Preview Column Index Mapping")
    
    preview_data = []
    for idx, key in enumerate(st.session_state.column_order):
        cfg = mapping.get(key, {})
        preview_data.append({
            "Index": idx,
            "Key": key,
            "Display Name": cfg.get('source_name', ''),
            "Type": cfg.get('field_type', 'text'),
            "Required": "✅" if cfg.get('required') else "❌"
        })
    
    if preview_data:
        st.dataframe(preview_data)
    
    # Save button
    st.markdown("---")
    if st.button("💾 Save All Changes"):
        # Update indices based on order
        for idx, key in enumerate(st.session_state.column_order):
            if key in updated:
                updated[key]['index'] = idx
        
        st.session_state.column_mapping = updated
        save_config('column_mapping.json', updated)
        save_config('column_order.json', st.session_state.column_order)
        st.success("✅ Column mapping saved!")


def render_categories_admin():
    """Admin interface for categories."""
    st.header("📁 Category Configuration")
    
    categories = st.session_state.categories
    updated = {}
    
    cols = st.columns(3)
    for i, (code, config) in enumerate(categories.items()):
        with cols[i % 3]:
            st.markdown(f"### {code}")
            name = st.text_input("Name", value=config['name'], key=f"cat_{code}")
            color = st.color_picker("Color", value=config['color'], key=f"col_{code}")
            st.markdown(f'<div style="background:{color};color:white;padding:8px;border-radius:4px;text-align:center;">{code}: {name}</div>', unsafe_allow_html=True)
            updated[code] = {'name': name, 'color': color}
            st.markdown("")
    
    # Add new category
    st.markdown("---")
    st.subheader("➕ Add Category")
    c1, c2, c3, c4 = st.columns([1, 2, 1, 1])
    with c1:
        new_code = st.text_input("Code", placeholder="H", max_chars=2)
    with c2:
        new_name = st.text_input("Name", placeholder="Legal", key="new_cat_n")
    with c3:
        new_color = st.color_picker("Color", value="#666666", key="new_cat_c")
    with c4:
        if st.button("Add") and new_code and new_name:
            updated[new_code.upper()] = {'name': new_name, 'color': new_color}
            st.success(f"✅ Added {new_code.upper()}")
    
    st.markdown("---")
    if st.button("💾 Save Categories"):
        st.session_state.categories = updated
        save_config('categories.json', updated)
        st.success("✅ Saved!")


def render_risk_levels_admin():
    """Admin interface for risk levels."""
    st.header("🎯 Risk Level Configuration")
    st.info("**Formula:** Score = Probability (1-4) × Impact (1-4)")
    
    # Matrix preview
    matrix = "<table style='border-collapse:collapse;margin:10px 0;'><tr><th style='border:1px solid #ddd;padding:8px;'>P↓ I→</th>"
    for i in range(1, 5):
        matrix += f"<th style='border:1px solid #ddd;padding:8px;width:50px;'>{i}</th>"
    matrix += "</tr>"
    for p in range(4, 0, -1):
        matrix += f"<tr><th style='border:1px solid #ddd;padding:8px;'>{p}</th>"
        for i in range(1, 5):
            s = p * i
            c = "#dc3545" if s >= 12 else "#fd7e14" if s >= 8 else "#ffc107" if s >= 4 else "#28a745"
            matrix += f"<td style='border:1px solid #ddd;padding:8px;background:{c};color:white;text-align:center;'>{s}</td>"
        matrix += "</tr>"
    matrix += "</table>"
    st.markdown(matrix, unsafe_allow_html=True)
    
    levels = st.session_state.risk_levels
    updated = {}
    
    for key in ['critical', 'high', 'moderate', 'low']:
        cfg = levels.get(key, {})
        with st.expander(f"{cfg.get('emoji', '⚪')} {cfg.get('label', key.title())}", expanded=True):
            c1, c2, c3, c4 = st.columns(4)
            with c1:
                label = st.text_input("Label", value=cfg.get('label', ''), key=f"lbl_{key}")
            with c2:
                mn = st.number_input("Min", min_value=1, max_value=16, value=cfg.get('min_score', 1), key=f"min_{key}")
            with c3:
                mx = st.number_input("Max", min_value=1, max_value=16, value=cfg.get('max_score', 16), key=f"max_{key}")
            with c4:
                color = st.color_picker("Color", value=cfg.get('color', '#888'), key=f"clr_{key}")
            
            emojis = ["🔴", "🟠", "🟡", "🟢", "⚪"]
            idx = emojis.index(cfg.get('emoji', '⚪')) if cfg.get('emoji') in emojis else 0
            emoji = st.selectbox("Emoji", emojis, index=idx, key=f"emj_{key}")
            
            updated[key] = {'min_score': mn, 'max_score': mx, 'label': label, 'color': color, 'emoji': emoji}
    
    st.markdown("---")
    if st.button("💾 Save Risk Levels"):
        st.session_state.risk_levels = updated
        save_config('risk_levels.json', updated)
        st.success("✅ Saved!")


def render_formulas_admin():
    """Admin interface for formulas."""
    st.header("📐 Formula Configuration")
    
    formulas = st.session_state.formulas
    updated = {}
    
    for key, cfg in formulas.items():
        with st.expander(f"**{cfg.get('name', key)}**", expanded=True):
            c1, c2 = st.columns(2)
            with c1:
                name = st.text_input("Name", value=cfg.get('name', ''), key=f"fn_{key}")
                formula = st.text_input("Formula", value=cfg.get('formula', ''), key=f"ff_{key}")
            with c2:
                desc = st.text_area("Description", value=cfg.get('description', ''), key=f"fd_{key}", height=80)
            
            updated[key] = {'name': name, 'formula': formula, 'description': desc}
            if 'min_value' in cfg:
                updated[key]['min_value'] = cfg['min_value']
                updated[key]['max_value'] = cfg['max_value']
    
    st.markdown("---")
    if st.button("💾 Save Formulas"):
        st.session_state.formulas = updated
        save_config('formulas.json', updated)
        st.success("✅ Saved!")


def render_dashboard_labels_admin():
    """Admin interface for dashboard labels (chart titles, section names, etc.)."""
    st.header("🏷️ Dashboard Labels Configuration")
    
    st.info("""
    **Customize all text labels in the HTML dashboard:**
    - Page title and subtitle
    - Section headings
    - Chart titles
    - KPI card labels
    - Filter labels
    - Table column headers
    
    Changes apply when you regenerate the HTML dashboard.
    """)
    
    # Load current labels
    labels_path = APP_DIR / "configuration" / "dashboard_labels.json"
    
    try:
        with open(labels_path, 'r', encoding='utf-8') as f:
            labels = json.load(f)
    except FileNotFoundError:
        st.warning("No dashboard_labels.json found. Creating default configuration...")
        labels = {
            "page": {"title": "Risk Cartography Dashboard", "subtitle": "Corruption Risk Analysis"},
            "sections": {},
            "charts": {},
            "kpi_cards": {},
            "filters": {},
            "table_columns": {}
        }
    
    updated = labels.copy()
    
    # Page Settings
    with st.expander("📄 **Page Title & Subtitle**", expanded=True):
        page = labels.get('page', {})
        c1, c2 = st.columns(2)
        with c1:
            title = st.text_input("Dashboard Title", value=page.get('title', 'Risk Cartography Dashboard'), key="lbl_page_title")
        with c2:
            subtitle = st.text_input("Subtitle", value=page.get('subtitle', 'Corruption Risk Analysis'), key="lbl_page_subtitle")
        updated['page'] = {'title': title, 'subtitle': subtitle}
    
    # Section Headers
    with st.expander("📑 **Section Headers**", expanded=False):
        sections = labels.get('sections', {})
        updated_sections = {}
        
        default_sections = {
            "executive_summary": "Executive Summary",
            "afa_compliance": "AFA Compliance Metrics", 
            "risk_distribution": "Risk Distribution",
            "risk_matrix": "Risk Matrix",
            "entity_analysis": "Entity Analysis",
            "category_analysis": "Category Analysis",
            "detailed_analysis": "Detailed Analysis",
            "risk_details": "Risk Details Table"
        }
        
        for key, default_val in default_sections.items():
            val = st.text_input(f"{key}", value=sections.get(key, default_val), key=f"lbl_sec_{key}")
            updated_sections[key] = val
        
        updated['sections'] = updated_sections
    
    # Chart Titles
    with st.expander("📊 **Chart Titles**", expanded=False):
        charts = labels.get('charts', {})
        updated_charts = {}
        
        default_charts = {
            "risks_by_level": {"title": "Risk Distribution by Severity"},
            "risks_by_category": {"title": "Risks by Category"},
            "risks_by_entity": {"title": "Risks by Entity"},
            "mitigation_status": {"title": "Mitigation Effectiveness"},
            "risk_matrix_gross": {"title": "Risk Matrix — Gross Risk"},
            "risk_matrix_residual": {"title": "Risk Matrix — Residual Risk"},
            "category_radar": {"title": "Category Risk Radar"},
            "top_risks": {"title": "Top 10 Highest Residual Risks"},
            "top_critical": {"title": "Top Critical Risks - Action Required"},
            "entity_summary": {"title": "Entity Summary"}
        }
        
        for key, defaults in default_charts.items():
            current = charts.get(key, defaults)
            if isinstance(current, dict):
                val = st.text_input(f"{key}", value=current.get('title', defaults.get('title', key)), key=f"lbl_chart_{key}")
                updated_charts[key] = {"title": val}
            else:
                val = st.text_input(f"{key}", value=current, key=f"lbl_chart_{key}")
                updated_charts[key] = {"title": val}
        
        updated['charts'] = updated_charts
    
    # KPI Cards
    with st.expander("🔢 **KPI Card Labels**", expanded=False):
        kpis = labels.get('kpi_cards', {})
        updated_kpis = {}
        
        default_kpis = {
            "total_risks": "Total Risks",
            "critical_risks": "Critical Risks",
            "high_risks": "High Risks",
            "moderate_risks": "Moderate Risks",
            "low_risks": "Low Risks",
            "entities_analyzed": "Entities Analyzed",
            "avg_gross_score": "Avg Gross Score",
            "avg_residual_score": "Avg Residual Score",
            "risk_reduction": "Risk Reduction"
        }
        
        for key, default_val in default_kpis.items():
            val = st.text_input(f"{key}", value=kpis.get(key, default_val), key=f"lbl_kpi_{key}")
            updated_kpis[key] = val
        
        updated['kpi_cards'] = updated_kpis
    
    # Filter Labels
    with st.expander("🔍 **Filter Labels**", expanded=False):
        filters = labels.get('filters', {})
        updated_filters = {}
        
        default_filters = {
            "entity_label": "Entity",
            "entity_all": "All Entities",
            "level_label": "Risk Level",
            "level_all": "All Levels",
            "category_label": "Process/Category",
            "category_all": "All Processes",
            "search_placeholder": "Search risks...",
            "reset_filters": "Reset Filters"
        }
        
        for key, default_val in default_filters.items():
            val = st.text_input(f"{key}", value=filters.get(key, default_val), key=f"lbl_flt_{key}")
            updated_filters[key] = val
        
        updated['filters'] = updated_filters
    
    # Table Columns
    with st.expander("📋 **Table Column Headers**", expanded=False):
        cols = labels.get('table_columns', {})
        updated_cols = {}
        
        default_cols = {
            "entity": "Entity",
            "risk_id": "Risk ID",
            "category": "Process",
            "scenario": "Scenario",
            "description": "Description",
            "score_gross": "Gross Score",
            "score_residual": "Residual Score",
            "level_gross": "Gross Level",
            "level_residual": "Residual Level",
            "controls": "Existing Controls",
            "action_plan": "Action Plan"
        }
        
        for key, default_val in default_cols.items():
            val = st.text_input(f"{key}", value=cols.get(key, default_val), key=f"lbl_col_{key}")
            updated_cols[key] = val
        
        updated['table_columns'] = updated_cols
    
    # Risk Level Labels
    with st.expander("🚦 **Risk Level Names**", expanded=False):
        levels = labels.get('risk_levels', {})
        updated_levels = {}
        
        default_levels = {
            "critical": "Critical",
            "critical_emoji": "🔴",
            "high": "High",
            "high_emoji": "🟠",
            "moderate": "Moderate",
            "moderate_emoji": "🟡",
            "low": "Low",
            "low_emoji": "🟢"
        }
        
        for key, default_val in default_levels.items():
            val = st.text_input(f"{key}", value=levels.get(key, default_val), key=f"lbl_lvl_{key}")
            updated_levels[key] = val
        
        updated['risk_levels'] = updated_levels
    
    st.markdown("---")
    
    c1, c2 = st.columns(2)
    with c1:
        if st.button("💾 Save Dashboard Labels"):
            # Ensure directory exists
            labels_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(labels_path, 'w', encoding='utf-8') as f:
                json.dump(updated, f, indent=2, ensure_ascii=False)
            
            st.success("✅ Dashboard labels saved! Regenerate HTML dashboard to apply changes.")
    
    with c2:
        if st.button("🔄 Reset to Defaults"):
            # Delete file to reset
            if labels_path.exists():
                labels_path.unlink()
            st.success("✅ Reset to defaults. Refresh page to see changes.")
            st.rerun()


# === EXECUTOR MODE ===

def render_executor():
    """Executor interface."""
    st.header("🚀 Execute Risk Analysis")
    
    # Step 1: Upload
    st.subheader("📁 Step 1: Upload Excel Files")
    
    # Option to use samples
    use_samples = st.checkbox("📚 Use sample data for demo")
    
    if use_samples:
        sample_files = list(SAMPLES_DIR.glob("*.xlsx"))
        if sample_files:
            st.info(f"Found {len(sample_files)} sample file(s)")
            uploaded_files = sample_files
        else:
            st.warning("No sample files found in /samples/")
            uploaded_files = []
    else:
        uploaded = st.file_uploader("Upload Excel files", type=['xlsx', 'xls'], accept_multiple_files=True)
        uploaded_files = uploaded if uploaded else []
    
    if uploaded_files:
        st.success(f"✅ {len(uploaded_files)} file(s) ready")
        
        with st.expander("👁️ Preview"):
            for uf in uploaded_files[:3]:  # Preview first 3
                if isinstance(uf, Path):
                    st.markdown(f"**{uf.name}**")
                    df = pd.read_excel(uf, nrows=3, engine='openpyxl')
                else:
                    st.markdown(f"**{uf.name}**")
                    df = pd.read_excel(uf, nrows=3, engine='openpyxl')
                    uf.seek(0)
                st.dataframe(df)
    
    # Step 2: Options
    st.markdown("---")
    st.subheader("📤 Step 2: Output Options")
    c1, c2 = st.columns(2)
    with c1:
        gen_html = st.checkbox("📊 HTML Dashboard", value=True)
        gen_pbi = st.checkbox("📈 PowerBI CSVs", value=True)
    with c2:
        gen_xlsx = st.checkbox("📋 Excel Report", value=True)
        gen_entity = st.checkbox("🏢 Entity Dashboards", value=True)
    
    # Step 3: Run
    st.markdown("---")
    st.subheader("▶️ Step 3: Run Analysis")
    
    if not uploaded_files:
        st.warning("⚠️ Upload files or select sample data first")
    
    if st.button("🔥 Run Analysis", disabled=not uploaded_files):
        run_analysis(uploaded_files, use_samples)
    
    # Step 4: Download
    st.markdown("---")
    st.subheader("📥 Step 4: Download Results")
    render_downloads()


def run_analysis(files, use_samples: bool):
    """Execute the analysis pipeline."""
    progress = st.progress(0)
    status = st.empty()
    
    try:
        # Step 1: Prepare input files
        status.text("📁 Preparing files...")
        progress.progress(10)
        
        # Clear input folder
        for f in INPUT_DIR.glob("*.xlsx"):
            f.unlink()
        
        # Copy files to input
        if use_samples:
            for f in files:
                import shutil
                shutil.copy(f, INPUT_DIR / f.name)
        else:
            for f in files:
                with open(INPUT_DIR / f.name, 'wb') as out:
                    out.write(f.getbuffer())
        
        # Step 2: Update configs
        status.text("⚙️ Applying configuration...")
        progress.progress(25)
        
        # Sync session configs to files
        save_config('column_mapping.json', st.session_state.column_mapping)
        save_config('categories.json', st.session_state.categories)
        save_config('risk_levels.json', st.session_state.risk_levels)
        save_config('formulas.json', st.session_state.formulas)
        if 'column_order' in st.session_state:
            save_config('column_order.json', st.session_state.column_order)
        
        # Build column mapping from session state order
        column_order = st.session_state.get('column_order', list(st.session_state.column_mapping.keys()))
        column_index_mapping = {}
        numeric_fields = []
        
        for idx, key in enumerate(column_order):
            column_index_mapping[str(idx)] = key
            # Check if this is a numeric field
            field_config = st.session_state.column_mapping.get(key, {})
            if field_config.get('field_type') == 'numeric' or key in ['prob_gross', 'impact_gross', 'score_gross', 'prob_residual', 'impact_residual', 'score_residual']:
                numeric_fields.append(key)
        
        # Update analysis_config.json for lib/main.py (load existing, update parts)
        analysis_config_path = CONFIG_DIR / 'analysis_config.json'
        if analysis_config_path.exists():
            with open(analysis_config_path, 'r', encoding='utf-8') as f:
                analysis_cfg = json.load(f)
        else:
            # Create minimal valid structure
            analysis_cfg = {
                "input": {"base_directory": "../input/", "files": []},
                "columns": {
                    "mapping": {},
                    "numeric_fields": [],
                    "skip_header_values": ["N°", "N"]
                },
                "risk_levels": {"levels": []},
                "risk_categories": {"categories": []},
                "output": {"directory": "../output/", "dashboard_filename": "risk_dashboard.html"},
                "analysis": {"top_risks_count": 10},
                "dashboard": {"title": "Risk Cartography Dashboard"}
            }
        
        # Update column mapping from session state
        analysis_cfg['columns']['mapping'] = column_index_mapping
        analysis_cfg['columns']['numeric_fields'] = numeric_fields
        
        # Update risk levels from session state
        risk_levels_list = []
        order = 1
        for key in ['low', 'moderate', 'high', 'critical']:
            if key in st.session_state.risk_levels:
                cfg = st.session_state.risk_levels[key]
                risk_levels_list.append({
                    "key": f"{cfg['emoji']} {cfg['label']}",
                    "label_en": cfg['label'],
                    "color": cfg['color'],
                    "order": order,
                    "score_min": cfg['min_score'],
                    "score_max": cfg['max_score']
                })
                order += 1
        analysis_cfg['risk_levels'] = {"levels": risk_levels_list}
        
        # Update categories from session state
        cat_list = []
        for prefix, cfg in st.session_state.categories.items():
            cat_list.append({
                "prefix": prefix,
                "name_en": cfg['name'],
                "color": cfg['color']
            })
        analysis_cfg['risk_categories'] = {"categories": cat_list}
        
        # Update files list from input directory
        files_list = []
        for f in INPUT_DIR.glob("*.xlsx"):
            entity = f.stem.replace("risk_cartography_", "").replace("sample_", "").replace("_", " ").title()
            files_list.append({
                "filename": f.name,
                "entity_name": entity,
                "enabled": True,
                "sheet_name": "All",
                "skip_rows": 3
            })
        analysis_cfg['input']['files'] = files_list
        
        # Save updated config
        with open(analysis_config_path, 'w', encoding='utf-8') as f:
            json.dump(analysis_cfg, f, indent=2, ensure_ascii=False)
        
        # Step 3: Run main.py
        status.text("📊 Running analysis...")
        progress.progress(50)
        
        # Use the SAME Python interpreter that's running this script
        # This ensures we use the venv's Python, not the global one
        python_cmd = sys.executable
        
        # Set encoding environment variables for subprocess
        sub_env = os.environ.copy()
        sub_env['PYTHONIOENCODING'] = 'utf-8'
        sub_env['PYTHONUTF8'] = '1'
        sub_env['CONFIG_DIR'] = str(CONFIG_DIR)
        sub_env['OUTPUT_DIR'] = str(OUTPUT_DIR)
        sub_env['INPUT_DIR'] = str(INPUT_DIR)
        
        result = subprocess.run(
            [python_cmd, str(LIB_DIR / 'run_analysis.py')],
            cwd=str(APP_DIR),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=sub_env
        )
        
        # Safe decode with error handling
        try:
            result.stdout = result.stdout.decode('utf-8', errors='replace') if result.stdout else ''
        except:
            result.stdout = str(result.stdout)
        try:
            result.stderr = result.stderr.decode('utf-8', errors='replace') if result.stderr else ''
        except:
            result.stderr = str(result.stderr)
        
        progress.progress(90)
        
        if result.returncode == 0:
            status.text("✅ Complete!")
            progress.progress(100)
            st.success("🎉 Analysis completed!")
            
            with st.expander("📋 Log"):
                st.code(result.stdout)
            
            # Summary metrics
            st.markdown("### 📦 Generated Files")
            c1, c2, c3, c4 = st.columns(4)
            with c1:
                st.metric("HTML", len(list(OUTPUT_DIR.glob("*.html"))))
            with c2:
                st.metric("PDF", len(list(OUTPUT_DIR.glob("*.pdf"))))
            with c3:
                st.metric("CSV", len(list(OUTPUT_DIR.glob("powerbi_*.csv"))))
            with c4:
                st.metric("Excel", len(list(OUTPUT_DIR.glob("*.xlsx"))))
        else:
            st.error("❌ Analysis failed")
            with st.expander("❌ Error"):
                st.code(result.stderr or result.stdout)
    
    except Exception as e:
        st.error(f"❌ Error: {e}")
        import traceback
        st.code(traceback.format_exc())


def render_downloads():
    """Render download section."""
    output_type = st.selectbox("Select type", ["HTML Dashboards", "PDF Reports", "CSV (PowerBI)", "Excel Report"])
    
    if output_type == "HTML Dashboards":
        files = list(OUTPUT_DIR.glob("*.html"))
    elif output_type == "PDF Reports":
        files = list(OUTPUT_DIR.glob("*.pdf"))
    elif output_type == "CSV (PowerBI)":
        files = list(OUTPUT_DIR.glob("powerbi_*.csv"))
    else:
        files = list(OUTPUT_DIR.glob("*.xlsx"))
    
    if files:
        # Add download all button for multiple files
        if len(files) > 1:
            st.info(f"📁 {len(files)} file(s) available")
        
        for f in files:
            c1, c2 = st.columns([3, 1])
            with c1:
                # Show file size
                size_kb = f.stat().st_size / 1024
                st.markdown(f"📄 **{f.name}** ({size_kb:.1f} KB)")
            with c2:
                with open(f, 'rb') as data:
                    if f.suffix == ".html":
                        mime = "text/html"
                    elif f.suffix == ".pdf":
                        mime = "application/pdf"
                    elif f.suffix == ".csv":
                        mime = "text/csv"
                    else:
                        mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    st.download_button("Download", data.read(), file_name=f.name, mime=mime, key=f"dl_{f.name}")
    else:
        st.info("No files yet. Run analysis first.")


# === WIKI MODE ===

def render_wiki_overview():
    """Wiki: Application overview."""
    st.header("📖 Risk Cartography - Documentation")
    
    st.markdown("""
    ## Welcome to Risk Cartography
    
    This application generates **interactive dashboards** for analyzing corruption risk 
    cartographies in compliance with **AFA (Agence Française Anticorruption)** and 
    **Sapin II** regulations.
    
    ---
    
    ### 🎯 Purpose
    
    | Objective | Description |
    |-----------|-------------|
    | **Visualize Risks** | Transform Excel risk data into interactive dashboards |
    | **Track Mitigation** | Compare inherent vs residual risk levels |
    | **Compliance** | Meet AFA/Sapin II reporting requirements |
    | **Export** | Generate PowerBI-ready files for further analysis |
    
    ---
    
    ### 🔄 Workflow
    
    ```
    ┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
    │   UPLOAD    │ ──► │  CONFIGURE  │ ──► │   ANALYZE   │ ──► │   EXPORT    │
    │ Excel Files │     │  Settings   │     │    Data     │     │ Dashboards  │
    └─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
    ```
    
    ---
    
    ### 📂 Application Modes
    
    | Mode | Icon | Description |
    |------|------|-------------|
    | **Executor** | 🚀 | Upload files, run analysis, download results |
    | **Admin** | ⚙️ | Configure columns, categories, risk levels, formulas |
    | **Wiki** | 📖 | Documentation and help (you are here) |
    
    ---
    
    ### 📁 Folder Structure
    
    ```
    RISK_CARTOGRAPHY_v1.0/
    ├── app.py              # Main application
    ├── config/             # Configuration files (editable via Admin)
    ├── input/              # Drop your Excel files here
    ├── output/             # Generated dashboards appear here
    ├── samples/            # Demo data for testing
    └── lib/                # Core processing modules
    ```
    """)


def render_wiki_dashboard():
    """Wiki: How to read the dashboard."""
    st.header("📊 Dashboard Guide")
    
    st.markdown("""
    ## Understanding the Dashboard
    
    The HTML dashboard provides a comprehensive view of your risk cartography analysis.
    
    ---
    
    ### 🎯 KPI Cards (Top Row)
    
    Four key performance indicators are displayed at the top:
    
    | Card | Metric | Interpretation |
    |------|--------|----------------|
    | **Total Risks** | Count of all risk scenarios | Higher = more comprehensive coverage |
    | **Critical Risks** | Risks with score ≥ 12 | ⚠️ Require immediate attention |
    | **Avg Score** | Mean of residual scores | Lower is better (target < 4) |
    | **Mitigation Rate** | % of improved risks | Higher = better control effectiveness |
    
    ---
    
    ### 📈 Risk Level Distribution (Pie Chart)
    
    Shows the proportion of risks in each level:
    
    | Level | Color | Score Range | Action Required |
    |-------|-------|-------------|-----------------|
    | 🟢 **Low** | Green | 1-3 | Monitor periodically |
    | 🟡 **Moderate** | Yellow | 4-6 | Review controls quarterly |
    | 🟠 **High** | Orange | 8-9 | Strengthen controls |
    | 🔴 **Critical** | Red | 12-16 | Immediate action required |
    
    **Reading tip:** Ideally, the pie should be mostly green/yellow after mitigation.
    
    ---
    
    ### 📊 Risk Matrix (Heatmap)
    
    A 4×4 matrix showing Probability vs Impact:
    
    ```
           IMPACT →
         │ 1 │ 2 │ 3 │ 4 │
       ──┼───┼───┼───┼───┤
       4 │ 4 │ 8 │12 │16 │  ▲
       3 │ 3 │ 6 │ 9 │12 │  │
       2 │ 2 │ 4 │ 6 │ 8 │  PROBABILITY
       1 │ 1 │ 2 │ 3 │ 4 │  │
    ```
    
    **Reading tip:** Risks should migrate from top-right (critical) to bottom-left (low) after controls.
    
    ---
    
    ### 📉 Gross vs Residual Comparison (Bar Chart)
    
    Compares inherent risk (before controls) vs residual risk (after controls):
    
    - **Blue bars**: Gross/Inherent scores
    - **Green bars**: Residual scores
    - **Gap between bars**: Risk reduction achieved
    
    **Reading tip:** Larger gaps indicate effective mitigation measures.
    
    ---
    
    ### 🏢 Entity Navigation
    
    Click on entity cards to drill down into specific business unit dashboards.
    Each entity dashboard shows:
    - Entity-specific KPIs
    - Top risks for that entity
    - Category breakdown
    - Back link to global dashboard
    """)


def render_wiki_charts():
    """Wiki: Charts and graphs explanation."""
    st.header("📈 Charts & Graphs")
    
    st.markdown("""
    ## Chart Types and Interpretation
    
    ---
    
    ### 1️⃣ Risk Level Pie Chart
    
    **Purpose:** Show distribution of risks across severity levels
    
    **How to read:**
    - Each slice = one risk level (Critical, High, Moderate, Low)
    - Slice size = proportion of total risks
    - Hover for exact count and percentage
    
    **AFA/Sapin II context:** Regulators expect to see a balanced distribution 
    with no more than 10-15% in Critical/High after mitigation.
    
    ---
    
    ### 2️⃣ Category Radar Chart
    
    **Purpose:** Compare risk exposure across business categories
    
    **How to read:**
    - Each axis = one category (Procurement, Commercial, HR, etc.)
    - Distance from center = average risk score for that category
    - Shape shows relative exposure areas
    
    **Interpretation:**
    - Spiky shape = uneven risk distribution (focus on spikes)
    - Circular shape = balanced risk across categories
    
    ---
    
    ### 3️⃣ Gross vs Residual Bar Chart
    
    **Purpose:** Measure control effectiveness
    
    **How to read:**
    - Grouped bars: Blue (Gross) vs Green (Residual)
    - Each group = one risk category or entity
    - Bar height = average risk score
    
    **Key metric:** `Reduction % = (Gross - Residual) / Gross × 100`
    
    | Reduction | Interpretation |
    |-----------|----------------|
    | > 50% | Excellent control effectiveness |
    | 30-50% | Good mitigation |
    | 10-30% | Adequate but improvable |
    | < 10% | Controls need strengthening |
    
    ---
    
    ### 4️⃣ Top Risks Table
    
    **Purpose:** Highlight highest-priority risks
    
    **Columns:**
    | Column | Description |
    |--------|-------------|
    | Risk ID | Unique identifier (e.g., A1, B3, C7) |
    | Scenario | Description of the risk |
    | Gross Score | Inherent risk level |
    | Residual Score | After-control risk level |
    | Status | Improved/Unchanged/Worsened |
    
    **Priority order:** Sorted by residual score (highest first)
    
    ---
    
    ### 5️⃣ Mitigation Status Pie
    
    **Purpose:** Show control effectiveness overview
    
    **Segments:**
    - 🟢 **Improved:** Residual < Gross (controls working)
    - 🟡 **Unchanged:** Residual = Gross (controls ineffective)
    - 🔴 **Worsened:** Residual > Gross (rare, indicates new factors)
    
    **AFA/Sapin II target:** ≥ 70% of risks should be "Improved"
    """)


def render_wiki_formulas():
    """Wiki: Calculation formulas."""
    st.header("📐 Formulas & Calculations")
    
    st.markdown("""
    ## Risk Calculation Methodology
    
    ---
    
    ### 🎯 Core Formula: Risk Score
    
    ```
    Risk Score = Probability × Impact
    ```
    
    | Component | Scale | Description |
    |-----------|-------|-------------|
    | **Probability** | 1-4 | Likelihood of occurrence |
    | **Impact** | 1-4 | Severity of consequences |
    | **Score** | 1-16 | Combined risk rating |
    
    ---
    
    ### 📊 Probability Scale
    
    | Value | Label | Definition |
    |-------|-------|------------|
    | 1 | Rare | < 10% chance per year |
    | 2 | Unlikely | 10-30% chance per year |
    | 3 | Possible | 30-60% chance per year |
    | 4 | Likely | > 60% chance per year |
    
    ---
    
    ### 💥 Impact Scale
    
    | Value | Label | Definition |
    |-------|-------|------------|
    | 1 | Minor | Negligible financial/reputational impact |
    | 2 | Moderate | < €100K or limited reputation damage |
    | 3 | Significant | €100K-1M or significant reputation damage |
    | 4 | Critical | > €1M or severe legal/reputation impact |
    
    ---
    
    ### 🚦 Risk Level Classification
    
    | Score Range | Level | Color | Required Action |
    |-------------|-------|-------|-----------------|
    | 1-3 | 🟢 Low | Green | Monitor |
    | 4-6 | 🟡 Moderate | Yellow | Review |
    | 8-9 | 🟠 High | Orange | Mitigate |
    | 12-16 | 🔴 Critical | Red | Urgent action |
    
    **Note:** Scores 7, 10, 11 are not achievable (no P×I combination produces them).
    
    ---
    
    ### 📉 Derived Metrics
    
    #### Risk Reduction Percentage
    ```
    Risk Reduction % = ((Gross Score - Residual Score) / Gross Score) × 100
    ```
    
    **Example:** Gross=12, Residual=6 → (12-6)/12 × 100 = **50% reduction**
    
    ---
    
    #### Mitigation Rate
    ```
    Mitigation Rate = (Number of Improved Risks / Total Risks) × 100
    ```
    
    **Improved** = where Residual Score < Gross Score
    
    ---
    
    #### Urgency Score (Weighted Priority Index)
    ```
    Urgency = (Critical×4 + High×2 + Moderate×1) / (Total×4) × 100
    ```
    
    | Urgency | Interpretation |
    |---------|----------------|
    | > 75% | Portfolio severely at risk |
    | 50-75% | High attention needed |
    | 25-50% | Moderate risk exposure |
    | < 25% | Well-controlled portfolio |
    
    ---
    
    #### Average Score
    ```
    Average Score = Sum of all Residual Scores / Number of Risks
    ```
    
    **Target:** Average < 4.0 indicates well-managed risk portfolio
    """)


def render_wiki_outputs():
    """Wiki: Output file formats."""
    st.header("📁 Output Files")
    
    st.markdown("""
    ## Generated File Formats
    
    The application generates four types of output files:
    
    ---
    
    ### 📊 1. HTML Dashboards
    
    | File | Description |
    |------|-------------|
    | `risk_dashboard.html` | Global dashboard with all entities |
    | `entity_*.html` | Individual entity dashboards |
    
    **Features:**
    - Interactive charts (Chart.js)
    - Responsive design
    - Help tooltips on hover
    - Entity drill-down links
    - Self-contained (no server required)
    
    **Usage:** Open in any modern browser (Chrome, Firefox, Edge)
    
    ---
    
    ### 📄 2. PDF Reports
    
    Professional PDF reports for management presentations:
    
    | File | Description |
    |------|-------------|
    | `risk_report.pdf` | Main consolidated report |
    | `report_entity_*.pdf` | Individual entity reports |
    
    **Contents:**
    - KPI cards with visual indicators
    - Risk level distribution pie chart
    - Category Risk Radar chart
    - Gross vs Residual bar charts
    - Top Priority Risks table
    - AFA Compliance metrics
    
    **Usage:** Print, email, or present to management/auditors
    
    ---
    
    ### 📈 3. PowerBI CSV Files
    
    Ready-to-import files for Microsoft Power BI:
    
    | File | Contents | Use in PowerBI |
    |------|----------|----------------|
    | `powerbi_kpi_summary.csv` | KPI metrics | Card visuals, scorecards |
    | `powerbi_level_distribution.csv` | Risk counts by level | Pie/donut charts |
    | `powerbi_top_risks.csv` | Top N risks sorted | Tables, matrices |
    | `powerbi_category_scores.csv` | Scores by category | Radar, bar charts |
    | `powerbi_entity_drilldown.csv` | Entity-level KPIs | Slicers, drill-through |
    | `powerbi_mitigation.csv` | Before/after comparison | Clustered bar charts |
    | `powerbi_executive_summary.csv` | High-level summary | Executive dashboard |
    
    **Schema for `powerbi_kpi_summary.csv`:**
    ```csv
    metric,value,unit,threshold,status
    Total Risks,256,count,,info
    Critical Risks,12,count,15,warning
    Average Score,4.2,score,5,good
    Mitigation Rate,78.5,%,70,good
    ```
    
    ---
    
    ### 📋 4. Excel Report
    
    | Sheet | Contents |
    |-------|----------|
    | Summary | Key metrics and charts |
    | Raw Data | All risk records |
    | By Level | Distribution statistics |
    | By Category | Category breakdown |
    | By Entity | Entity comparison |
    
    **Usage:** Further analysis, manual reporting, archival
    
    ---
    
    ### 📂 Output Directory Structure
    
    ```
    output/
    ├── risk_dashboard.html           # Main HTML dashboard
    ├── entity_*.html                 # Entity dashboards
    │
    ├── risk_report.pdf               # Main PDF report
    ├── report_entity_*.pdf           # Entity PDF reports
    │
    ├── powerbi_kpi_summary.csv       # PowerBI files
    ├── powerbi_level_distribution.csv
    ├── powerbi_top_risks.csv
    ├── powerbi_category_scores.csv
    ├── powerbi_entity_drilldown.csv
    ├── powerbi_mitigation.csv
    ├── powerbi_executive_summary.csv
    ├── powerbi_raw_data.csv
    ├── powerbi_analysis.json
    │
    └── risk_analysis_report.xlsx     # Excel workbook
    ```
    """)


def render_wiki_compliance():
    """Wiki: AFA/Sapin II compliance information."""
    st.header("⚖️ AFA / Sapin II Compliance")
    
    st.markdown("""
    ## Regulatory Framework
    
    ---
    
    ### 📜 Sapin II Law (2016)
    
    The French **Sapin II Law** (Law No. 2016-1691 of December 9, 2016) requires 
    companies meeting certain thresholds to implement an **anti-corruption program** 
    with 8 mandatory pillars:
    
    | # | Pillar | This Tool Supports |
    |---|--------|-------------------|
    | 1 | Code of Conduct | ❌ |
    | 2 | Internal Whistleblowing | ❌ |
    | 3 | **Risk Mapping** | ✅ **Primary function** |
    | 4 | Third-Party Due Diligence | ❌ |
    | 5 | Accounting Controls | ❌ |
    | 6 | Training | ❌ |
    | 7 | Disciplinary Sanctions | ❌ |
    | 8 | Internal Controls | ✅ Mitigation tracking |
    
    ---
    
    ### 🏛️ AFA (Agence Française Anticorruption)
    
    The AFA is the French national anti-corruption agency that:
    - Issues guidelines for compliance programs
    - Conducts audits on qualifying companies
    - Publishes recommendations for risk mapping
    
    ---
    
    ### 📋 AFA Risk Mapping Requirements
    
    According to AFA guidelines, a compliant risk map must:
    
    | Requirement | Implementation in This Tool |
    |-------------|----------------------------|
    | **Identify risks** by process | Risk scenarios linked to processes |
    | **Assess probability** | 4-level probability scale |
    | **Assess impact** | 4-level impact scale |
    | **Calculate inherent risk** | P × I = Score (Gross) |
    | **Document controls** | Prevention measures field |
    | **Calculate residual risk** | P × I = Score (Residual) |
    | **Prioritize actions** | Top risks list, urgency score |
    | **Update regularly** | Version tracking, re-execution |
    
    ---
    
    ### ✅ Compliance Checklist
    
    Use this checklist to ensure your risk mapping meets AFA expectations:
    
    """)
    
    # Interactive checklist
    checks = [
        ("Coverage", "All corruption-exposed processes are in scope"),
        ("Scenarios", "Risk scenarios are specific and documented"),
        ("Methodology", "Probability × Impact scoring is applied consistently"),
        ("Inherent vs Residual", "Both gross and net assessments are performed"),
        ("Controls", "Mitigation measures are documented for each risk"),
        ("Ownership", "Each risk has an identified owner"),
        ("Review", "Risk map is reviewed at least annually"),
        ("Board Reporting", "Summary is reported to management/board")
    ]
    
    for label, desc in checks:
        st.checkbox(f"**{label}:** {desc}")
    
    st.markdown("""
    ---
    
    ### 📊 Expected Distribution (AFA Benchmark)
    
    After effective mitigation, a well-managed risk portfolio should show:
    
    | Level | Target Range | Concern Threshold |
    |-------|-------------|-------------------|
    | 🟢 Low | 40-60% | < 30% |
    | 🟡 Moderate | 30-40% | N/A |
    | 🟠 High | 5-15% | > 25% |
    | 🔴 Critical | < 5% | > 10% |
    
    **Overall mitigation rate target:** ≥ 70%
    
    ---
    
    ### 📚 References
    
    - [AFA Official Website](https://www.agence-francaise-anticorruption.gouv.fr/)
    - [Sapin II Law Text](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000033558528)
    - [AFA Guidelines (PDF)](https://www.agence-francaise-anticorruption.gouv.fr/files/files/AFA_recommandations.pdf)
    """)


def render_wiki(section):
    """Main wiki renderer that dispatches to subsections."""
    if section == "Overview":
        render_wiki_overview()
    elif section == "Dashboard Guide":
        render_wiki_dashboard()
    elif section == "Charts & Graphs":
        render_wiki_charts()
    elif section == "Formulas":
        render_wiki_formulas()
    elif section == "Output Files":
        render_wiki_outputs()
    elif section == "AFA/Sapin II":
        render_wiki_compliance()


# === MAIN ===

def main():
    init_session_state()
    mode, section = render_sidebar()
    
    if mode == "admin":
        if section == "Column Mapping":
            render_column_mapping_admin()
        elif section == "Categories":
            render_categories_admin()
        elif section == "Risk Levels":
            render_risk_levels_admin()
        elif section == "Formulas":
            render_formulas_admin()
        elif section == "Dashboard Labels":
            render_dashboard_labels_admin()
    elif mode == "wiki":
        render_wiki(section)
    else:
        render_executor()
    
    # Footer
    st.sidebar.markdown("---")
    st.sidebar.caption("Risk Cartography v1.0")
    st.sidebar.caption("AFA / Sapin II Compliance")
    st.sidebar.caption(f"© {datetime.now().year}")


if __name__ == "__main__":
    main()
