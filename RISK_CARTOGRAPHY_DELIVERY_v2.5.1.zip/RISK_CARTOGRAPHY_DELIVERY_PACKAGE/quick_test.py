#!/usr/bin/env python3
"""
QUICK TEST SCRIPT - Run this to diagnose issues
Usage: python quick_test.py

This will test each component and show exactly what fails.
"""

import sys
import os

print("=" * 60)
print("  RISK CARTOGRAPHY - QUICK DIAGNOSTIC TEST")
print("=" * 60)
print()

# Store all issues
issues = []

# ========================================
# TEST 1: Python Version
# ========================================
print("[1/6] PYTHON VERSION")
py_ver = sys.version_info
print(f"       Python {py_ver.major}.{py_ver.minor}.{py_ver.micro}")
if py_ver.major < 3 or (py_ver.major == 3 and py_ver.minor < 6):
    issues.append("Python 3.6+ required")
    print("       [FAIL] Need Python 3.6+")
else:
    print("       [OK]")
print()

# ========================================
# TEST 2: Required Packages
# ========================================
print("[2/6] REQUIRED PACKAGES")
packages_status = {}

for pkg in ['pandas', 'openpyxl', 'reportlab', 'xlsxwriter']:
    try:
        mod = __import__(pkg)
        ver = getattr(mod, '__version__', '?')
        packages_status[pkg] = (True, ver)
        print(f"       [OK] {pkg} ({ver})")
    except ImportError as e:
        packages_status[pkg] = (False, str(e))
        issues.append(f"Missing package: {pkg}")
        print(f"       [FAIL] {pkg} - pip install {pkg}")
print()

# ========================================
# TEST 3: Demo Data Files
# ========================================
print("[3/6] DEMO DATA FILES")
demo_dir = os.path.join(os.path.dirname(__file__), 'demo_input')
if os.path.exists(demo_dir):
    files = [f for f in os.listdir(demo_dir) if f.endswith('.xlsx')]
    print(f"       Found {len(files)} demo files")
    if len(files) > 0:
        print("       [OK]")
    else:
        issues.append("No demo Excel files found")
        print("       [FAIL] No .xlsx files in demo_input/")
else:
    issues.append("demo_input folder missing")
    print("       [FAIL] demo_input/ folder not found")
print()

# ========================================
# TEST 4: Read Demo Data
# ========================================
print("[4/6] READING DEMO DATA")
if packages_status.get('pandas', (False,))[0] and packages_status.get('openpyxl', (False,))[0]:
    try:
        import pandas as pd
        demo_file = os.path.join(demo_dir, os.listdir(demo_dir)[0]) if os.path.exists(demo_dir) else None
        if demo_file and os.path.exists(demo_file):
            df = pd.read_excel(demo_file, engine='openpyxl')
            print(f"       Read {len(df)} rows from {os.path.basename(demo_file)}")
            print("       [OK]")
        else:
            issues.append("Cannot find demo file to read")
            print("       [FAIL] No demo file to test")
    except Exception as e:
        issues.append(f"Excel read error: {e}")
        print(f"       [FAIL] {e}")
else:
    print("       [SKIP] Missing pandas or openpyxl")
print()

# ========================================
# TEST 5: PDF Generation
# ========================================
print("[5/6] PDF GENERATION")
if packages_status.get('reportlab', (False,))[0]:
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
        import tempfile
        
        # Try creating a temp PDF
        with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as f:
            c = canvas.Canvas(f.name, pagesize=A4)
            c.drawString(100, 750, "Test PDF")
            c.save()
            pdf_size = os.path.getsize(f.name)
            os.unlink(f.name)
        
        print(f"       Created test PDF ({pdf_size} bytes)")
        print("       [OK]")
    except Exception as e:
        issues.append(f"PDF generation error: {e}")
        print(f"       [FAIL] {e}")
else:
    issues.append("reportlab not installed - PDFs won't generate")
    print("       [FAIL] reportlab not installed")
print()

# ========================================
# TEST 6: Output Directory
# ========================================
print("[6/6] OUTPUT DIRECTORY")
output_dir = os.path.join(os.path.dirname(__file__), 'output')
if os.path.exists(output_dir):
    # Check write permission
    test_file = os.path.join(output_dir, '_test_write.txt')
    try:
        with open(test_file, 'w') as f:
            f.write('test')
        os.unlink(test_file)
        print("       output/ folder exists and is writable")
        print("       [OK]")
    except Exception as e:
        issues.append(f"Cannot write to output/: {e}")
        print(f"       [FAIL] Cannot write: {e}")
else:
    try:
        os.makedirs(output_dir)
        print("       Created output/ folder")
        print("       [OK]")
    except Exception as e:
        issues.append(f"Cannot create output/: {e}")
        print(f"       [FAIL] {e}")
print()

# ========================================
# SUMMARY
# ========================================
print("=" * 60)
if issues:
    print("  ISSUES FOUND:")
    print("=" * 60)
    for i, issue in enumerate(issues, 1):
        print(f"  {i}. {issue}")
    print()
    print("  FIX COMMAND:")
    print("  pip install pandas openpyxl reportlab xlsxwriter")
else:
    print("  ALL TESTS PASSED!")
    print("=" * 60)
    print()
    print("  Next step - run the analysis:")
    print("  python lib/run_analysis.py demo_input -o output -v")

print()
print("=" * 60)

# ========================================
# BONUS: Test full analysis if all OK
# ========================================
if not issues:
    print()
    response = input("Run full analysis test now? [y/N] ").strip().lower()
    if response == 'y':
        print()
        print("Running: python lib/run_analysis.py demo_input -o output -v")
        print("-" * 60)
        os.system(f"{sys.executable} lib/run_analysis.py demo_input -o output -v")
