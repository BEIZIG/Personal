"""
================================================================================
DASHBOARD BUILDER MODULE
================================================================================

PURPOSE:
    This module generates interactive HTML dashboards for visualizing
    risk cartography data. The dashboard includes charts, tables, filters,
    and drill-down capabilities.

WHAT IT DOES:
    1. Creates an interactive HTML dashboard
    2. Generates pie charts, bar charts, radar charts
    3. Adds filtering by entity, level, and category
    4. Enables search functionality
    5. Shows detailed risk information in modals
    6. Supports dark/light theme toggle
    7. Allows PDF export from browser

KEY FEATURES:
    - Interactive filters (entity, level, category)
    - Search functionality across all risks
    - Drill-down modals with full risk details
    - Dark/Light theme toggle
    - Animated transitions and hover effects
    - Executive summary with key insights
    - Alert panel for critical risks
    - Sortable/filterable tables
    - Real-time statistics updates

KEY CLASSES:
    - EnhancedDashboardGenerator: Main class for creating dashboards

EXAMPLE USAGE:
    from dashboard_builder import EnhancedDashboardGenerator
    
    generator = EnhancedDashboardGenerator()
    generator.generate_with_analysis(
        df=dataframe,
        analysis=analysis,
        output_path='output/dashboard.html'
    )

OUTPUT:
    - A single HTML file with embedded CSS and JavaScript
    - No external dependencies required to view
    - Opens directly in any modern web browser

CUSTOMIZATION:
    - Edit configuration/dashboard_labels.json for text labels
    - Edit configuration/dashboard_help.json for help tooltips
    - Colors are defined in the JSON configuration file

AUTHOR: Risk Management Team
VERSION: 2.0.0
================================================================================
"""

import json
from datetime import datetime
from typing import Dict, List, Optional, Any
from pathlib import Path
import logging

import pandas as pd

# Handle both package and direct imports
try:
    from .risk_analyzer import RiskAnalysis
    from .config_manager import DashboardColors
except ImportError:
    from risk_analyzer import RiskAnalysis
    from config_manager import DashboardColors

logger = logging.getLogger(__name__)

DEFAULT_COLORS = DashboardColors()


def load_dashboard_labels(config_path: str = None) -> Dict:
    """Load dashboard labels from JSON configuration file."""
    if config_path is None:
        # Default path relative to this file
        lib_dir = Path(__file__).parent
        config_path = lib_dir.parent / "configuration" / "dashboard_labels.json"
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        logger.warning(f"Dashboard labels not found at {config_path}, using defaults")
        return get_default_labels()
    except json.JSONDecodeError as e:
        logger.error(f"Error parsing dashboard labels: {e}")
        return get_default_labels()


def get_default_labels() -> Dict:
    """Return default labels if config file not found."""
    return {
        "page": {"title": "Risk Cartography Dashboard", "subtitle": "Corruption Risk Analysis"},
        "charts": {
            "risks_by_level": {"title": "Risk Distribution by Severity"},
            "risks_by_category": {"title": "Risks by Category"},
            "risks_by_entity": {"title": "Risks by Entity"},
            "mitigation_status": {"title": "Mitigation Effectiveness"},
            "risk_matrix": {"title": "Risk Matrix", "x_axis": "Impact", "y_axis": "Probability"}
        },
        "kpi_cards": {
            "total_risks": "Total Risks",
            "critical_risks": "Critical Risks",
            "high_risks": "High Risks",
            "entities_analyzed": "Entities Analyzed"
        },
        "filters": {
            "entity_label": "Entity", "entity_all": "All Entities",
            "level_label": "Risk Level", "level_all": "All Levels",
            "category_label": "Process", "category_all": "All Processes",
            "search_placeholder": "Search risks..."
        },
        "risk_levels": {
            "critical": "🔴 Critical", "high": "🟠 High",
            "moderate": "🟡 Moderate", "low": "🟢 Low"
        },
        "table_columns": {
            "entity": "Entity", "risk_id": "Risk ID", "category": "Process",
            "scenario": "Scenario", "description": "Description",
            "score_gross": "Gross Score", "score_residual": "Residual Score",
            "level_residual": "Residual Level"
        }
    }


def load_dashboard_help(config_path: str = None) -> Dict:
    """Load dashboard help tooltips from JSON configuration file."""
    if config_path is None:
        lib_dir = Path(__file__).parent
        config_path = lib_dir.parent / "configuration" / "dashboard_help.json"
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        logger.warning(f"Dashboard help not found at {config_path}, using defaults")
        return get_default_help()
    except json.JSONDecodeError as e:
        logger.error(f"Error parsing dashboard help: {e}")
        return get_default_help()


def get_default_help() -> Dict:
    """Return default help content if config file not found."""
    return {
        "sections": {
            "executive_summary": {
                "title": "Executive Summary", 
                "help": "HIGH-LEVEL RISK OVERVIEW\n\n" +
                        "This section provides at-a-glance insights for executives:\n\n" +
                        "• Risk Severity Index: Weighted average of all residual scores (1-16 scale)\n" +
                        "  - Green (≤5): Low overall exposure\n" +
                        "  - Yellow (5-8): Moderate, monitor closely\n" +
                        "  - Red (>8): High, requires management attention\n\n" +
                        "• Key Alerts: Critical/High risks needing immediate action\n\n" +
                        "• Control Effectiveness: Overall % risk reduction achieved"
            },
            "afa_compliance": {
                "title": "AFA Compliance", 
                "help": "SAPIN II / AFA COMPLIANCE METRICS\n\n" +
                        "Measures alignment with Article 17 of Sapin II law:\n\n" +
                        "• Risk Mapping Coverage: % of processes with documented risks\n" +
                        "  - Target: 100% of corruption-exposed processes\n\n" +
                        "• Control Coverage: % risks with documented controls\n" +
                        "  - AFA Expectation: All significant risks controlled\n\n" +
                        "• Third-Party Exposure: % risks involving external parties\n" +
                        "  - Triggers Pillar 4 due diligence requirements\n\n" +
                        "• Remediation Rate: % of High/Critical risks with action plans"
            },
            "kpi_cards": {
                "title": "KPIs", 
                "help": "KEY PERFORMANCE INDICATORS\n\n" +
                        "📊 Total Risks: Count of all mapped corruption scenarios\n\n" +
                        "🔴 Critical: Score 12-16 (P≥3 AND I≥3)\n" +
                        "   Action: Immediate escalation to management\n\n" +
                        "🟠 High: Score 8-9\n" +
                        "   Action: Remediation plan within 30 days\n\n" +
                        "⚠️ Appetite Breach: % risks exceeding acceptable level\n" +
                        "   Formula: (Critical + High) ÷ Total × 100\n" +
                        "   Target: <20% for AFA compliance\n" +
                        "   - ≤15%: ✓ Good (green)\n" +
                        "   - 15-30%: ⚠ Attention (yellow)\n" +
                        "   - >30%: ⛔ Critical (red)\n\n" +
                        "✓ Mitigated: Risks where controls reduced the score\n\n" +
                        "📉 Reduction: Overall improvement from Gross to Residual\n" +
                        "   Formula: (Avg Gross - Avg Residual) ÷ Avg Gross × 100\n" +
                        "   Target: >30% demonstrates control effectiveness"
            },
            "risk_level_chart": {
                "title": "Risk Levels", 
                "help": "RISK DISTRIBUTION BY SEVERITY\n\n" +
                        "Shows count of risks in each AFA risk level:\n\n" +
                        "🟢 Low (Score 1-3): Acceptable risk\n" +
                        "   No specific action required, periodic monitoring\n\n" +
                        "🟡 Moderate (Score 4-6): Tolerable with controls\n" +
                        "   Monitor effectiveness, review annually\n\n" +
                        "🟠 High (Score 8-9): Above appetite\n" +
                        "   Requires documented action plan\n\n" +
                        "🔴 Critical (Score 12-16): Unacceptable\n" +
                        "   Immediate action, management oversight\n\n" +
                        "IDEAL PROFILE:\n" +
                        "• Low+Moderate: >75%\n" +
                        "• High: <20%\n" +
                        "• Critical: <5%"
            },
            "category_chart": {
                "title": "Category Chart", 
                "help": "RISKS BY AFA CORRUPTION CATEGORY\n\n" +
                        "The 7 standard AFA corruption risk processes:\n\n" +
                        "A - Procurement/Purchasing\n" +
                        "    Supplier kickbacks, bid rigging, false invoicing\n\n" +
                        "C - Commercial/Sales\n" +
                        "    Client bribery, facilitation payments\n\n" +
                        "R - Human Resources\n" +
                        "    Hiring fraud, conflict of interest\n\n" +
                        "F - Finance/Accounting\n" +
                        "    Fraudulent entries, expense fraud\n\n" +
                        "M - M&A / Joint Ventures\n" +
                        "    Partner conflicts, due diligence failures\n\n" +
                        "S - Sponsoring/Donations\n" +
                        "    Hidden bribes via sponsorship\n\n" +
                        "P - Public Officials\n" +
                        "    Gifts, lobbying, influence peddling\n\n" +
                        "INTERPRETATION:\n" +
                        "Higher bars = More risk scenarios identified\n" +
                        "Click bars to filter the risk table"
            },
            "entity_chart": {
                "title": "Entity Chart", 
                "help": "RISKS BY ENTITY / BUSINESS UNIT\n\n" +
                        "Stacked bar showing risk severity per entity:\n\n" +
                        "🔴 Critical (dark red)\n" +
                        "🟠 High (orange)\n" +
                        "🟡 Moderate (yellow)\n" +
                        "🟢 Low (green)\n\n" +
                        "HOW TO READ:\n" +
                        "• Taller bars = More total risks\n" +
                        "• More red/orange = Higher exposure\n" +
                        "• Compare entities to identify hotspots\n\n" +
                        "ACTION:\n" +
                        "Click entity name to open its dedicated dashboard"
            },
            "mitigation_chart": {
                "title": "Mitigation Chart", 
                "help": "CONTROL EFFECTIVENESS ANALYSIS\n\n" +
                        "Shows Gross vs Residual scores by entity:\n\n" +
                        "Orange bars: GROSS (inherent) risk score\n" +
                        "  Risk level before any controls applied\n\n" +
                        "Green bars: RESIDUAL risk score\n" +
                        "  Risk level after controls + mitigations\n\n" +
                        "INTERPRETATION:\n" +
                        "• Large gap = Controls are effective ✓\n" +
                        "• Small gap = Weak controls, review needed\n" +
                        "• Green > Orange = Risk worsened ⚠️\n\n" +
                        "AFA EXPECTATION:\n" +
                        "All Critical risks must show significant reduction"
            },
            "control_effectiveness": {
                "title": "Control Effectiveness", 
                "help": "CONTROL EFFECTIVENESS BY RISK CATEGORY\n\n" +
                        "Compares average Gross vs Residual scores per category:\n\n" +
                        "🔴 Red bars: Inherent (Gross) risk\n" +
                        "   Average score BEFORE controls\n\n" +
                        "🟢 Green bars: Residual risk\n" +
                        "   Average score AFTER controls\n\n" +
                        "REDUCTION % (shown in tooltip):\n" +
                        "   = (Gross - Residual) ÷ Gross × 100\n\n" +
                        "BENCHMARKS:\n" +
                        "• >50% reduction: Excellent controls\n" +
                        "• 30-50%: Good, meeting AFA standards\n" +
                        "• <30%: Weak, improvement needed\n\n" +
                        "PRIORITY ACTION:\n" +
                        "Focus on categories with smallest gaps"
            },
            "risk_matrix": {
                "title": "Risk Matrix", 
                "help": "AFA 4×4 RISK HEAT MAP\n\n" +
                        "Standard Probability × Impact matrix:\n\n" +
                        "Y-AXIS (Probability / Likelihood):\n" +
                        "4 - Very Likely: Expected to occur\n" +
                        "3 - Likely: Could occur several times\n" +
                        "2 - Unlikely: Could occur sometime\n" +
                        "1 - Rare: May occur in exceptional circumstances\n\n" +
                        "X-AXIS (Impact / Severity):\n" +
                        "4 - Critical: Business-threatening\n" +
                        "3 - Major: Significant financial/reputational\n" +
                        "2 - Moderate: Manageable impact\n" +
                        "1 - Minor: Limited consequences\n\n" +
                        "SCORE = P × I (1-16)\n\n" +
                        "COLOR ZONES:\n" +
                        "🔴 Red (12-16): Unacceptable\n" +
                        "🟠 Orange (8-9): Above appetite\n" +
                        "🟡 Yellow (4-6): Tolerable\n" +
                        "🟢 Green (1-3): Acceptable\n\n" +
                        "Numbers show how many risks fall in each cell"
            },
            "top_critical": {
                "title": "Top Critical Risks", 
                "help": "PRIORITY ACTION TABLE\n\n" +
                        "Shows only Critical and High severity risks that require immediate management attention.\n\n" +
                        "COLUMNS:\n" +
                        "• Level: 🔴 Critical or 🟠 High\n" +
                        "• ID: Risk identifier (e.g., A1, C2)\n" +
                        "• Entity: Business unit affected\n" +
                        "• Scenario: Brief risk description\n" +
                        "• Score: Gross → Residual transition\n" +
                        "• Action Plan: Remediation status\n" +
                        "   ✓ = Plan documented\n" +
                        "   ⚠️ Pending = No plan yet\n" +
                        "• Owner: Person accountable for control\n\n" +
                        "AFA REQUIREMENT:\n" +
                        "All Critical/High risks must have:\n" +
                        "1. Documented action plan\n" +
                        "2. Assigned control owner\n" +
                        "3. Target completion date\n\n" +
                        "Click any row to see full risk details"
            },
            "entity_summary": {
                "title": "Entity Summary", 
                "help": "ENTITY RISK PROFILE TABLE\n\n" +
                        "Summary statistics per business unit:\n\n" +
                        "• Entity: Click name to open dashboard →\n" +
                        "• Risks: Total count of mapped risks\n" +
                        "• Critical: Count of score 12-16 risks\n" +
                        "• High: Count of score 8-9 risks\n" +
                        "• Avg Score: Mean residual score (1-16)\n\n" +
                        "INTERPRETATION:\n" +
                        "• Avg Score <5: Low exposure ✓\n" +
                        "• Avg Score 5-8: Moderate attention\n" +
                        "• Avg Score >8: High priority\n\n" +
                        "BENCHMARKING:\n" +
                        "Compare entities to identify outliers\n" +
                        "Entities with higher Critical/High counts\n" +
                        "may need enhanced controls or audit"
            },
            "risk_table": {
                "title": "Risk Register", 
                "help": "COMPLETE RISK REGISTRY\n\n" +
                        "Full list of all mapped corruption risks.\n\n" +
                        "FEATURES:\n" +
                        "• Search: Type to filter by any field\n" +
                        "• Sort: Click column headers\n" +
                        "• Filter: Use dropdowns above\n\n" +
                        "COLUMNS:\n" +
                        "• Entity: Business unit\n" +
                        "• ID: Unique risk identifier\n" +
                        "• Scenario: Risk description\n" +
                        "• Gross: Inherent score (P×I)\n" +
                        "• Residual: Score after controls\n" +
                        "• Level: Severity category\n\n" +
                        "Click any row to view full details including:\n" +
                        "• Aggravating factors\n" +
                        "• Prevention measures\n" +
                        "• Corrective actions\n" +
                        "• Control owner"
            },
            "detailed_analysis": {
                "title": "Process Category Summary", 
                "help": "CATEGORY BREAKDOWN TABLE\n\n" +
                        "Statistics per AFA corruption category:\n\n" +
                        "• Process: Category name (A-P)\n" +
                        "• Count: Number of risk scenarios\n" +
                        "• Critical: High-severity risks\n" +
                        "• High: Above-appetite risks\n" +
                        "• Avg Score: Mean residual score\n\n" +
                        "PRIORITY CATEGORIES:\n" +
                        "Focus on categories with highest:\n" +
                        "1. Critical + High counts\n" +
                        "2. Average residual scores\n\n" +
                        "AFA INSPECTION TIP:\n" +
                        "Ensure all 7 categories are covered\n" +
                        "(A, C, R, F, M, S, P)"
            }
        }
    }


class EnhancedDashboardGenerator:
    """
    Generates highly interactive HTML dashboard with advanced features.
    Labels are externalized in configuration/dashboard_labels.json
    Help tooltips are externalized in configuration/dashboard_help.json
    """
    
    def __init__(self, title: str = None, config: Dict = None, labels_path: str = None, help_path: str = None):
        self.labels = load_dashboard_labels(labels_path)
        self.help_content = load_dashboard_help(help_path)
        self.title = title or self.labels.get('page', {}).get('title', 'Risk Cartography Dashboard')
        self.colors = DEFAULT_COLORS
        self.config = config or {}
    
    def _get_help(self, section_key: str) -> Dict:
        """Get help content for a section."""
        return self.help_content.get('sections', {}).get(section_key, {})
    
    def _generate_help_icon(self, section_key: str) -> str:
        """Generate a help icon with tooltip for a section."""
        help_data = self._get_help(section_key)
        if not help_data:
            return ''
        
        help_text = help_data.get('help', '').replace('\n', '&#10;').replace("'", "&#39;")
        return f'''<span class="help-icon" data-tooltip="{help_text}" tabindex="0">❓</span>'''
    
    def _get_label(self, *keys, default: str = '') -> str:
        """Get a label from nested keys in the labels config."""
        value = self.labels
        for key in keys:
            if isinstance(value, dict):
                value = value.get(key, {})
            else:
                return default
        return value if isinstance(value, str) else default
    
    def generate(self, df: pd.DataFrame, analysis: RiskAnalysis) -> str:
        """Generate complete enhanced HTML dashboard."""
        risks_json = self._prepare_risks_data(df)
        
        return f'''<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{self.title}</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    {self._generate_enhanced_styles()}
</head>
<body>
    {self._generate_navigation()}
    <main id="main-content">
        {self._generate_header(analysis)}
        {self._generate_filter_bar(df, analysis)}
        {self._generate_alert_panel(analysis)}
        {self._generate_executive_summary(analysis)}
        {self._generate_afa_compliance_section(analysis)}
        {self._generate_kpi_cards(analysis)}
        <div id="charts-section">
            {self._generate_charts_section(analysis)}
            {self._generate_risk_matrix_section(df)}
        </div>
        {self._generate_detailed_analysis_section(analysis, df)}
        {self._generate_risk_table_section(df)}
        {self._generate_footer(analysis)}
    </main>
    {self._generate_risk_modal()}
    {self._generate_scripts(analysis, risks_json)}
</body>
</html>'''
    
    def generate_entity_dashboard(self, df: pd.DataFrame, analysis: RiskAnalysis, 
                                   entity_name: str, global_dashboard_path: str = "risk_dashboard.html") -> str:
        """Generate entity-specific dashboard with back navigation to global dashboard."""
        risks_json = self._prepare_risks_data(df)
        entity_title = f"{entity_name} - Risk Dashboard"
        
        return f'''<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{entity_title}</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    {self._generate_enhanced_styles()}
</head>
<body>
    {self._generate_entity_navigation(entity_name, global_dashboard_path)}
    <main id="main-content">
        {self._generate_entity_header(analysis, entity_name)}
        {self._generate_alert_panel(analysis)}
        {self._generate_executive_summary(analysis)}
        {self._generate_afa_compliance_section(analysis)}
        {self._generate_kpi_cards(analysis)}
        <div id="charts-section">
            {self._generate_entity_charts_section(analysis)}
            {self._generate_risk_matrix_section(df)}
        </div>
        {self._generate_entity_category_analysis(analysis, df)}
        {self._generate_risk_table_section(df)}
        {self._generate_footer(analysis)}
    </main>
    {self._generate_risk_modal()}
    {self._generate_entity_scripts(analysis, risks_json)}
</body>
</html>'''
    
    def _generate_entity_navigation(self, entity_name: str, global_dashboard_path: str) -> str:
        """Generate navigation bar for entity dashboard with back link."""
        return f'''
    <nav class="navbar">
        <div class="navbar-inner">
            <a href="{global_dashboard_path}" class="nav-back-link">
                <span class="nav-back-icon">←</span>
                <span>Back to Global Dashboard</span>
            </a>
            <div class="nav-brand">
                <div class="nav-brand-icon">🏢</div>
                <span>{entity_name}</span>
            </div>
            <div class="nav-actions">
                <button class="nav-btn" onclick="window.print()" title="Print Report">🖨️</button>
                <button class="nav-btn theme-toggle" onclick="toggleTheme()" title="Toggle Theme"><span id="theme-icon">🌓</span></button>
            </div>
        </div>
    </nav>'''
    
    def _generate_entity_header(self, analysis: RiskAnalysis, entity_name: str) -> str:
        """Generate header section for entity dashboard."""
        subtitle = self.labels.get('page', {}).get('subtitle', 'Corruption Risk Analysis')
        
        return f'''
    <header class="dashboard-header animate-in">
        <div class="header-content">
            <h1 class="dashboard-title">🏢 {entity_name}</h1>
            <p class="dashboard-subtitle">{subtitle} - Entity Dashboard</p>
        </div>
        <div class="header-stats">
            <div class="header-stat">
                <span class="stat-value">{analysis.summary.total_risks}</span>
                <span class="stat-label">Total Risks</span>
            </div>
            <div class="header-stat">
                <span class="stat-value {'danger' if analysis.summary.avg_residual_score > 8 else 'warning' if analysis.summary.avg_residual_score > 5 else ''}">{analysis.summary.avg_residual_score:.1f}</span>
                <span class="stat-label">Avg Score</span>
            </div>
            <div class="header-stat">
                <span class="stat-value">{analysis.summary.risk_reduction_pct:+.1f}%</span>
                <span class="stat-label">Reduction</span>
            </div>
        </div>
    </header>'''
    
    def _generate_entity_category_analysis(self, analysis: RiskAnalysis, df: pd.DataFrame) -> str:
        """Generate category analysis section for entity (replacement for detailed analysis)."""
        by_category = analysis.by_category
        
        # Calculate critical/high counts from df for each category
        category_rows = []
        for cat_key, stats in sorted(by_category.items()):
            # Count critical and high risks for this category from df
            cat_df = df[df['risk_id'].str.startswith(cat_key, na=False)]
            critical_count = len(cat_df[cat_df['level_residual'].str.contains('Critical', na=False, case=False)])
            high_count = len(cat_df[cat_df['level_residual'].str.contains('High', na=False, case=False)])
            
            critical_badge = (
                f'<span class="risk-badge badge-critical">{critical_count}</span>'
                if critical_count > 0 
                else '<span style="color: var(--text-muted);">0</span>'
            )
            high_badge = (
                f'<span class="risk-badge badge-high">{high_count}</span>'
                if high_count > 0 
                else '<span style="color: var(--text-muted);">0</span>'
            )
            
            # Get category name - use the stats category_name if available
            cat_name = stats.category_name if hasattr(stats, 'category_name') else cat_key
            
            category_rows.append(f'''
                <tr>
                    <td class="category">{cat_name}</td>
                    <td>{stats.count}</td>
                    <td>{critical_badge}</td>
                    <td>{high_badge}</td>
                    <td>{stats.avg_residual_score:.1f}</td>
                </tr>''')
        
        # Generate top risks list for entity
        top_risks_html = self._generate_top_risks_list(analysis.top_risks)
        
        return f'''
    <div class="charts-grid animate-in" style="animation-delay: 0.4s;">
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">⚠️ Top Highest Residual Risks</h3>
            </div>
            <ul class="top-risks-list">
                {top_risks_html}
            </ul>
        </div>
        
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">📊 Process Category Summary {self._generate_help_icon('detailed_analysis')}</h3>
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Process</th>
                        <th>Count</th>
                        <th>Critical</th>
                        <th>High</th>
                        <th>Avg Score</th>
                    </tr>
                </thead>
                <tbody>
                    {''.join(category_rows)}
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="charts-grid animate-in" style="animation-delay: 0.45s;">
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">🎯 Mitigation Effectiveness</h3>
            </div>
            <div class="chart-container">
                <canvas id="mitigationChart"></canvas>
            </div>
        </div>
        
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">🕸️ Category Risk Radar</h3>
            </div>
            <div class="chart-container">
                <canvas id="categoryRadarChart"></canvas>
            </div>
        </div>
    </div>'''
    
    @staticmethod
    def get_entity_filename(entity_name: str) -> str:
        """Generate a clean filename for entity dashboard."""
        # Clean entity name for use as filename
        clean_name = entity_name.replace(' ', '_').replace('/', '_').replace('\\', '_')
        clean_name = ''.join(c for c in clean_name if c.isalnum() or c in ('_', '-'))
        return f"entity_{clean_name.lower()}.html"
    
    def save(self, html: str, filepath: str) -> str:
        """Save HTML to file."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(html)
        logger.info(f"Enhanced dashboard saved: {filepath}")
        return str(path)
    
    def _prepare_risks_data(self, df: pd.DataFrame) -> str:
        """Prepare risks data as JSON for JavaScript."""
        risks = []
        for _, row in df.iterrows():
            risk = {
                'entity': str(row.get('entity', '')),
                'risk_id': str(row.get('risk_id', '')),
                'scenario': str(row.get('scenario', '')),
                'description': str(row.get('description', ''))[:500],
                'aggravating_factors': str(row.get('aggravating_factors', '')),
                'prevention_measures': str(row.get('prevention_measures', '')),
                'corrective_actions': str(row.get('corrective_actions', '')),
                'prob_gross': int(row.get('prob_gross', 0)) if pd.notna(row.get('prob_gross')) else 0,
                'impact_gross': int(row.get('impact_gross', 0)) if pd.notna(row.get('impact_gross')) else 0,
                'score_gross': int(row.get('score_gross', 0)) if pd.notna(row.get('score_gross')) else 0,
                'level_gross': str(row.get('level_gross', '')),
                'prob_residual': int(row.get('prob_residual', 0)) if pd.notna(row.get('prob_residual')) else 0,
                'impact_residual': int(row.get('impact_residual', 0)) if pd.notna(row.get('impact_residual')) else 0,
                'score_residual': int(row.get('score_residual', 0)) if pd.notna(row.get('score_residual')) else 0,
                'level_residual': str(row.get('level_residual', '')),
                'category': str(row.get('risk_id', ''))[:1] if row.get('risk_id') else ''
            }
            risks.append(risk)
        return json.dumps(risks, ensure_ascii=False)
    
    def _generate_enhanced_styles(self) -> str:
        """Generate enhanced CSS with theme support."""
        return '''<style>
        /* === CSS Variables === */
        :root {
            --font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            --transition-fast: 0.15s ease;
            --transition-normal: 0.3s ease;
            --transition-slow: 0.5s ease;
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.1);
            --shadow-md: 0 4px 20px rgba(0,0,0,0.15);
            --shadow-lg: 0 8px 40px rgba(0,0,0,0.2);
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
        }
        
        /* Dark theme (default) */
        [data-theme="dark"] {
            --bg-primary: #0f1119;
            --bg-secondary: #1a1d29;
            --bg-card: #252836;
            --bg-hover: #2d3142;
            --text-primary: #ffffff;
            --text-secondary: #9ca3af;
            --text-muted: #6b7280;
            --accent: #00d4ff;
            --accent-glow: rgba(0, 212, 255, 0.3);
            --success: #10b981;
            --success-bg: rgba(16, 185, 129, 0.15);
            --warning: #f59e0b;
            --warning-bg: rgba(245, 158, 11, 0.15);
            --orange: #f97316;
            --orange-bg: rgba(249, 115, 22, 0.15);
            --danger: #ef4444;
            --danger-bg: rgba(239, 68, 68, 0.15);
            --border: rgba(255,255,255,0.08);
            --border-strong: rgba(255,255,255,0.15);
            --chart-grid: rgba(255,255,255,0.05);
        }
        
        /* Light theme */
        [data-theme="light"] {
            --bg-primary: #f8fafc;
            --bg-secondary: #ffffff;
            --bg-card: #ffffff;
            --bg-hover: #f1f5f9;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --text-muted: #94a3b8;
            --accent: #0284c7;
            --accent-glow: rgba(2, 132, 199, 0.2);
            --success: #059669;
            --success-bg: rgba(5, 150, 105, 0.1);
            --warning: #d97706;
            --warning-bg: rgba(217, 119, 6, 0.1);
            --orange: #ea580c;
            --orange-bg: rgba(234, 88, 12, 0.1);
            --danger: #dc2626;
            --danger-bg: rgba(220, 38, 38, 0.1);
            --border: rgba(0,0,0,0.08);
            --border-strong: rgba(0,0,0,0.15);
            --chart-grid: rgba(0,0,0,0.05);
        }
        
        /* === Reset & Base === */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        html { scroll-behavior: smooth; }
        
        body {
            font-family: var(--font-family);
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            line-height: 1.6;
        }
        
        /* === Help Tooltips === */
        .help-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 22px;
            height: 22px;
            font-size: 12px;
            background: var(--bg-hover);
            border: 1px solid var(--border-strong);
            border-radius: 50%;
            cursor: help;
            margin-left: 8px;
            opacity: 0.7;
            transition: var(--transition-fast);
            position: relative;
            vertical-align: middle;
        }
        
        .help-icon:hover, .help-icon:focus {
            opacity: 1;
            background: var(--accent);
            color: #fff;
            border-color: var(--accent);
            transform: scale(1.1);
        }
        
        .help-icon::after {
            content: attr(data-tooltip);
            position: absolute;
            bottom: calc(100% + 12px);
            left: 50%;
            transform: translateX(-50%);
            background: var(--bg-card);
            color: var(--text-primary);
            padding: 16px 20px;
            border-radius: var(--radius-md);
            font-size: 0.85rem;
            font-weight: 400;
            line-height: 1.6;
            white-space: pre-wrap;
            min-width: 280px;
            max-width: 420px;
            box-shadow: var(--shadow-lg);
            border: 1px solid var(--border-strong);
            opacity: 0;
            visibility: hidden;
            transition: var(--transition-normal);
            z-index: 99999;
            pointer-events: none;
        }
        
        .help-icon::before {
            content: '';
            position: absolute;
            bottom: calc(100% + 4px);
            left: 50%;
            transform: translateX(-50%);
            border: 8px solid transparent;
            border-top-color: var(--bg-card);
            opacity: 0;
            visibility: hidden;
            transition: var(--transition-normal);
            z-index: 99999;
        }
        
        .help-icon:hover::after, .help-icon:focus::after,
        .help-icon:hover::before, .help-icon:focus::before {
            opacity: 1;
            visibility: visible;
        }
        
        /* Elevate help-icon when active to escape stacking context */
        .help-icon:hover, .help-icon:focus {
            z-index: 9999;
        }
        
        /* Tooltip positioning adjustments for edge cases */
        .help-icon.tooltip-left::after {
            left: auto;
            right: 0;
            transform: none;
        }
        
        .help-icon.tooltip-right::after {
            left: 0;
            transform: none;
        }
        
        /* Tooltip appears below for elements near top of viewport */
        .help-icon.tooltip-bottom::after {
            bottom: auto;
            top: calc(100% + 12px);
        }
        
        .help-icon.tooltip-bottom::before {
            bottom: auto;
            top: calc(100% + 4px);
            border-top-color: transparent;
            border-bottom-color: var(--bg-card);
        }
        
        /* Section title with help */
        .section-title-with-help {
            display: flex;
            align-items: center;
            gap: 4px;
            position: relative;
            z-index: 1;
        }
        
        .chart-title-with-help {
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        /* Section wrappers */
        .section-wrapper {
            margin-bottom: 24px;
        }
        
        .section-header-simple {
            margin-bottom: 16px;
        }
        
        .section-header-simple h2 {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        /* === Navigation === */
        .navbar {
            position: sticky;
            top: 0;
            z-index: 100;
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
        }
        
        .navbar-inner {
            max-width: 1600px;
            margin: 0 auto;
            padding: 0 24px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .nav-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 600;
            font-size: 1.1rem;
            color: var(--text-primary);
        }
        
        .nav-brand-icon {
            width: 36px;
            height: 36px;
            background: linear-gradient(135deg, var(--accent), #00ff88);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }
        
        .nav-back-link {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            border-radius: var(--radius-sm);
            background: var(--bg-hover);
            color: var(--accent);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            transition: var(--transition-fast);
            border: 1px solid var(--border);
        }
        
        .nav-back-link:hover {
            background: var(--accent);
            color: #fff;
            transform: translateX(-4px);
        }
        
        .nav-back-icon {
            font-size: 1.2rem;
            transition: var(--transition-fast);
        }
        
        .nav-back-link:hover .nav-back-icon {
            transform: translateX(-2px);
        }
        
        .entity-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--accent);
            text-decoration: none;
            padding: 4px 8px;
            border-radius: var(--radius-sm);
            transition: var(--transition-fast);
        }
        
        .entity-link:hover {
            background: var(--accent);
            color: #fff;
        }
        
        .entity-link-icon {
            font-size: 0.85rem;
            opacity: 0.7;
        }
        
        .entity-link:hover .entity-link-icon {
            opacity: 1;
        }
        
        .nav-links {
            display: flex;
            gap: 8px;
        }
        
        .nav-link {
            padding: 8px 16px;
            border-radius: var(--radius-sm);
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            transition: var(--transition-fast);
        }
        
        .nav-link:hover, .nav-link.active {
            background: var(--bg-hover);
            color: var(--text-primary);
        }
        
        .nav-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            border-radius: var(--radius-sm);
            font-size: 0.9rem;
            font-weight: 500;
            border: none;
            cursor: pointer;
            transition: var(--transition-fast);
        }
        
        .btn-ghost {
            background: transparent;
            color: var(--text-secondary);
        }
        
        .btn-ghost:hover {
            background: var(--bg-hover);
            color: var(--text-primary);
        }
        
        .btn-primary {
            background: var(--accent);
            color: #000;
        }
        
        .btn-primary:hover {
            opacity: 0.9;
            transform: translateY(-1px);
        }
        
        .theme-toggle {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            background: var(--bg-hover);
            border: 1px solid var(--border);
        }
        
        /* === Main Content === */
        #main-content {
            max-width: 1600px;
            margin: 0 auto;
            padding: 24px;
        }
        
        /* === Header === */
        .dashboard-header {
            text-align: center;
            margin-bottom: 24px;
            padding: 32px;
            background: linear-gradient(135deg, var(--bg-secondary) 0%, var(--bg-card) 100%);
            border-radius: var(--radius-lg);
            border: 1px solid var(--border);
            position: relative;
            overflow: hidden;
        }
        
        .dashboard-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--success), var(--warning), var(--orange), var(--danger));
        }
        
        .dashboard-header h1 {
            font-size: 2.2rem;
            font-weight: 700;
            margin-bottom: 8px;
            background: linear-gradient(135deg, var(--accent), #00ff88);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .dashboard-header .subtitle {
            color: var(--text-secondary);
            font-size: 1rem;
        }
        
        .header-stats {
            display: flex;
            justify-content: center;
            gap: 32px;
            margin-top: 20px;
        }
        
        .header-stat {
            text-align: center;
        }
        
        .header-stat-value {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--accent);
        }
        
        .header-stat-label {
            font-size: 0.8rem;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* === Filter Bar === */
        .filter-bar {
            background: var(--bg-card);
            border-radius: var(--radius-md);
            padding: 16px 20px;
            margin-bottom: 24px;
            border: 1px solid var(--border);
            display: flex;
            flex-wrap: wrap;
            gap: 16px;
            align-items: center;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        
        .filter-label {
            font-size: 0.75rem;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .filter-select, .filter-input {
            background: var(--bg-secondary);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            padding: 8px 12px;
            color: var(--text-primary);
            font-size: 0.9rem;
            min-width: 150px;
            transition: var(--transition-fast);
        }
        
        .filter-select:focus, .filter-input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px var(--accent-glow);
        }
        
        .filter-input {
            min-width: 250px;
        }
        
        .filter-chips {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            flex: 1;
        }
        
        .filter-chip {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            background: var(--accent-glow);
            border: 1px solid var(--accent);
            border-radius: 20px;
            font-size: 0.8rem;
            color: var(--accent);
        }
        
        .filter-chip-remove {
            cursor: pointer;
            opacity: 0.7;
        }
        
        .filter-chip-remove:hover {
            opacity: 1;
        }
        
        .filter-stats {
            margin-left: auto;
            display: flex;
            align-items: center;
            gap: 12px;
            color: var(--text-secondary);
            font-size: 0.9rem;
        }
        
        .filter-count {
            font-weight: 600;
            color: var(--accent);
        }
        
        /* === Alert Panel === */
        .alert-panel {
            background: linear-gradient(135deg, var(--danger-bg), transparent);
            border: 1px solid var(--danger);
            border-radius: var(--radius-md);
            padding: 16px 20px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 16px;
            animation: pulse-border 2s infinite;
        }
        
        @keyframes pulse-border {
            0%, 100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4); }
            50% { box-shadow: 0 0 0 4px rgba(239, 68, 68, 0.1); }
        }
        
        .alert-icon {
            width: 48px;
            height: 48px;
            background: var(--danger);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            flex-shrink: 0;
        }
        
        .alert-content { flex: 1; }
        
        .alert-title {
            font-weight: 600;
            font-size: 1rem;
            margin-bottom: 4px;
        }
        
        .alert-description {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }
        
        .alert-action {
            background: var(--danger);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: var(--radius-sm);
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition-fast);
        }
        
        .alert-action:hover {
            opacity: 0.9;
        }
        
        .alert-panel.hidden { display: none; }
        
        /* === Executive Summary === */
        .executive-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 24px;
        }
        
        .insight-card {
            background: var(--bg-card);
            border-radius: var(--radius-md);
            padding: 20px;
            border: 1px solid var(--border);
            position: relative;
            overflow: hidden;
        }
        
        .insight-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
        }
        
        .insight-card.success::before { background: var(--success); }
        .insight-card.warning::before { background: var(--warning); }
        .insight-card.danger::before { background: var(--danger); }
        .insight-card.accent::before { background: var(--accent); }
        
        .insight-icon {
            width: 40px;
            height: 40px;
            border-radius: var(--radius-sm);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-bottom: 12px;
        }
        
        .insight-card.success .insight-icon { background: var(--success-bg); }
        .insight-card.warning .insight-icon { background: var(--warning-bg); }
        .insight-card.danger .insight-icon { background: var(--danger-bg); }
        .insight-card.accent .insight-icon { background: var(--accent-glow); }
        
        .insight-title {
            font-size: 0.85rem;
            color: var(--text-muted);
            margin-bottom: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .insight-value {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 8px;
        }
        
        .insight-card.success .insight-value { color: var(--success); }
        .insight-card.warning .insight-value { color: var(--warning); }
        .insight-card.danger .insight-value { color: var(--danger); }
        .insight-card.accent .insight-value { color: var(--accent); }
        
        .insight-detail {
            font-size: 0.9rem;
            color: var(--text-secondary);
        }
        
        .insight-trend {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .trend-up { background: var(--success-bg); color: var(--success); }
        .trend-down { background: var(--danger-bg); color: var(--danger); }
        .trend-stable { background: var(--warning-bg); color: var(--warning); }
        
        /* === KPI Cards === */
        .kpi-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }
        
        .kpi-card {
            background: var(--bg-card);
            border-radius: var(--radius-md);
            padding: 20px;
            border: 1px solid var(--border);
            text-align: center;
            transition: var(--transition-normal);
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }
        
        .kpi-card::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 3px;
            transform: scaleX(0);
            transition: var(--transition-normal);
        }
        
        .kpi-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-md);
            border-color: var(--border-strong);
        }
        
        .kpi-card:hover::after {
            transform: scaleX(1);
        }
        
        .kpi-card.success::after { background: var(--success); }
        .kpi-card.warning::after { background: var(--warning); }
        .kpi-card.danger::after { background: var(--danger); }
        .kpi-card.accent::after { background: var(--accent); }
        
        .kpi-value {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 4px;
            transition: var(--transition-fast);
        }
        
        .kpi-card.success .kpi-value { color: var(--success); }
        .kpi-card.warning .kpi-value { color: var(--warning); }
        .kpi-card.danger .kpi-value { color: var(--danger); }
        .kpi-card.accent .kpi-value { color: var(--accent); }
        
        .kpi-label {
            color: var(--text-muted);
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 500;
        }
        
        .kpi-change {
            font-size: 0.8rem;
            margin-top: 4px;
        }
        
        /* === Charts === */
        .section-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .section-title::before {
            content: '';
            width: 4px;
            height: 24px;
            background: var(--accent);
            border-radius: 2px;
        }
        
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(420px, 1fr));
            gap: 20px;
            margin-bottom: 24px;
        }
        
        .chart-card {
            background: var(--bg-card);
            border-radius: var(--radius-md);
            padding: 20px;
            border: 1px solid var(--border);
            transition: var(--transition-normal);
            overflow: visible;
            position: relative;
        }
        
        .chart-card:hover {
            border-color: var(--border-strong);
            z-index: 10;
        }
        
        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
        }
        
        .chart-title {
            font-size: 1rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .chart-actions {
            display: flex;
            gap: 8px;
        }
        
        .chart-btn {
            width: 32px;
            height: 32px;
            border-radius: var(--radius-sm);
            background: var(--bg-secondary);
            border: 1px solid var(--border);
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition-fast);
        }
        
        .chart-btn:hover {
            background: var(--bg-hover);
            color: var(--text-primary);
        }
        
        .chart-container {
            position: relative;
            height: 300px;
        }
        
        .chart-legend {
            display: flex;
            justify-content: center;
            gap: 16px;
            margin-top: 12px;
            flex-wrap: wrap;
        }
        
        .legend-item {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 0.85rem;
            color: var(--text-secondary);
        }
        
        .legend-color {
            width: 12px;
            height: 12px;
            border-radius: 3px;
        }
        
        /* === Risk Matrix - Sapin II / Audit Standard Format === */
        .matrix-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }
        
        .risk-matrix-table {
            border-collapse: separate;
            border-spacing: 3px;
            width: 100%;
            max-width: 450px;
        }
        
        .risk-matrix-table th,
        .risk-matrix-table td {
            text-align: center;
            padding: 0;
        }
        
        .matrix-corner {
            width: 90px;
            height: 35px;
        }
        
        .matrix-y-axis-cell {
            vertical-align: middle;
            text-align: center;
            width: 90px;
        }
        
        .matrix-y-axis {
            writing-mode: vertical-rl;
            transform: rotate(180deg);
            font-weight: 700;
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--text-secondary);
            display: inline-block;
            padding: 4px;
        }
        
        .matrix-prob-label {
            font-weight: 600;
            font-size: 0.7rem;
            color: var(--text-secondary);
            text-align: right;
            padding-right: 8px;
            width: 80px;
            white-space: nowrap;
        }
        
        .matrix-prob-num {
            font-weight: 700;
            color: var(--accent);
            font-size: 0.85rem;
            margin-right: 4px;
        }
        
        .matrix-impact-label {
            font-weight: 600;
            font-size: 0.65rem;
            color: var(--text-secondary);
            padding-top: 6px;
            text-transform: uppercase;
        }
        
        .matrix-impact-num {
            font-weight: 700;
            color: var(--accent);
            font-size: 0.75rem;
            display: block;
        }
        
        .matrix-x-axis {
            font-weight: 700;
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--text-secondary);
            padding-top: 12px;
        }
        
        .matrix-cell {
            width: 70px;
            height: 55px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 6px;
            font-weight: 700;
            font-size: 1.2rem;
            cursor: pointer;
            transition: all 0.2s ease;
            position: relative;
            box-shadow: inset 0 -2px 0 rgba(0,0,0,0.1);
        }
        
        .matrix-cell:hover {
            transform: scale(1.08);
            z-index: 10;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        }
        
        .matrix-cell .tooltip {
            position: absolute;
            bottom: calc(100% + 8px);
            left: 50%;
            transform: translateX(-50%);
            background: var(--bg-secondary);
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 500;
            white-space: nowrap;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.2s ease;
            border: 1px solid var(--border);
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            z-index: 100;
        }
        
        .matrix-cell:hover .tooltip {
            opacity: 1;
        }
        
        .matrix-cell-score {
            display: none;
        }
        
        /* Risk Level Colors - Sapin II Standard */
        .level-low {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
        }
        
        .level-moderate {
            background: linear-gradient(135deg, #ffc107 0%, #ffca2c 100%);
            color: #1a1a2e;
        }
        
        .level-high {
            background: linear-gradient(135deg, #fd7e14 0%, #f76707 100%);
            color: white;
        }
        
        .level-critical {
            background: linear-gradient(135deg, #dc3545 0%, #c92a2a 100%);
            color: white;
        }
        
        /* Matrix Legend */
        .matrix-legend {
            display: flex;
            justify-content: center;
            gap: 16px;
            margin-top: 16px;
            flex-wrap: wrap;
        }
        
        .legend-item {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 0.75rem;
            color: var(--text-secondary);
        }
        
        .legend-color {
            width: 16px;
            height: 16px;
            border-radius: 4px;
        }
        
        .legend-low { background: #28a745; }
        .legend-moderate { background: #ffc107; }
        .legend-high { background: #fd7e14; }
        .legend-critical { background: #dc3545; }
        
        .matrix-title-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 8px;
        }
        
        .matrix-subtitle {
            font-size: 0.8rem;
            color: var(--text-muted);
            font-weight: 500;
        }
        
        .level-low { background: rgba(16, 185, 129, 0.25); color: var(--success); }
        .level-moderate { background: rgba(245, 158, 11, 0.25); color: var(--warning); }
        .level-high { background: rgba(249, 115, 22, 0.25); color: var(--orange); }
        .level-critical { background: rgba(239, 68, 68, 0.25); color: var(--danger); }
        
        .matrix-axis-label {
            text-align: center;
            color: var(--text-muted);
            font-size: 0.85rem;
            margin-top: 8px;
        }
        
        /* === Tables === */
        .table-card {
            background: var(--bg-card);
            border-radius: var(--radius-md);
            border: 1px solid var(--border);
            overflow: hidden;
            margin-bottom: 24px;
        }
        
        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 20px;
            border-bottom: 1px solid var(--border);
        }
        
        .table-title {
            font-size: 1rem;
            font-weight: 600;
        }
        
        .table-search {
            background: var(--bg-secondary);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            padding: 8px 12px;
            color: var(--text-primary);
            font-size: 0.9rem;
            min-width: 200px;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .data-table th, .data-table td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }
        
        .data-table th {
            background: var(--bg-secondary);
            color: var(--text-muted);
            font-weight: 600;
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            cursor: pointer;
            user-select: none;
            transition: var(--transition-fast);
        }
        
        .data-table th:hover {
            background: var(--bg-hover);
            color: var(--text-primary);
        }
        
        .data-table th .sort-icon {
            margin-left: 6px;
            opacity: 0.5;
        }
        
        .data-table th.sorted .sort-icon {
            opacity: 1;
            color: var(--accent);
        }
        
        .data-table tbody tr {
            transition: var(--transition-fast);
            cursor: pointer;
        }
        
        .data-table tbody tr:hover {
            background: var(--bg-hover);
        }
        
        .data-table td.entity {
            font-weight: 600;
            color: var(--accent);
        }
        
        .risk-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 4px 10px;
            border-radius: 16px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .badge-low { background: var(--success-bg); color: var(--success); }
        .badge-moderate { background: var(--warning-bg); color: var(--warning); }
        .badge-high { background: var(--orange-bg); color: var(--orange); }
        .badge-critical { background: var(--danger-bg); color: var(--danger); }
        
        .score-pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 26px;
            border-radius: 13px;
            font-weight: 600;
            font-size: 0.85rem;
        }
        
        .score-change {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .score-gross {
            color: var(--text-muted);
            text-decoration: line-through;
            font-size: 0.9rem;
        }
        
        .score-arrow {
            color: var(--success);
        }
        
        /* === Top Risks === */
        .top-risks-list {
            list-style: none;
        }
        
        .risk-item {
            padding: 14px 16px;
            margin-bottom: 8px;
            background: var(--bg-secondary);
            border-radius: var(--radius-sm);
            border-left: 4px solid;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            transition: var(--transition-fast);
        }
        
        .risk-item:hover {
            background: var(--bg-hover);
            transform: translateX(4px);
        }
        
        .risk-item.critical { border-left-color: var(--danger); }
        .risk-item.high { border-left-color: var(--orange); }
        .risk-item.moderate { border-left-color: var(--warning); }
        .risk-item.low { border-left-color: var(--success); }
        
        .risk-info { flex: 1; }
        
        .risk-entity {
            font-weight: 600;
            color: var(--accent);
            font-size: 0.9rem;
        }
        
        .risk-scenario {
            color: var(--text-secondary);
            font-size: 0.85rem;
            margin-top: 4px;
        }
        
        .risk-score-display {
            text-align: right;
        }
        
        .risk-score-value {
            font-size: 1.4rem;
            font-weight: 700;
        }
        
        .risk-item.critical .risk-score-value { color: var(--danger); }
        .risk-item.high .risk-score-value { color: var(--orange); }
        .risk-item.moderate .risk-score-value { color: var(--warning); }
        .risk-item.low .risk-score-value { color: var(--success); }
        
        /* === Modal === */
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(4px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition-normal);
        }
        
        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
        .modal {
            background: var(--bg-card);
            border-radius: var(--radius-lg);
            max-width: 700px;
            width: 90%;
            max-height: 85vh;
            overflow-y: auto;
            border: 1px solid var(--border);
            transform: scale(0.95) translateY(20px);
            transition: var(--transition-normal);
        }
        
        .modal-overlay.active .modal {
            transform: scale(1) translateY(0);
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid var(--border);
            position: sticky;
            top: 0;
            background: var(--bg-card);
            z-index: 10;
        }
        
        .modal-title {
            font-size: 1.2rem;
            font-weight: 600;
        }
        
        .modal-close {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: var(--bg-secondary);
            border: 1px solid var(--border);
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition-fast);
        }
        
        .modal-close:hover {
            background: var(--danger-bg);
            color: var(--danger);
            border-color: var(--danger);
        }
        
        .modal-body {
            padding: 20px;
        }
        
        .modal-section {
            margin-bottom: 20px;
        }
        
        .modal-section-title {
            font-size: 0.8rem;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }
        
        .modal-section-content {
            background: var(--bg-secondary);
            padding: 12px 16px;
            border-radius: var(--radius-sm);
            font-size: 0.95rem;
            line-height: 1.6;
        }
        
        .modal-scores {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
            margin-bottom: 20px;
        }
        
        .score-block {
            background: var(--bg-secondary);
            padding: 16px;
            border-radius: var(--radius-sm);
            text-align: center;
        }
        
        .score-block-label {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-bottom: 8px;
        }
        
        .score-block-value {
            font-size: 2rem;
            font-weight: 700;
        }
        
        .score-block-details {
            font-size: 0.85rem;
            color: var(--text-secondary);
            margin-top: 4px;
        }
        
        .score-block.gross .score-block-value { color: var(--orange); }
        .score-block.residual .score-block-value { color: var(--success); }
        
        /* === Footer === */
        .footer {
            text-align: center;
            padding: 24px;
            color: var(--text-muted);
            font-size: 0.85rem;
            margin-top: 24px;
            border-top: 1px solid var(--border);
        }
        
        .footer-links {
            display: flex;
            justify-content: center;
            gap: 16px;
            margin-bottom: 12px;
        }
        
        .footer-link {
            color: var(--text-secondary);
            text-decoration: none;
            transition: var(--transition-fast);
        }
        
        .footer-link:hover {
            color: var(--accent);
        }
        
        /* === Animations === */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-in {
            animation: fadeIn 0.4s ease forwards;
        }
        
        @keyframes countUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .count-up {
            animation: countUp 0.6s ease forwards;
        }
        
        /* === Responsive === */
        @media (max-width: 1024px) {
            .charts-grid { grid-template-columns: 1fr; }
            .executive-summary { grid-template-columns: repeat(2, 1fr); }
            .nav-links { display: none; }
        }
        
        @media (max-width: 768px) {
            #main-content { padding: 16px; }
            .dashboard-header h1 { font-size: 1.6rem; }
            .kpi-container { grid-template-columns: repeat(2, 1fr); }
            .filter-bar { flex-direction: column; align-items: stretch; }
            .filter-group { flex: 1; }
            .filter-stats { margin-left: 0; justify-content: center; padding-top: 8px; }
            .executive-summary { grid-template-columns: 1fr; }
            .header-stats { flex-wrap: wrap; gap: 16px; }
            .modal { width: 95%; max-height: 90vh; }
        }
        
        /* === Print styles === */
        @media print {
            .navbar, .filter-bar, .btn, .chart-actions, .modal-overlay { display: none !important; }
            body { background: white; color: black; }
            .kpi-card, .chart-card, .table-card { break-inside: avoid; }
        }
        
        /* === AFA / Sapin II Compliance Section === */
        .afa-compliance-section {
            margin: 24px 0;
            padding: 24px;
            background: var(--bg-secondary);
            border-radius: var(--radius);
            border: 1px solid var(--border);
        }
        
        .section-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 24px;
            flex-wrap: wrap;
        }
        
        .section-header h2 {
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
        }
        
        .section-subtitle {
            font-size: 0.85rem;
            color: var(--text-muted);
        }
        
        .compliance-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 24px;
        }
        
        .compliance-card {
            background: var(--bg-primary);
            border-radius: var(--radius);
            padding: 20px;
            text-align: center;
            border: 2px solid var(--border);
            transition: var(--transition-fast);
        }
        
        .compliance-card:hover {
            border-color: var(--accent);
            transform: translateY(-2px);
        }
        
        .compliance-card.success { border-color: var(--success); }
        .compliance-card.warning { border-color: var(--orange); }
        .compliance-card.danger { border-color: var(--danger); }
        
        .compliance-score-ring {
            width: 100px;
            height: 100px;
            margin: 0 auto 16px;
        }
        
        .circular-chart {
            display: block;
            width: 100%;
            height: 100%;
        }
        
        .circle-bg {
            fill: none;
            stroke: var(--bg-secondary);
            stroke-width: 3.8;
        }
        
        .circle {
            fill: none;
            stroke-width: 2.8;
            stroke-linecap: round;
            stroke: var(--accent);
            transition: stroke-dasharray 0.6s ease;
        }
        
        .compliance-card.success .circle { stroke: var(--success); }
        .compliance-card.warning .circle { stroke: var(--orange); }
        .compliance-card.danger .circle { stroke: var(--danger); }
        
        .circular-chart .percentage {
            fill: var(--text);
            font-family: inherit;
            font-size: 0.5em;
            font-weight: 700;
            text-anchor: middle;
        }
        
        .compliance-icon {
            font-size: 2rem;
            margin-bottom: 8px;
        }
        
        .compliance-value {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--text);
            line-height: 1;
        }
        
        .compliance-unit {
            font-size: 1rem;
            color: var(--text-muted);
            font-weight: 500;
        }
        
        .compliance-label {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--text-secondary);
            margin: 8px 0 4px;
        }
        
        .compliance-sublabel {
            font-size: 0.75rem;
            color: var(--text-muted);
        }
        
        .compliance-details {
            margin-top: 12px;
            text-align: left;
            font-size: 0.8rem;
        }
        
        .detail-row {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 4px 0;
            color: var(--text-secondary);
        }
        
        .detail-icon {
            font-size: 0.9rem;
        }
        
        /* Gap Analysis Grid */
        .gap-analysis-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .gap-card {
            background: var(--bg-primary);
            border-radius: var(--radius);
            padding: 20px;
            border: 1px solid var(--border);
        }
        
        .gap-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            flex-wrap: wrap;
            gap: 8px;
        }
        
        .gap-header h3 {
            margin: 0;
            font-size: 1rem;
            font-weight: 600;
        }
        
        .gap-total {
            font-size: 0.8rem;
            color: var(--text-muted);
            background: var(--bg-secondary);
            padding: 4px 10px;
            border-radius: 12px;
        }
        
        .gap-subtitle {
            font-size: 0.8rem;
            color: var(--text-muted);
        }
        
        .gap-bars {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        
        .gap-bar-row {
            display: grid;
            grid-template-columns: 100px 1fr;
            align-items: center;
            gap: 12px;
        }
        
        .gap-label {
            font-size: 0.8rem;
            color: var(--text-secondary);
            text-align: right;
        }
        
        .gap-bar-container {
            height: 24px;
            background: var(--bg-secondary);
            border-radius: 4px;
            overflow: hidden;
        }
        
        .gap-bar {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            padding-right: 8px;
            font-size: 0.75rem;
            font-weight: 600;
            color: white;
            min-width: 30px;
            border-radius: 4px;
        }
        
        .gap-bar.critical { background: linear-gradient(90deg, #dc3545, #c92a2a); }
        .gap-bar.warning { background: linear-gradient(90deg, #fd7e14, #f76707); }
        .gap-bar.success { background: linear-gradient(90deg, #28a745, #20c997); }
        
        .urgency-meter {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--border);
        }
        
        .urgency-label {
            font-size: 0.8rem;
            color: var(--text-muted);
            white-space: nowrap;
        }
        
        .urgency-bar-container {
            flex: 1;
            height: 8px;
            background: var(--bg-secondary);
            border-radius: 4px;
            overflow: hidden;
        }
        
        .urgency-bar {
            height: 100%;
            background: linear-gradient(90deg, var(--success), var(--orange), var(--danger));
            border-radius: 4px;
            transition: width 0.6s ease;
        }
        
        .urgency-value {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--text);
            min-width: 55px;
            text-align: right;
        }
        
        /* Risk Profile */
        .risk-profile {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .profile-row {
            display: grid;
            grid-template-columns: 70px 1fr 45px 50px;
            align-items: center;
            gap: 8px;
        }
        
        .profile-level {
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            padding: 3px 8px;
            border-radius: 4px;
            text-align: center;
        }
        
        .profile-level.critical { background: var(--danger); color: white; }
        .profile-level.high { background: var(--orange); color: white; }
        .profile-level.moderate { background: var(--yellow); color: #1a1a2e; }
        .profile-level.low { background: var(--success); color: white; }
        
        .profile-bar-container {
            height: 20px;
            background: var(--bg-secondary);
            border-radius: 4px;
            overflow: visible;
            position: relative;
        }
        
        .profile-bar {
            height: 100%;
            border-radius: 4px;
            transition: width 0.6s ease;
        }
        
        .profile-bar.critical { background: var(--danger); }
        .profile-bar.high { background: var(--orange); }
        .profile-bar.moderate { background: var(--yellow); }
        .profile-bar.low { background: var(--success); }
        
        .target-line {
            position: absolute;
            top: -4px;
            bottom: -4px;
            width: 2px;
            background: var(--text);
            z-index: 10;
        }
        
        .target-line::after {
            content: '▼';
            position: absolute;
            top: -14px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 8px;
            color: var(--text-muted);
        }
        
        .profile-value {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--text);
            text-align: right;
        }
        
        .gap-indicator {
            font-size: 0.75rem;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 4px;
            text-align: center;
        }
        
        .gap-indicator.over { background: rgba(220, 53, 69, 0.2); color: var(--danger); }
        .gap-indicator.ok { background: rgba(40, 167, 69, 0.2); color: var(--success); }
        
        /* Sapin II Pillars */
        .sapin-pillars .pillar-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
        }
        
        .pillar-item {
            text-align: center;
            padding: 16px 12px;
            background: var(--bg-secondary);
            border-radius: var(--radius-sm);
        }
        
        .pillar-icon {
            font-size: 1.5rem;
            margin-bottom: 6px;
        }
        
        .pillar-name {
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 4px;
        }
        
        .pillar-value {
            font-size: 1.4rem;
            font-weight: 700;
            color: var(--text);
        }
        
        .pillar-detail {
            font-size: 0.7rem;
            color: var(--text-muted);
        }
        
        /* Concentration Summary */
        .concentration-summary {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            padding: 16px;
            background: var(--bg-primary);
            border-radius: var(--radius-sm);
            border: 1px solid var(--border);
        }
        
        .concentration-item {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .concentration-label {
            font-size: 0.8rem;
            color: var(--text-muted);
        }
        
        .concentration-value {
            font-weight: 600;
            color: var(--text);
        }
        
        .concentration-hint,
        .concentration-detail {
            font-size: 0.75rem;
            color: var(--text-muted);
        }
        
        /* Responsive for AFA section */
        @media (max-width: 768px) {
            .compliance-grid { grid-template-columns: repeat(2, 1fr); }
            .gap-analysis-grid { grid-template-columns: 1fr; }
            .profile-row { grid-template-columns: 60px 1fr 40px 45px; }
            .sapin-pillars .pillar-grid { grid-template-columns: repeat(2, 1fr); }
            .concentration-summary { flex-direction: column; }
        }
        
        @media (max-width: 480px) {
            .compliance-grid { grid-template-columns: 1fr; }
            .gap-bar-row { grid-template-columns: 80px 1fr; }
        }
    </style>'''
    
    def _generate_navigation(self) -> str:
        """Generate navigation bar."""
        return '''
    <nav class="navbar">
        <div class="navbar-inner">
            <div class="nav-brand">
                <div class="nav-brand-icon">🛡️</div>
                <span>Risk Control</span>
            </div>
            
            <div class="nav-links">
                <a href="#main-content" class="nav-link active">Dashboard</a>
                <a href="#charts-section" class="nav-link">Analytics</a>
                <a href="#risk-table" class="nav-link">Risk Registry</a>
            </div>
            
            <div class="nav-actions">
                <button class="btn btn-ghost" onclick="exportToPDF()">
                    <span>📥</span> Export
                </button>
                <button class="theme-toggle btn-ghost" onclick="toggleTheme()" title="Toggle theme">
                    <span id="theme-icon">🌙</span>
                </button>
            </div>
        </div>
    </nav>'''
    
    def _generate_header(self, analysis: RiskAnalysis) -> str:
        """Generate dashboard header."""
        s = analysis.summary
        return f'''
    <div class="dashboard-header animate-in">
        <h1>Risk Cartography Dashboard</h1>
        <div class="subtitle">
            Corruption Risk Analysis • {s.total_entities} Entities • {datetime.now().strftime('%B %d, %Y')}
        </div>
        <div class="header-stats">
            <div class="header-stat">
                <div class="header-stat-value">{s.total_risks}</div>
                <div class="header-stat-label">Total Risks</div>
            </div>
            <div class="header-stat">
                <div class="header-stat-value">{s.risk_reduction_pct:+.0f}%</div>
                <div class="header-stat-label">Risk Reduction</div>
            </div>
            <div class="header-stat">
                <div class="header-stat-value">{s.avg_residual_score:.1f}</div>
                <div class="header-stat-label">Avg Score</div>
            </div>
        </div>
    </div>'''
    
    def _generate_filter_bar(self, df: pd.DataFrame, analysis: RiskAnalysis) -> str:
        """Generate interactive filter bar with configurable labels."""
        entities = sorted(df['entity'].unique())
        
        # Get category names from labels config
        cat_labels = self.labels.get('categories', {})
        categories = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
        cat_names = {
            'A': cat_labels.get('A', 'Procurement'),
            'B': cat_labels.get('B', 'Sales/Commercial'),
            'C': cat_labels.get('C', 'Human Resources'),
            'D': cat_labels.get('D', 'Finance'),
            'E': cat_labels.get('E', 'M&A / JV'),
            'F': cat_labels.get('F', 'Sponsorship'),
            'G': cat_labels.get('G', 'Public Officials')
        }
        
        # Get filter labels
        entity_label = self._get_label('filters', 'entity_label', default='Entity')
        entity_all = self._get_label('filters', 'entity_all', default='All Entities')
        level_label = self._get_label('filters', 'level_label', default='Risk Level')
        level_all = self._get_label('filters', 'level_all', default='All Levels')
        category_label = self._get_label('filters', 'category_label', default='Process')
        category_all = self._get_label('filters', 'category_all', default='All Processes')
        search_label = self._get_label('filters', 'search_label', default='Search')
        search_placeholder = self._get_label('filters', 'search_placeholder', default='Search risks...')
        
        # Get risk level labels
        critical = self._get_label('risk_levels', 'critical', default='🔴 Critical')
        high = self._get_label('risk_levels', 'high', default='🟠 High')
        moderate = self._get_label('risk_levels', 'moderate', default='🟡 Moderate')
        low = self._get_label('risk_levels', 'low', default='🟢 Low')
        
        entity_options = ''.join(f'<option value="{e}">{e}</option>' for e in entities)
        cat_options = ''.join(f'<option value="{c}">{c} - {cat_names[c]}</option>' for c in categories)
        
        return f'''
    <div class="filter-bar animate-in" style="animation-delay: 0.1s;">
        <div class="filter-group">
            <label class="filter-label">{entity_label}</label>
            <select class="filter-select" id="entity-filter" onchange="applyFilters()">
                <option value="">{entity_all}</option>
                {entity_options}
            </select>
        </div>
        
        <div class="filter-group">
            <label class="filter-label">{level_label}</label>
            <select class="filter-select" id="level-filter" onchange="applyFilters()">
                <option value="">{level_all}</option>
                <option value="{critical}">{critical}</option>
                <option value="{high}">{high}</option>
                <option value="{moderate}">{moderate}</option>
                <option value="{low}">{low}</option>
            </select>
        </div>
        
        <div class="filter-group">
            <label class="filter-label">{category_label}</label>
            <select class="filter-select" id="category-filter" onchange="applyFilters()">
                <option value="">{category_all}</option>
                {cat_options}
            </select>
        </div>
        
        <div class="filter-group" style="flex: 1;">
            <label class="filter-label">{search_label}</label>
            <input type="text" class="filter-input" id="search-filter" 
                   placeholder="{search_placeholder}" 
                   oninput="applyFilters()">
        </div>
        
        <div class="filter-chips" id="active-filters"></div>
        
        <div class="filter-stats">
            <span>Showing <span class="filter-count" id="visible-count">{analysis.summary.total_risks}</span> of {analysis.summary.total_risks}</span>
            <button class="btn btn-ghost" onclick="resetFilters()">Reset</button>
        </div>
    </div>'''
    
    def _generate_alert_panel(self, analysis: RiskAnalysis) -> str:
        """Generate critical risk alert panel."""
        critical_count = sum(1 for r in analysis.top_risks if '🔴' in str(r.get('level_residual', '')))
        
        if critical_count == 0:
            return '<div class="alert-panel hidden"></div>'
        
        return f'''
    <div class="alert-panel animate-in" style="animation-delay: 0.15s;">
        <div class="alert-icon">⚠️</div>
        <div class="alert-content">
            <div class="alert-title">Critical Risks Detected</div>
            <div class="alert-description">
                {critical_count} risk(s) require immediate attention with residual scores ≥10
            </div>
        </div>
        <button class="alert-action" onclick="filterCritical()">View Critical Risks</button>
    </div>'''
    
    def _generate_executive_summary(self, analysis: RiskAnalysis) -> str:
        """Generate executive summary insights."""
        s = analysis.summary
        m = analysis.mitigation
        
        # Find highest risk entity
        worst_entity = max(analysis.by_entity.items(), 
                         key=lambda x: x[1].avg_residual_score)
        best_entity = min(analysis.by_entity.items(),
                         key=lambda x: x[1].avg_residual_score)
        
        # Mitigation effectiveness
        mitigation_rate = (m.improved / s.total_risks * 100) if m else 0
        
        return f'''
    <div class="section-wrapper animate-in" style="animation-delay: 0.2s;">
        <div class="section-header-simple">
            <h2>📊 Executive Summary {self._generate_help_icon('executive_summary')}</h2>
        </div>
        <div class="executive-summary">
        <div class="insight-card success">
            <div class="insight-icon">📉</div>
            <div class="insight-title">Risk Reduction</div>
            <div class="insight-value">{s.risk_reduction_pct:+.1f}%</div>
            <div class="insight-detail">
                Average score reduced from {s.avg_gross_score:.1f} to {s.avg_residual_score:.1f}
                <span class="insight-trend trend-up">✓ Effective</span>
            </div>
        </div>
        
        <div class="insight-card warning">
            <div class="insight-icon">🎯</div>
            <div class="insight-title">Mitigation Rate</div>
            <div class="insight-value">{mitigation_rate:.0f}%</div>
            <div class="insight-detail">
                {m.improved if m else 0} of {s.total_risks} risks successfully mitigated
            </div>
        </div>
        
        <div class="insight-card danger">
            <div class="insight-icon">📍</div>
            <div class="insight-title">Highest Exposure</div>
            <div class="insight-value">{worst_entity[0]}</div>
            <div class="insight-detail">
                Average residual score: {worst_entity[1].avg_residual_score:.1f} 
                ({worst_entity[1].critical_count} critical)
            </div>
        </div>
        
        <div class="insight-card accent">
            <div class="insight-icon">⭐</div>
            <div class="insight-title">Best Performance</div>
            <div class="insight-value">{best_entity[0]}</div>
            <div class="insight-detail">
                Average residual score: {best_entity[1].avg_residual_score:.1f}
                <span class="insight-trend trend-up">★ Benchmark</span>
            </div>
        </div>
    </div>
    </div>'''
    
    def _generate_afa_compliance_section(self, analysis: RiskAnalysis) -> str:
        """Generate AFA/Sapin II compliance scorecard section."""
        afa = analysis.afa_compliance
        gaps = analysis.control_gaps
        pillars = analysis.sapin_ii_pillars
        trends = analysis.risk_trends
        conc = analysis.risk_concentration
        
        # Determine compliance level colors
        def get_score_class(score, thresholds=(30, 60, 80)):
            if score >= thresholds[2]:
                return 'success'
            elif score >= thresholds[1]:
                return 'warning'
            else:
                return 'danger'
        
        compliance_class = get_score_class(pillars.overall_compliance_score)
        control_class = get_score_class(afa.control_effectiveness_score)
        coverage_class = get_score_class(afa.control_coverage_rate)
        
        # Risk appetite status
        appetite_class = 'success' if trends.appetite_breach_rate < 30 else ('warning' if trends.appetite_breach_rate < 50 else 'danger')
        
        return f'''
    <div class="afa-compliance-section animate-in" style="animation-delay: 0.22s;">
        <div class="section-header">
            <h2>📋 AFA / Sapin II Compliance Dashboard {self._generate_help_icon('afa_compliance')}</h2>
            <span class="section-subtitle">Agence Française Anticorruption Compliance Metrics</span>
        </div>
        
        <div class="compliance-grid">
            <!-- Overall Compliance Score -->
            <div class="compliance-card {compliance_class}">
                <div class="compliance-score-ring">
                    <svg viewBox="0 0 36 36" class="circular-chart">
                        <path class="circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
                        <path class="circle" stroke-dasharray="{pillars.overall_compliance_score}, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/>
                        <text x="18" y="20.35" class="percentage">{pillars.overall_compliance_score:.0f}</text>
                    </svg>
                </div>
                <div class="compliance-label">Overall Compliance Score</div>
                <div class="compliance-sublabel">Based on Sapin II pillars</div>
            </div>
            
            <!-- Control Effectiveness -->
            <div class="compliance-card {control_class}">
                <div class="compliance-icon">🛡️</div>
                <div class="compliance-value">{afa.control_effectiveness_score:.0f}<span class="compliance-unit">/100</span></div>
                <div class="compliance-label">Control Effectiveness</div>
                <div class="compliance-details">
                    <div class="detail-row">
                        <span class="detail-icon">✅</span>
                        <span>Highly Effective: {afa.highly_effective_controls}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-icon">⚡</span>
                        <span>Moderate: {afa.moderately_effective_controls}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-icon">⚠️</span>
                        <span>Ineffective: {afa.ineffective_controls}</span>
                    </div>
                </div>
            </div>
            
            <!-- Control Coverage -->
            <div class="compliance-card {coverage_class}">
                <div class="compliance-icon">📊</div>
                <div class="compliance-value">{afa.control_coverage_rate:.0f}<span class="compliance-unit">%</span></div>
                <div class="compliance-label">Control Coverage</div>
                <div class="compliance-details">
                    <div class="detail-row">
                        <span class="detail-icon">🟢</span>
                        <span>With Controls: {afa.risks_with_controls}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-icon">🔴</span>
                        <span>Without Controls: {afa.risks_without_controls}</span>
                    </div>
                </div>
            </div>
            
            <!-- Risk Appetite -->
            <div class="compliance-card {appetite_class}">
                <div class="compliance-icon">🎯</div>
                <div class="compliance-value">{trends.appetite_breach_rate:.0f}<span class="compliance-unit">%</span></div>
                <div class="compliance-label">Appetite Breach Rate</div>
                <div class="compliance-details">
                    <div class="detail-row">
                        <span class="detail-icon">✅</span>
                        <span>Within Appetite: {trends.risks_within_appetite}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-icon">⚠️</span>
                        <span>Exceeding: {trends.risks_exceeding_appetite}</span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Gap Analysis Section -->
        <div class="gap-analysis-grid">
            <div class="gap-card">
                <div class="gap-header">
                    <h3>🔥 Priority Gaps</h3>
                    <span class="gap-total">{gaps.total_control_gaps} gaps identified</span>
                </div>
                <div class="gap-bars">
                    <div class="gap-bar-row">
                        <span class="gap-label">High Priority</span>
                        <div class="gap-bar-container">
                            <div class="gap-bar critical" style="width: {min(100, gaps.high_priority_gaps / max(1, gaps.total_control_gaps) * 100):.0f}%">
                                {gaps.high_priority_gaps}
                            </div>
                        </div>
                    </div>
                    <div class="gap-bar-row">
                        <span class="gap-label">Medium Priority</span>
                        <div class="gap-bar-container">
                            <div class="gap-bar warning" style="width: {min(100, gaps.medium_priority_gaps / max(1, gaps.total_control_gaps) * 100):.0f}%">
                                {gaps.medium_priority_gaps}
                            </div>
                        </div>
                    </div>
                    <div class="gap-bar-row">
                        <span class="gap-label">Low Priority</span>
                        <div class="gap-bar-container">
                            <div class="gap-bar success" style="width: {min(100, gaps.low_priority_gaps / max(1, gaps.total_control_gaps) * 100):.0f}%">
                                {gaps.low_priority_gaps}
                            </div>
                        </div>
                    </div>
                </div>
                <div class="urgency-meter">
                    <span class="urgency-label">Urgency Score:</span>
                    <div class="urgency-bar-container">
                        <div class="urgency-bar" style="width: {gaps.urgency_score}%"></div>
                    </div>
                    <span class="urgency-value">{gaps.urgency_score:.0f}/100</span>
                </div>
            </div>
            
            <div class="gap-card">
                <div class="gap-header">
                    <h3>📊 Residual Risk Profile</h3>
                    <span class="gap-subtitle">vs. Target State</span>
                </div>
                <div class="risk-profile">
                    <div class="profile-row">
                        <span class="profile-level critical">Critical</span>
                        <div class="profile-bar-container">
                            <div class="profile-bar critical" style="width: {gaps.residual_critical_pct}%"></div>
                            <div class="target-line" style="left: {gaps.target_critical_max_pct}%" title="Target: max {gaps.target_critical_max_pct}%"></div>
                        </div>
                        <span class="profile-value">{gaps.residual_critical_pct:.1f}%</span>
                        <span class="gap-indicator {'over' if gaps.gap_to_target_critical > 0 else 'ok'}">
                            {'+' if gaps.gap_to_target_critical > 0 else ''}{gaps.gap_to_target_critical:.1f}%
                        </span>
                    </div>
                    <div class="profile-row">
                        <span class="profile-level high">High</span>
                        <div class="profile-bar-container">
                            <div class="profile-bar high" style="width: {gaps.residual_high_pct}%"></div>
                            <div class="target-line" style="left: {gaps.target_high_max_pct}%" title="Target: max {gaps.target_high_max_pct}%"></div>
                        </div>
                        <span class="profile-value">{gaps.residual_high_pct:.1f}%</span>
                        <span class="gap-indicator {'over' if gaps.gap_to_target_high > 0 else 'ok'}">
                            {'+' if gaps.gap_to_target_high > 0 else ''}{gaps.gap_to_target_high:.1f}%
                        </span>
                    </div>
                    <div class="profile-row">
                        <span class="profile-level moderate">Moderate</span>
                        <div class="profile-bar-container">
                            <div class="profile-bar moderate" style="width: {gaps.residual_moderate_pct}%"></div>
                        </div>
                        <span class="profile-value">{gaps.residual_moderate_pct:.1f}%</span>
                    </div>
                    <div class="profile-row">
                        <span class="profile-level low">Low</span>
                        <div class="profile-bar-container">
                            <div class="profile-bar low" style="width: {gaps.residual_low_pct}%"></div>
                        </div>
                        <span class="profile-value">{gaps.residual_low_pct:.1f}%</span>
                    </div>
                </div>
            </div>
            
            <div class="gap-card sapin-pillars">
                <div class="gap-header">
                    <h3>⚖️ Sapin II Pillars</h3>
                    <span class="gap-subtitle">Key Indicators</span>
                </div>
                <div class="pillar-grid">
                    <div class="pillar-item">
                        <div class="pillar-icon">🗺️</div>
                        <div class="pillar-name">Risk Mapping</div>
                        <div class="pillar-value">{pillars.risk_mapping_coverage:.0f}%</div>
                        <div class="pillar-detail">{pillars.risk_mapping_depth:.1f} scenarios/process</div>
                    </div>
                    <div class="pillar-item">
                        <div class="pillar-icon">🤝</div>
                        <div class="pillar-name">Third-Party Exposure</div>
                        <div class="pillar-value">{pillars.third_party_exposure_pct:.0f}%</div>
                        <div class="pillar-detail">of total risks</div>
                    </div>
                    <div class="pillar-item">
                        <div class="pillar-icon">🔒</div>
                        <div class="pillar-name">Internal Controls</div>
                        <div class="pillar-value">{pillars.internal_control_effectiveness:.0f}%</div>
                        <div class="pillar-detail">effectiveness</div>
                    </div>
                    <div class="pillar-item">
                        <div class="pillar-icon">📋</div>
                        <div class="pillar-name">Remediation</div>
                        <div class="pillar-value">{afa.remediation_coverage_rate:.0f}%</div>
                        <div class="pillar-detail">action plan coverage</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Risk Concentration -->
        <div class="concentration-summary">
            <div class="concentration-item">
                <span class="concentration-label">Entity Concentration:</span>
                <span class="concentration-value">{conc.entity_concentration_index:.3f}</span>
                <span class="concentration-hint">(HHI Index: 0=spread, 1=concentrated)</span>
            </div>
            <div class="concentration-item">
                <span class="concentration-label">Highest Exposure:</span>
                <span class="concentration-value">{conc.highest_risk_entity}</span>
                <span class="concentration-detail">({conc.highest_risk_entity_pct:.1f}% of risks)</span>
            </div>
            <div class="concentration-item">
                <span class="concentration-label">Critical Risk Distribution:</span>
                <span class="concentration-value">{conc.entities_with_critical_risks}/{conc.entities_with_critical_risks + conc.entities_without_critical_risks} entities</span>
                <span class="concentration-detail">{conc.critical_risk_concentration:.1f}% concentration</span>
            </div>
        </div>
    </div>'''
    
    def _generate_kpi_cards(self, analysis: RiskAnalysis) -> str:
        """Generate KPI cards with Risk Appetite Breach indicator."""
        s = analysis.summary
        m = analysis.mitigation
        rt = analysis.risk_trends  # Risk trends stats
        
        critical_count = analysis.by_level.get('🔴 Critical', type('', (), {'count': 0})).count
        high_count = analysis.by_level.get('🟠 High', type('', (), {'count': 0})).count
        
        # Calculate appetite breach rate
        appetite_breach_rate = rt.appetite_breach_rate if rt else 0
        risks_exceeding = rt.risks_exceeding_appetite if rt else 0
        
        # Get KPI labels from config
        kpi = self.labels.get('kpi_cards', {})
        total_risks_label = kpi.get('total_risks', 'Total Risks')
        critical_label = kpi.get('critical_risks', 'Critical')
        high_label = kpi.get('high_risks', 'High')
        entities_label = kpi.get('entities_analyzed', 'Entities')
        
        # Get risk level values for filtering
        critical = self._get_label('risk_levels', 'critical', default='🔴 Critical')
        high = self._get_label('risk_levels', 'high', default='🟠 High')
        
        # Determine appetite breach severity class
        breach_class = 'success' if appetite_breach_rate <= 15 else 'warning' if appetite_breach_rate <= 30 else 'danger'
        breach_status = '✓ Good' if appetite_breach_rate <= 15 else '⚠ Attention' if appetite_breach_rate <= 30 else '⛔ Critical'
        
        return f'''
    <div class="section-wrapper animate-in" style="animation-delay: 0.25s;">
        <div class="section-header-simple">
            <h2>📈 Key Performance Indicators {self._generate_help_icon('kpi_cards')}</h2>
        </div>
        <div class="kpi-container">
        <div class="kpi-card accent" onclick="filterByLevel('')" title="Click to view all">
            <div class="kpi-value count-up">{s.total_risks}</div>
            <div class="kpi-label">{total_risks_label}</div>
        </div>
        <div class="kpi-card danger" onclick="filterByLevel('{critical}')" title="Click to filter">
            <div class="kpi-value count-up">{critical_count}</div>
            <div class="kpi-label">{critical_label}</div>
        </div>
        <div class="kpi-card warning" onclick="filterByLevel('{high}')" title="Click to filter">
            <div class="kpi-value count-up">{high_count}</div>
            <div class="kpi-label">{high_label}</div>
        </div>
        <div class="kpi-card {breach_class}" title="{risks_exceeding} risks exceed appetite (High + Critical)">
            <div class="kpi-value count-up">{appetite_breach_rate:.0f}%</div>
            <div class="kpi-label">Appetite Breach</div>
            <div class="kpi-change" style="font-size: 0.75rem;">{breach_status}</div>
        </div>
        <div class="kpi-card success">
            <div class="kpi-value count-up">{m.improved if m else 0}</div>
            <div class="kpi-label">Mitigated</div>
            <div class="kpi-change" style="color: var(--success);">↓ Reduced</div>
        </div>
        <div class="kpi-card {'success' if s.risk_reduction_pct > 0 else 'warning'}">
            <div class="kpi-value count-up">{s.risk_reduction_pct:+.0f}%</div>
            <div class="kpi-label">Reduction</div>
        </div>
        <div class="kpi-card accent">
            <div class="kpi-value count-up">{s.total_entities}</div>
            <div class="kpi-label">{entities_label}</div>
        </div>
    </div>
    </div>'''
    
    def _generate_charts_section(self, analysis: RiskAnalysis) -> str:
        """Generate charts section with configurable labels and Gross vs Residual comparison."""
        # Get chart titles from labels config
        level_title = self._get_label('charts', 'risks_by_level', 'title', default='Risk Level Distribution')
        category_title = self._get_label('charts', 'risks_by_category', 'title', default='Risks by Category')
        entity_title = self._get_label('charts', 'risks_by_entity', 'title', default='Risks by Entity')
        mitigation_title = self._get_label('charts', 'mitigation_status', 'title', default='Mitigation Effectiveness')
        
        return f'''
    <div class="charts-grid animate-in" style="animation-delay: 0.3s;">
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">📊 {level_title} {self._generate_help_icon('risk_level_chart')}</h3>
                <div class="chart-actions">
                    <button class="chart-btn" onclick="toggleChartType('riskLevelChart')" title="Toggle chart type">🔄</button>
                </div>
            </div>
            <div class="chart-container">
                <canvas id="riskLevelChart"></canvas>
            </div>
        </div>
        
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">📁 {category_title} {self._generate_help_icon('category_chart')}</h3>
            </div>
            <div class="chart-container">
                <canvas id="categoryChart"></canvas>
            </div>
        </div>
        
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">🏢 {entity_title} {self._generate_help_icon('entity_chart')}</h3>
            </div>
            <div class="chart-container">
                <canvas id="entityChart"></canvas>
            </div>
        </div>
        
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">📈 {mitigation_title} {self._generate_help_icon('mitigation_chart')}</h3>
            </div>
            <div class="chart-container">
                <canvas id="comparisonChart"></canvas>
            </div>
        </div>
    </div>
    
    <div class="charts-grid animate-in" style="animation-delay: 0.35s;">
        <div class="chart-card" style="grid-column: span 2;">
            <div class="chart-header">
                <h3 class="chart-title">📉 Control Effectiveness by Category (Gross → Residual) {self._generate_help_icon('control_effectiveness')}</h3>
            </div>
            <div class="chart-container" style="height: 300px;">
                <canvas id="grossResidualChart"></canvas>
            </div>
        </div>
    </div>'''
    
    def _generate_entity_charts_section(self, analysis: RiskAnalysis) -> str:
        """Generate charts section for entity-specific dashboard (no entity chart)."""
        level_title = self._get_label('charts', 'risks_by_level', 'title', default='Risk Level Distribution')
        category_title = self._get_label('charts', 'risks_by_category', 'title', default='Risks by Category')
        mitigation_title = self._get_label('charts', 'mitigation_status', 'title', default='Mitigation Effectiveness')
        
        return f'''
    <div class="charts-grid animate-in" style="animation-delay: 0.3s;">
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">📊 {level_title} {self._generate_help_icon('risk_level_chart')}</h3>
                <div class="chart-actions">
                    <button class="chart-btn" onclick="toggleChartType('riskLevelChart')" title="Toggle chart type">🔄</button>
                </div>
            </div>
            <div class="chart-container">
                <canvas id="riskLevelChart"></canvas>
            </div>
        </div>
        
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">📁 {category_title} {self._generate_help_icon('category_chart')}</h3>
            </div>
            <div class="chart-container">
                <canvas id="categoryChart"></canvas>
            </div>
        </div>
        
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">📈 Gross vs Residual Score by Category</h3>
            </div>
            <div class="chart-container">
                <canvas id="scoreComparisonChart"></canvas>
            </div>
        </div>
        
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">📈 {mitigation_title} {self._generate_help_icon('mitigation_chart')}</h3>
            </div>
            <div class="chart-container">
                <canvas id="comparisonChart"></canvas>
            </div>
        </div>
    </div>'''
    
    def _generate_entity_scripts(self, analysis: RiskAnalysis, risks_json: str) -> str:
        """Generate JavaScript for entity-specific dashboard (no entity chart, add score comparison)."""
        # Prepare chart data
        level_data = [
            analysis.by_level.get('🟢 Low', type('', (), {'count': 0})).count,
            analysis.by_level.get('🟡 Moderate', type('', (), {'count': 0})).count,
            analysis.by_level.get('🟠 High', type('', (), {'count': 0})).count,
            analysis.by_level.get('🔴 Critical', type('', (), {'count': 0})).count
        ]
        
        cat_labels = [s.category_name for s in analysis.by_category.values()]
        cat_counts = [s.count for s in analysis.by_category.values()]
        cat_colors = [s.color for s in analysis.by_category.values()]
        cat_gross = [round(s.avg_gross_score, 1) for s in analysis.by_category.values()]
        cat_residual = [round(s.avg_residual_score, 1) for s in analysis.by_category.values()]
        
        m = analysis.mitigation
        
        return f'''
    <script>
        // === Global Data (Entity Dashboard) ===
        const allRisks = {risks_json};
        let filteredRisks = [...allRisks];
        let sortColumn = null;
        let sortDirection = 'asc';
        let charts = {{}};
        
        // === Theme Toggle ===
        function toggleTheme() {{
            const html = document.documentElement;
            const current = html.getAttribute('data-theme');
            const newTheme = current === 'dark' ? 'light' : 'dark';
            html.setAttribute('data-theme', newTheme);
            const themeIcon = document.getElementById('theme-icon');
            if (themeIcon) themeIcon.textContent = newTheme === 'dark' ? '🌙' : '☀️';
            localStorage.setItem('theme', newTheme);
            updateChartColors();
        }}
        
        // Load saved theme
        const savedTheme = localStorage.getItem('theme') || 'dark';
        document.documentElement.setAttribute('data-theme', savedTheme);
        const themeIconInit = document.getElementById('theme-icon');
        if (themeIconInit) themeIconInit.textContent = savedTheme === 'dark' ? '🌙' : '☀️';
        
        // === Chart Configuration ===
        Chart.defaults.color = '#9ca3af';
        Chart.defaults.borderColor = 'rgba(255,255,255,0.08)';
        
        const chartColors = {{
            success: '#10b981',
            warning: '#f59e0b',
            orange: '#f97316',
            danger: '#ef4444',
            accent: '#00d4ff'
        }};
        
        function updateChartColors() {{
            const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
            Chart.defaults.color = isDark ? '#9ca3af' : '#64748b';
            Chart.defaults.borderColor = isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
            Object.values(charts).forEach(chart => chart.update());
        }}
        
        // === Initialize Charts ===
        document.addEventListener('DOMContentLoaded', function() {{
            // Risk Level Doughnut Chart
            charts.riskLevel = new Chart(document.getElementById('riskLevelChart'), {{
                type: 'doughnut',
                data: {{
                    labels: ['Low', 'Moderate', 'High', 'Critical'],
                    datasets: [{{
                        data: {level_data},
                        backgroundColor: [chartColors.success, chartColors.warning, chartColors.orange, chartColors.danger],
                        borderWidth: 0,
                        hoverOffset: 8
                    }}]
                }},
                options: {{
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '65%',
                    plugins: {{
                        legend: {{ position: 'bottom', labels: {{ padding: 16 }} }},
                        tooltip: {{
                            callbacks: {{
                                label: function(ctx) {{
                                    const total = ctx.dataset.data.reduce((a, b) => a + b, 0);
                                    const pct = ((ctx.raw / total) * 100).toFixed(1);
                                    return ctx.label + ': ' + ctx.raw + ' (' + pct + '%)';
                                }}
                            }}
                        }}
                    }},
                    animation: {{ animateRotate: true, animateScale: true }}
                }}
            }});
            
            // Category Bar Chart
            charts.category = new Chart(document.getElementById('categoryChart'), {{
                type: 'bar',
                data: {{
                    labels: {json.dumps(cat_labels)},
                    datasets: [{{
                        label: 'Risk Count',
                        data: {cat_counts},
                        backgroundColor: {json.dumps(cat_colors)},
                        borderRadius: 6,
                        borderSkipped: false
                    }}]
                }},
                options: {{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {{
                        legend: {{ display: false }},
                        tooltip: {{
                            callbacks: {{
                                title: function(ctx) {{ return ctx[0].label; }},
                                label: function(ctx) {{ return ctx.raw + ' risks'; }}
                            }}
                        }}
                    }},
                    scales: {{
                        y: {{ beginAtZero: true, ticks: {{ stepSize: 5 }} }},
                        x: {{ grid: {{ display: false }} }}
                    }},
                    animation: {{ duration: 800, easing: 'easeOutQuart' }}
                }}
            }});
            
            // Score Comparison by Category (Gross vs Residual) - replaces entity chart for single entity
            charts.scoreComparison = new Chart(document.getElementById('scoreComparisonChart'), {{
                type: 'bar',
                data: {{
                    labels: {json.dumps(cat_labels)},
                    datasets: [
                        {{ label: 'Gross', data: {cat_gross}, backgroundColor: 'rgba(249,115,22,0.7)', borderRadius: 4 }},
                        {{ label: 'Residual', data: {cat_residual}, backgroundColor: 'rgba(16,185,129,0.7)', borderRadius: 4 }}
                    ]
                }},
                options: {{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {{ legend: {{ position: 'bottom' }} }},
                    scales: {{
                        y: {{ beginAtZero: true, max: 16 }},
                        x: {{ grid: {{ display: false }} }}
                    }},
                    animation: {{ duration: 800 }}
                }}
            }});
            
            // Mitigation Comparison Chart (Gross avg vs Residual avg)
            const totalGross = {cat_gross}.reduce((a, b) => a + b, 0) / Math.max({cat_gross}.length, 1);
            const totalResidual = {cat_residual}.reduce((a, b) => a + b, 0) / Math.max({cat_residual}.length, 1);
            
            charts.comparison = new Chart(document.getElementById('comparisonChart'), {{
                type: 'bar',
                data: {{
                    labels: ['Average Risk Score'],
                    datasets: [
                        {{ label: 'Gross', data: [totalGross.toFixed(1)], backgroundColor: 'rgba(249,115,22,0.7)', borderRadius: 4 }},
                        {{ label: 'Residual', data: [totalResidual.toFixed(1)], backgroundColor: 'rgba(16,185,129,0.7)', borderRadius: 4 }}
                    ]
                }},
                options: {{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {{ legend: {{ position: 'bottom' }} }},
                    scales: {{
                        y: {{ beginAtZero: true, max: 16 }},
                        x: {{ grid: {{ display: false }} }}
                    }},
                    animation: {{ duration: 800 }}
                }}
            }});
            
            // Mitigation Pie Chart
            charts.mitigation = new Chart(document.getElementById('mitigationChart'), {{
                type: 'pie',
                data: {{
                    labels: ['Reduced', 'Unchanged', 'Increased'],
                    datasets: [{{
                        data: [{m.improved if m else 0}, {m.unchanged if m else 0}, {m.worsened if m else 0}],
                        backgroundColor: [chartColors.success, '#6b7280', chartColors.danger],
                        borderWidth: 0
                    }}]
                }},
                options: {{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {{ legend: {{ position: 'bottom' }} }},
                    animation: {{ animateRotate: true }}
                }}
            }});
            
            // Category Radar Chart
            charts.categoryRadar = new Chart(document.getElementById('categoryRadarChart'), {{
                type: 'radar',
                data: {{
                    labels: {json.dumps([l[:12] for l in cat_labels])},
                    datasets: [
                        {{ 
                            label: 'Gross', 
                            data: {cat_gross}, 
                            backgroundColor: 'rgba(249,115,22,0.2)', 
                            borderColor: chartColors.orange, 
                            pointBackgroundColor: chartColors.orange,
                            pointRadius: 4
                        }},
                        {{ 
                            label: 'Residual', 
                            data: {cat_residual}, 
                            backgroundColor: 'rgba(16,185,129,0.2)', 
                            borderColor: chartColors.success, 
                            pointBackgroundColor: chartColors.success,
                            pointRadius: 4
                        }}
                    ]
                }},
                options: {{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {{ legend: {{ position: 'bottom' }} }},
                    scales: {{
                        r: {{ 
                            beginAtZero: true, 
                            max: 16,
                            ticks: {{ stepSize: 4 }}
                        }}
                    }}
                }}
            }});
            
            // Populate risk registry
            populateRegistry();
        }});
        
        // === Filter Functions ===
        function applyFilters() {{
            const levelFilter = document.getElementById('level-filter')?.value || '';
            const categoryFilter = document.getElementById('category-filter')?.value || '';
            const searchFilter = (document.getElementById('search-filter')?.value || '').toLowerCase();
            
            filteredRisks = allRisks.filter(risk => {{
                if (levelFilter && risk.level_residual !== levelFilter) return false;
                if (categoryFilter && risk.category !== categoryFilter) return false;
                if (searchFilter) {{
                    const searchText = (risk.scenario + ' ' + risk.description + ' ' + risk.risk_id).toLowerCase();
                    if (!searchText.includes(searchFilter)) return false;
                }}
                return true;
            }});
            
            populateRegistry();
            const visibleCount = document.getElementById('visible-count');
            if (visibleCount) visibleCount.textContent = filteredRisks.length;
        }}
        
        function resetFilters() {{
            const levelEl = document.getElementById('level-filter');
            const catEl = document.getElementById('category-filter');
            const searchEl = document.getElementById('search-filter');
            if (levelEl) levelEl.value = '';
            if (catEl) catEl.value = '';
            if (searchEl) searchEl.value = '';
            applyFilters();
        }}
        
        function filterByLevel(level) {{
            const el = document.getElementById('level-filter');
            if (el) el.value = level;
            applyFilters();
        }}
        
        function filterCritical() {{
            filterByLevel('🔴 Critical');
            const table = document.getElementById('risk-table');
            if (table) table.scrollIntoView({{ behavior: 'smooth' }});
        }}
        
        // === Registry Functions ===
        function populateRegistry() {{
            const tbody = document.getElementById('registry-body');
            if (!tbody) return;
            
            const searchEl = document.getElementById('registry-search');
            const search = (searchEl?.value || '').toLowerCase();
            
            let data = [...filteredRisks];
            
            // Apply registry search
            if (search) {{
                data = data.filter(r => 
                    (r.entity + r.risk_id + r.scenario).toLowerCase().includes(search)
                );
            }}
            
            // Apply sorting
            if (sortColumn) {{
                data.sort((a, b) => {{
                    let valA = a[sortColumn];
                    let valB = b[sortColumn];
                    if (typeof valA === 'number') {{
                        return sortDirection === 'asc' ? valA - valB : valB - valA;
                    }}
                    valA = String(valA).toLowerCase();
                    valB = String(valB).toLowerCase();
                    return sortDirection === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
                }});
            }}
            
            // Generate rows
            let html = '';
            data.forEach(risk => {{
                const level = risk.level_residual;
                let badgeClass = 'badge-low';
                if (level.includes('🔴')) badgeClass = 'badge-critical';
                else if (level.includes('🟠')) badgeClass = 'badge-high';
                else if (level.includes('🟡')) badgeClass = 'badge-moderate';
                
                const scenario = risk.scenario.length > 50 ? risk.scenario.substring(0, 50) + '...' : risk.scenario;
                const levelLabel = level.replace(/[🔴🟠🟡🟢]/g, '').trim();
                
                html += '<tr onclick="showRiskDetail(\\'' + risk.entity + '\\', \\'' + risk.risk_id + '\\')">' +
                    '<td>' + risk.risk_id + '</td>' +
                    '<td>' + scenario + '</td>' +
                    '<td><span class="score-pill" style="background: rgba(249,115,22,0.2); color: #f97316;">' + risk.score_gross + '</span></td>' +
                    '<td><span class="score-pill" style="background: rgba(16,185,129,0.2); color: #10b981;">' + risk.score_residual + '</span></td>' +
                    '<td><span class="risk-badge ' + badgeClass + '">' + levelLabel + '</span></td>' +
                    '</tr>';
            }});
            
            tbody.innerHTML = html;
            const statusEl = document.getElementById('registry-status');
            if (statusEl) statusEl.textContent = 'Showing ' + data.length + ' of ' + allRisks.length + ' risks';
        }}
        
        function filterRegistry() {{
            populateRegistry();
        }}
        
        function sortRegistry(column) {{
            if (sortColumn === column) {{
                sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
            }} else {{
                sortColumn = column;
                sortDirection = 'asc';
            }}
            populateRegistry();
        }}
        
        // === Modal Functions ===
        function showRiskDetail(entity, riskId) {{
            const risk = allRisks.find(r => r.entity === entity && r.risk_id === riskId);
            if (!risk) return;
            
            document.getElementById('modal-title').textContent = entity + ' — ' + riskId;
            document.getElementById('modal-gross-score').textContent = risk.score_gross;
            document.getElementById('modal-gross-details').textContent = 'P:' + risk.prob_gross + ' × I:' + risk.impact_gross;
            document.getElementById('modal-residual-score').textContent = risk.score_residual;
            document.getElementById('modal-residual-details').textContent = 'P:' + risk.prob_residual + ' × I:' + risk.impact_residual;
            document.getElementById('modal-scenario').textContent = risk.scenario || '-';
            document.getElementById('modal-description').textContent = risk.description || '-';
            document.getElementById('modal-factors').textContent = risk.aggravating_factors || '-';
            document.getElementById('modal-prevention').textContent = risk.prevention_measures || '-';
            document.getElementById('modal-actions').textContent = risk.corrective_actions || '-';
            
            document.getElementById('risk-modal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }}
        
        function closeModal(event) {{
            if (event && event.target !== document.getElementById('risk-modal')) return;
            document.getElementById('risk-modal').classList.remove('active');
            document.body.style.overflow = '';
        }}
        
        // Close on Escape
        document.addEventListener('keydown', function(e) {{
            if (e.key === 'Escape') closeModal();
        }});
        
        // === Export Functions ===
        function exportToPDF() {{
            window.print();
        }}
        
        function exportToCSV() {{
            const headers = ['Risk ID', 'Scenario', 'Prob Gross', 'Impact Gross', 'Score Gross', 'Prob Residual', 'Impact Residual', 'Score Residual', 'Level'];
            const rows = filteredRisks.map(r => [
                r.risk_id, '"' + r.scenario.replace(/"/g, '""') + '"',
                r.prob_gross, r.impact_gross, r.score_gross,
                r.prob_residual, r.impact_residual, r.score_residual,
                r.level_residual.replace(/[🔴🟠🟡🟢]/g, '').trim()
            ]);
            
            let csv = headers.join(',') + '\\n';
            rows.forEach(row => csv += row.join(',') + '\\n');
            
            const blob = new Blob([csv], {{ type: 'text/csv;charset=utf-8;' }});
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'risk_registry_' + new Date().toISOString().slice(0,10) + '.csv';
            link.click();
        }}
        
        function printDashboard() {{
            window.print();
        }}
        
        // === Chart Type Toggle ===
        function toggleChartType(chartId) {{
            const chart = charts.riskLevel;
            chart.config.type = chart.config.type === 'doughnut' ? 'bar' : 'doughnut';
            chart.update();
        }}
    </script>'''
    
    def _generate_risk_matrix_section(self, df: pd.DataFrame) -> str:
        """Generate risk matrix section following Sapin II / Audit standard format."""
        matrix_config = self.labels.get('charts', {}).get('risk_matrix', {})
        matrix_title = matrix_config.get('title', 'Risk Heat Matrix')
        x_axis = matrix_config.get('x_axis', 'IMPACT')
        y_axis = matrix_config.get('y_axis', 'PROBABILITY')
        gross_title = matrix_config.get('gross_title', 'Inherent Risk')
        residual_title = matrix_config.get('residual_title', 'Residual Risk')
        
        prob_labels = matrix_config.get('probability_labels', {
            '4': 'Very Likely', '3': 'Likely', '2': 'Unlikely', '1': 'Rare'
        })
        impact_labels = matrix_config.get('impact_labels', {
            '1': 'Minor', '2': 'Moderate', '3': 'Major', '4': 'Critical'
        })
        
        return f'''
    <div class="charts-grid animate-in" style="animation-delay: 0.35s;">
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">🔥 {matrix_title} — {gross_title} {self._generate_help_icon('risk_matrix')}</h3>
                <span class="matrix-subtitle">Before controls</span>
            </div>
            <div class="matrix-container">
                {self._generate_matrix_table(df, 'gross', y_axis, x_axis, prob_labels, impact_labels)}
                <div class="matrix-legend">
                    <div class="legend-item"><span class="legend-color legend-low"></span> Low (1-3)</div>
                    <div class="legend-item"><span class="legend-color legend-moderate"></span> Moderate (4-6)</div>
                    <div class="legend-item"><span class="legend-color legend-high"></span> High (8-9)</div>
                    <div class="legend-item"><span class="legend-color legend-critical"></span> Critical (12-16)</div>
                </div>
            </div>
        </div>
        
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">✅ {matrix_title} — {residual_title}</h3>
                <span class="matrix-subtitle">After controls</span>
            </div>
            <div class="matrix-container">
                {self._generate_matrix_table(df, 'residual', y_axis, x_axis, prob_labels, impact_labels)}
                <div class="matrix-legend">
                    <div class="legend-item"><span class="legend-color legend-low"></span> Low (1-3)</div>
                    <div class="legend-item"><span class="legend-color legend-moderate"></span> Moderate (4-6)</div>
                    <div class="legend-item"><span class="legend-color legend-high"></span> High (8-9)</div>
                    <div class="legend-item"><span class="legend-color legend-critical"></span> Critical (12-16)</div>
                </div>
            </div>
        </div>
    </div>'''
    
    def _generate_matrix_table(self, df: pd.DataFrame, risk_type: str, 
                                y_axis: str, x_axis: str,
                                prob_labels: dict, impact_labels: dict) -> str:
        """Generate a Sapin II compliant risk matrix table."""
        prob_col = f'prob_{risk_type}'
        impact_col = f'impact_{risk_type}'
        
        rows = []
        
        # Generate rows (probability 4 to 1, top to bottom)
        for prob in range(4, 0, -1):
            cells = []
            for impact in range(1, 5):
                count = len(df[(df[prob_col] == prob) & (df[impact_col] == impact)])
                score = prob * impact
                
                # Sapin II risk thresholds
                if score <= 3:
                    level_class = 'level-low'
                    level_name = 'Low'
                elif score <= 6:
                    level_class = 'level-moderate'
                    level_name = 'Moderate'
                elif score <= 9:
                    level_class = 'level-high'
                    level_name = 'High'
                else:
                    level_class = 'level-critical'
                    level_name = 'Critical'
                
                display = count
                tooltip = f'{level_name} Risk (P={prob} × I={impact} = {score})'
                
                cells.append(f'''
                    <td>
                        <div class="matrix-cell {level_class}" onclick="filterByMatrix({prob}, {impact}, '{risk_type}')">
                            {display}
                            <span class="tooltip">{tooltip}</span>
                        </div>
                    </td>''')
            
            prob_label = prob_labels.get(str(prob), f'Level {prob}')
            rows.append(f'''
                <tr>
                    <td class="matrix-prob-label"><span class="matrix-prob-num">{prob}</span>{prob_label}</td>
                    {''.join(cells)}
                </tr>''')
        
        # Impact header row
        impact_headers = []
        for impact in range(1, 5):
            impact_label = impact_labels.get(str(impact), f'Level {impact}')
            impact_headers.append(f'''
                <th class="matrix-impact-label">
                    <span class="matrix-impact-num">{impact}</span>
                    {impact_label}
                </th>''')
        
        return f'''
            <table class="risk-matrix-table">
                <tr>
                    <th class="matrix-corner"></th>
                    {''.join(impact_headers)}
                </tr>
                {''.join(rows)}
                <tr>
                    <td class="matrix-y-axis-cell">
                        <div class="matrix-y-axis">{y_axis}</div>
                    </td>
                    <td colspan="4" class="matrix-x-axis">{x_axis}</td>
                </tr>
            </table>'''
    
    def _generate_detailed_analysis_section(self, analysis: RiskAnalysis, df: pd.DataFrame) -> str:
        """Generate detailed analysis section with Top Critical Risks and Action Plans."""
        # Generate Top 5 Critical Risks with action plans
        top_critical_risks = self._generate_top_critical_risks_table(analysis.top_risks, df)
        
        return f'''
    <div class="charts-grid animate-in" style="animation-delay: 0.4s;">
        <div class="chart-card" style="grid-column: span 2;">
            <div class="chart-header">
                <h3 class="chart-title">🎯 Top Critical Risks - Action Required {self._generate_help_icon('top_critical')}</h3>
            </div>
            {top_critical_risks}
        </div>
    </div>
    
    <div class="charts-grid animate-in" style="animation-delay: 0.42s;">
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">⚠️ Top 10 Highest Residual Risks</h3>
            </div>
            <ul class="top-risks-list">
                {self._generate_top_risks_list(analysis.top_risks)}
            </ul>
        </div>
        
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">🏢 Entity Summary {self._generate_help_icon('entity_summary')}</h3>
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Entity</th>
                        <th>Risks</th>
                        <th>Critical</th>
                        <th>High</th>
                        <th>Avg Score</th>
                    </tr>
                </thead>
                <tbody>
                    {self._generate_entity_rows(analysis.by_entity)}
                </tbody>
            </table>
        </div>
    </div>
    
    <div class="charts-grid animate-in" style="animation-delay: 0.45s;">
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">🎯 Mitigation Effectiveness</h3>
            </div>
            <div class="chart-container">
                <canvas id="mitigationChart"></canvas>
            </div>
        </div>
        
        <div class="chart-card">
            <div class="chart-header">
                <h3 class="chart-title">🕸️ Category Risk Radar</h3>
            </div>
            <div class="chart-container">
                <canvas id="categoryRadarChart"></canvas>
            </div>
        </div>
    </div>'''
    
    def _generate_top_critical_risks_table(self, top_risks: List[Dict], df: pd.DataFrame) -> str:
        """Generate a table of top critical/high risks with action plans."""
        # Filter to Critical and High only (top 5)
        critical_high = [r for r in top_risks 
                         if '🔴' in r.get('level_residual', '') or '🟠' in r.get('level_residual', '')][:5]
        
        if not critical_high:
            return '<p style="text-align: center; color: var(--text-muted); padding: 20px;">✓ No critical or high risks found</p>'
        
        rows = []
        for risk in critical_high:
            level = risk.get('level_residual', '')
            level_class = 'badge-critical' if '🔴' in level else 'badge-high'
            level_text = 'Critical' if '🔴' in level else 'High'
            
            scenario = str(risk.get('scenario', ''))[:50]
            if len(str(risk.get('scenario', ''))) > 50:
                scenario += '...'
            
            # Get action plan from dataframe
            risk_id = risk.get('risk_id', '')
            action_plan = ''
            control_owner = ''
            
            if not df.empty and 'risk_id' in df.columns:
                risk_row = df[df['risk_id'] == risk_id]
                if not risk_row.empty:
                    action_plan = str(risk_row.iloc[0].get('corrective_actions', '') or '')[:80]
                    if len(str(risk_row.iloc[0].get('corrective_actions', '') or '')) > 80:
                        action_plan += '...'
                    control_owner = str(risk_row.iloc[0].get('control_owner', '') or '')
            
            action_status = '✓' if action_plan else '⚠️ Pending'
            action_class = '' if action_plan else 'style="color: var(--warning);"'
            
            rows.append(f'''
                <tr onclick="showRiskDetail('{risk.get('entity', '')}', '{risk_id}')" style="cursor: pointer;">
                    <td><span class="risk-badge {level_class}">{level_text}</span></td>
                    <td><strong>{risk_id}</strong></td>
                    <td>{risk.get('entity', '')}</td>
                    <td>{scenario}</td>
                    <td style="text-align: center;">{risk.get('score_gross', '')} → {risk.get('score_residual', '')}</td>
                    <td {action_class}>{action_plan if action_plan else action_status}</td>
                    <td>{control_owner if control_owner else '-'}</td>
                </tr>''')
        
        return f'''
            <div style="overflow-x: auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 80px;">Level</th>
                            <th style="width: 60px;">ID</th>
                            <th>Entity</th>
                            <th>Scenario</th>
                            <th style="width: 100px;">Score</th>
                            <th>Action Plan</th>
                            <th style="width: 120px;">Owner</th>
                        </tr>
                    </thead>
                    <tbody>
                        {''.join(rows)}
                    </tbody>
                </table>
            </div>'''
    
    def _generate_top_risks_list(self, top_risks: List[Dict]) -> str:
        """Generate top risks list."""
        items = []
        for risk in top_risks:
            level = risk.get('level_residual', '')
            if '🔴' in level:
                level_class = 'critical'
            elif '🟠' in level:
                level_class = 'high'
            elif '🟡' in level:
                level_class = 'moderate'
            else:
                level_class = 'low'
            
            scenario = str(risk.get('scenario', ''))[:60]
            if len(str(risk.get('scenario', ''))) > 60:
                scenario += '...'
            
            risk_id = risk.get('risk_id', '')
            entity = risk.get('entity', '')
            
            items.append(f'''
                <li class="risk-item {level_class}" onclick="showRiskDetail('{entity}', '{risk_id}')">
                    <div class="risk-info">
                        <span class="risk-entity">{entity} • {risk_id}</span>
                        <div class="risk-scenario">{scenario}</div>
                    </div>
                    <div class="risk-score-display">
                        <div class="score-change">
                            <span class="score-gross">{risk.get('score_gross', '')}</span>
                            <span class="score-arrow">→</span>
                            <span class="risk-score-value">{risk.get('score_residual', '')}</span>
                        </div>
                    </div>
                </li>''')
        
        return '\n'.join(items)
    
    def _generate_entity_rows(self, by_entity: Dict) -> str:
        """Generate entity table rows with links to entity dashboards."""
        rows = []
        for entity_name, stats in sorted(by_entity.items()):
            critical_badge = (
                f'<span class="risk-badge badge-critical">{stats.critical_count}</span>'
                if stats.critical_count > 0 
                else '<span style="color: var(--text-muted);">0</span>'
            )
            high_badge = (
                f'<span class="risk-badge badge-high">{stats.high_count}</span>'
                if stats.high_count > 0 
                else '<span style="color: var(--text-muted);">0</span>'
            )
            
            # Generate entity dashboard link
            entity_filename = self.get_entity_filename(entity_name)
            
            rows.append(f'''
                <tr>
                    <td class="entity">
                        <a href="{entity_filename}" class="entity-link" onclick="event.stopPropagation(); window.location.href='{entity_filename}';" title="View {entity_name} Dashboard">
                            🏢 {entity_name}
                            <span class="entity-link-icon">→</span>
                        </a>
                    </td>
                    <td onclick="filterByEntity('{entity_name}')" style="cursor: pointer;">{stats.total_risks}</td>
                    <td onclick="filterByEntity('{entity_name}')" style="cursor: pointer;">{critical_badge}</td>
                    <td onclick="filterByEntity('{entity_name}')" style="cursor: pointer;">{high_badge}</td>
                    <td onclick="filterByEntity('{entity_name}')" style="cursor: pointer;">{stats.avg_residual_score:.1f}</td>
                </tr>''')
        
        return '\n'.join(rows)
    
    def _generate_risk_table_section(self, df: pd.DataFrame) -> str:
        """Generate full risk registry table."""
        help_icon = self._generate_help_icon('risk_table')
        return f'''
    <div class="table-card animate-in" style="animation-delay: 0.5s;" id="risk-table">
        <div class="table-header">
            <h3 class="table-title">📋 Complete Risk Registry {help_icon}</h3>
            <input type="text" class="table-search" placeholder="Search registry..." 
                   id="registry-search" oninput="filterRegistry()">
        </div>
        <div style="overflow-x: auto;">
            <table class="data-table" id="risk-registry">
                <thead>
                    <tr>
                        <th onclick="sortRegistry('entity')">Entity <span class="sort-icon">↕</span></th>
                        <th onclick="sortRegistry('risk_id')">ID <span class="sort-icon">↕</span></th>
                        <th onclick="sortRegistry('scenario')">Scenario <span class="sort-icon">↕</span></th>
                        <th onclick="sortRegistry('score_gross')">Gross <span class="sort-icon">↕</span></th>
                        <th onclick="sortRegistry('score_residual')">Residual <span class="sort-icon">↕</span></th>
                        <th onclick="sortRegistry('level_residual')">Level <span class="sort-icon">↕</span></th>
                    </tr>
                </thead>
                <tbody id="registry-body">
                    <!-- Populated by JavaScript -->
                </tbody>
            </table>
        </div>
        <div style="padding: 16px; color: var(--text-muted); text-align: center;" id="registry-status">
            Loading risk data...
        </div>
    </div>'''
    
    def _generate_risk_modal(self) -> str:
        """Generate risk detail modal."""
        return '''
    <div class="modal-overlay" id="risk-modal" onclick="closeModal(event)">
        <div class="modal" onclick="event.stopPropagation()">
            <div class="modal-header">
                <h2 class="modal-title" id="modal-title">Risk Details</h2>
                <button class="modal-close" onclick="closeModal()">✕</button>
            </div>
            <div class="modal-body">
                <div class="modal-scores">
                    <div class="score-block gross">
                        <div class="score-block-label">Gross Risk</div>
                        <div class="score-block-value" id="modal-gross-score">-</div>
                        <div class="score-block-details" id="modal-gross-details">P:- × I:-</div>
                    </div>
                    <div class="score-block residual">
                        <div class="score-block-label">Residual Risk</div>
                        <div class="score-block-value" id="modal-residual-score">-</div>
                        <div class="score-block-details" id="modal-residual-details">P:- × I:-</div>
                    </div>
                </div>
                
                <div class="modal-section">
                    <div class="modal-section-title">Scenario</div>
                    <div class="modal-section-content" id="modal-scenario">-</div>
                </div>
                
                <div class="modal-section">
                    <div class="modal-section-title">Description</div>
                    <div class="modal-section-content" id="modal-description">-</div>
                </div>
                
                <div class="modal-section">
                    <div class="modal-section-title">Aggravating Factors</div>
                    <div class="modal-section-content" id="modal-factors">-</div>
                </div>
                
                <div class="modal-section">
                    <div class="modal-section-title">Prevention Measures</div>
                    <div class="modal-section-content" id="modal-prevention">-</div>
                </div>
                
                <div class="modal-section">
                    <div class="modal-section-title">Corrective Actions</div>
                    <div class="modal-section-content" id="modal-actions">-</div>
                </div>
            </div>
        </div>
    </div>'''
    
    def _generate_footer(self, analysis: RiskAnalysis) -> str:
        """Generate footer."""
        return f'''
    <div class="footer">
        <div class="footer-links">
            <a href="#" class="footer-link" onclick="exportToPDF(); return false;">Export PDF</a>
            <a href="#" class="footer-link" onclick="exportToCSV(); return false;">Export CSV</a>
            <a href="#" class="footer-link" onclick="printDashboard(); return false;">Print</a>
        </div>
        <p>Risk Cartography Dashboard • {analysis.summary.total_entities} Entities • {analysis.summary.total_risks} Risk Records</p>
        <p style="margin-top: 4px;">Generated {datetime.now().strftime('%Y-%m-%d at %H:%M:%S')}</p>
    </div>'''
    
    def _generate_scripts(self, analysis: RiskAnalysis, risks_json: str) -> str:
        """Generate JavaScript."""
        # Prepare chart data
        level_data = [
            analysis.by_level.get('🟢 Low', type('', (), {'count': 0})).count,
            analysis.by_level.get('🟡 Moderate', type('', (), {'count': 0})).count,
            analysis.by_level.get('🟠 High', type('', (), {'count': 0})).count,
            analysis.by_level.get('🔴 Critical', type('', (), {'count': 0})).count
        ]
        
        cat_labels = [s.category_name for s in analysis.by_category.values()]
        cat_counts = [s.count for s in analysis.by_category.values()]
        cat_colors = [s.color for s in analysis.by_category.values()]
        cat_gross = [round(s.avg_gross_score, 1) for s in analysis.by_category.values()]
        cat_residual = [round(s.avg_residual_score, 1) for s in analysis.by_category.values()]
        
        entity_names = list(analysis.by_entity.keys())
        entity_critical = [s.critical_count for s in analysis.by_entity.values()]
        entity_high = [s.high_count for s in analysis.by_entity.values()]
        entity_moderate = [s.moderate_count for s in analysis.by_entity.values()]
        entity_low = [s.low_count for s in analysis.by_entity.values()]
        entity_gross = [round(s.avg_gross_score, 1) for s in analysis.by_entity.values()]
        entity_residual = [round(s.avg_residual_score, 1) for s in analysis.by_entity.values()]
        
        m = analysis.mitigation
        
        return f'''
    <script>
        // === Global Data ===
        const allRisks = {risks_json};
        let filteredRisks = [...allRisks];
        let sortColumn = null;
        let sortDirection = 'asc';
        let charts = {{}};
        
        // === Theme Toggle ===
        function toggleTheme() {{
            const html = document.documentElement;
            const current = html.getAttribute('data-theme');
            const newTheme = current === 'dark' ? 'light' : 'dark';
            html.setAttribute('data-theme', newTheme);
            document.getElementById('theme-icon').textContent = newTheme === 'dark' ? '🌙' : '☀️';
            localStorage.setItem('theme', newTheme);
            updateChartColors();
        }}
        
        // Load saved theme
        const savedTheme = localStorage.getItem('theme') || 'dark';
        document.documentElement.setAttribute('data-theme', savedTheme);
        document.getElementById('theme-icon').textContent = savedTheme === 'dark' ? '🌙' : '☀️';
        
        // === Chart Configuration ===
        Chart.defaults.color = '#9ca3af';
        Chart.defaults.borderColor = 'rgba(255,255,255,0.08)';
        
        const chartColors = {{
            success: '#10b981',
            warning: '#f59e0b',
            orange: '#f97316',
            danger: '#ef4444',
            accent: '#00d4ff'
        }};
        
        function updateChartColors() {{
            const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
            Chart.defaults.color = isDark ? '#9ca3af' : '#64748b';
            Chart.defaults.borderColor = isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
            Object.values(charts).forEach(chart => chart.update());
        }}
        
        // === Initialize Charts ===
        document.addEventListener('DOMContentLoaded', function() {{
            // Risk Level Doughnut Chart
            charts.riskLevel = new Chart(document.getElementById('riskLevelChart'), {{
                type: 'doughnut',
                data: {{
                    labels: ['Low', 'Moderate', 'High', 'Critical'],
                    datasets: [{{
                        data: {level_data},
                        backgroundColor: [chartColors.success, chartColors.warning, chartColors.orange, chartColors.danger],
                        borderWidth: 0,
                        hoverOffset: 8
                    }}]
                }},
                options: {{
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '65%',
                    plugins: {{
                        legend: {{ position: 'bottom', labels: {{ padding: 16 }} }},
                        tooltip: {{
                            callbacks: {{
                                label: function(ctx) {{
                                    const total = ctx.dataset.data.reduce((a, b) => a + b, 0);
                                    const pct = ((ctx.raw / total) * 100).toFixed(1);
                                    return ctx.label + ': ' + ctx.raw + ' (' + pct + '%)';
                                }}
                            }}
                        }}
                    }},
                    animation: {{ animateRotate: true, animateScale: true }}
                }}
            }});
            
            // Category Bar Chart
            charts.category = new Chart(document.getElementById('categoryChart'), {{
                type: 'bar',
                data: {{
                    labels: {json.dumps(cat_labels)},
                    datasets: [{{
                        label: 'Risk Count',
                        data: {cat_counts},
                        backgroundColor: {json.dumps(cat_colors)},
                        borderRadius: 6,
                        borderSkipped: false
                    }}]
                }},
                options: {{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {{
                        legend: {{ display: false }},
                        tooltip: {{
                            callbacks: {{
                                title: function(ctx) {{ return ctx[0].label; }},
                                label: function(ctx) {{ return ctx.raw + ' risks'; }}
                            }}
                        }}
                    }},
                    scales: {{
                        y: {{ beginAtZero: true, ticks: {{ stepSize: 5 }} }},
                        x: {{ grid: {{ display: false }} }}
                    }},
                    animation: {{ duration: 800, easing: 'easeOutQuart' }}
                }}
            }});
            
            // Entity Stacked Bar Chart
            charts.entity = new Chart(document.getElementById('entityChart'), {{
                type: 'bar',
                data: {{
                    labels: {json.dumps(entity_names)},
                    datasets: [
                        {{ label: 'Critical', data: {entity_critical}, backgroundColor: chartColors.danger, borderRadius: 3 }},
                        {{ label: 'High', data: {entity_high}, backgroundColor: chartColors.orange, borderRadius: 3 }},
                        {{ label: 'Moderate', data: {entity_moderate}, backgroundColor: chartColors.warning, borderRadius: 3 }},
                        {{ label: 'Low', data: {entity_low}, backgroundColor: chartColors.success, borderRadius: 3 }}
                    ]
                }},
                options: {{
                    indexAxis: 'y',
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {{ legend: {{ position: 'bottom' }} }},
                    scales: {{
                        x: {{ stacked: true }},
                        y: {{ stacked: true, grid: {{ display: false }} }}
                    }},
                    animation: {{ duration: 800 }}
                }}
            }});
            
            // Gross vs Residual Comparison
            charts.comparison = new Chart(document.getElementById('comparisonChart'), {{
                type: 'bar',
                data: {{
                    labels: {json.dumps(entity_names)},
                    datasets: [
                        {{ label: 'Gross', data: {entity_gross}, backgroundColor: 'rgba(249,115,22,0.7)', borderRadius: 4 }},
                        {{ label: 'Residual', data: {entity_residual}, backgroundColor: 'rgba(16,185,129,0.7)', borderRadius: 4 }}
                    ]
                }},
                options: {{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {{ legend: {{ position: 'bottom' }} }},
                    scales: {{
                        y: {{ beginAtZero: true, max: 16 }},
                        x: {{ grid: {{ display: false }} }}
                    }},
                    animation: {{ duration: 800 }}
                }}
            }});
            
            // Mitigation Pie Chart
            charts.mitigation = new Chart(document.getElementById('mitigationChart'), {{
                type: 'pie',
                data: {{
                    labels: ['Reduced', 'Unchanged', 'Increased'],
                    datasets: [{{
                        data: [{m.improved if m else 0}, {m.unchanged if m else 0}, {m.worsened if m else 0}],
                        backgroundColor: [chartColors.success, '#6b7280', chartColors.danger],
                        borderWidth: 0
                    }}]
                }},
                options: {{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {{ legend: {{ position: 'bottom' }} }},
                    animation: {{ animateRotate: true }}
                }}
            }});
            
            // Gross vs Residual by Category - Control Effectiveness Chart
            charts.grossResidual = new Chart(document.getElementById('grossResidualChart'), {{
                type: 'bar',
                data: {{
                    labels: {json.dumps(cat_labels)},
                    datasets: [
                        {{ 
                            label: 'Gross Score', 
                            data: {cat_gross}, 
                            backgroundColor: 'rgba(239, 68, 68, 0.7)', 
                            borderColor: 'rgba(239, 68, 68, 1)',
                            borderWidth: 1,
                            borderRadius: 4 
                        }},
                        {{ 
                            label: 'Residual Score', 
                            data: {cat_residual}, 
                            backgroundColor: 'rgba(16, 185, 129, 0.7)', 
                            borderColor: 'rgba(16, 185, 129, 1)',
                            borderWidth: 1,
                            borderRadius: 4 
                        }}
                    ]
                }},
                options: {{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {{ 
                        legend: {{ position: 'top' }},
                        tooltip: {{
                            callbacks: {{
                                afterLabel: function(ctx) {{
                                    const gross = {cat_gross};
                                    const residual = {cat_residual};
                                    const idx = ctx.dataIndex;
                                    if (ctx.datasetIndex === 1 && gross[idx] > 0) {{
                                        const reduction = ((gross[idx] - residual[idx]) / gross[idx] * 100).toFixed(0);
                                        return 'Reduction: ' + reduction + '%';
                                    }}
                                    return '';
                                }}
                            }}
                        }}
                    }},
                    scales: {{
                        y: {{ beginAtZero: true, max: 16, title: {{ display: true, text: 'Avg Score (P×I)' }} }},
                        x: {{ grid: {{ display: false }} }}
                    }},
                    animation: {{ duration: 800 }}
                }}
            }});
            
            // Category Radar Chart
            charts.categoryRadar = new Chart(document.getElementById('categoryRadarChart'), {{
                type: 'radar',
                data: {{
                    labels: {json.dumps([l[:12] for l in cat_labels])},
                    datasets: [
                        {{ 
                            label: 'Gross', 
                            data: {cat_gross}, 
                            backgroundColor: 'rgba(249,115,22,0.2)', 
                            borderColor: chartColors.orange, 
                            pointBackgroundColor: chartColors.orange,
                            pointRadius: 4
                        }},
                        {{ 
                            label: 'Residual', 
                            data: {cat_residual}, 
                            backgroundColor: 'rgba(16,185,129,0.2)', 
                            borderColor: chartColors.success, 
                            pointBackgroundColor: chartColors.success,
                            pointRadius: 4
                        }}
                    ]
                }},
                options: {{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {{ legend: {{ position: 'bottom' }} }},
                    scales: {{
                        r: {{ 
                            beginAtZero: true, 
                            max: 16,
                            ticks: {{ stepSize: 4 }}
                        }}
                    }}
                }}
            }});
            
            // Populate risk registry
            populateRegistry();
        }});
        
        // === Filter Functions ===
        function applyFilters() {{
            const entityFilter = document.getElementById('entity-filter').value;
            const levelFilter = document.getElementById('level-filter').value;
            const categoryFilter = document.getElementById('category-filter').value;
            const searchFilter = document.getElementById('search-filter').value.toLowerCase();
            
            filteredRisks = allRisks.filter(risk => {{
                if (entityFilter && risk.entity !== entityFilter) return false;
                if (levelFilter && risk.level_residual !== levelFilter) return false;
                if (categoryFilter && risk.category !== categoryFilter) return false;
                if (searchFilter) {{
                    const searchText = (risk.scenario + ' ' + risk.description + ' ' + risk.risk_id).toLowerCase();
                    if (!searchText.includes(searchFilter)) return false;
                }}
                return true;
            }});
            
            updateFilterChips();
            populateRegistry();
            document.getElementById('visible-count').textContent = filteredRisks.length;
        }}
        
        function updateFilterChips() {{
            const container = document.getElementById('active-filters');
            const chips = [];
            
            const entity = document.getElementById('entity-filter').value;
            const level = document.getElementById('level-filter').value;
            const category = document.getElementById('category-filter').value;
            
            if (entity) chips.push(createChip('Entity: ' + entity, 'entity-filter'));
            if (level) chips.push(createChip('Level: ' + level.replace(/[🔴🟠🟡🟢]/g, '').trim(), 'level-filter'));
            if (category) chips.push(createChip('Category: ' + category, 'category-filter'));
            
            container.innerHTML = chips.join('');
        }}
        
        function createChip(text, filterId) {{
            return '<span class="filter-chip">' + text + 
                   '<span class="filter-chip-remove" onclick="clearFilter(\\'' + filterId + '\\')">✕</span></span>';
        }}
        
        function clearFilter(filterId) {{
            document.getElementById(filterId).value = '';
            applyFilters();
        }}
        
        function resetFilters() {{
            document.getElementById('entity-filter').value = '';
            document.getElementById('level-filter').value = '';
            document.getElementById('category-filter').value = '';
            document.getElementById('search-filter').value = '';
            applyFilters();
        }}
        
        function filterByEntity(entity) {{
            document.getElementById('entity-filter').value = entity;
            applyFilters();
            document.getElementById('risk-table').scrollIntoView({{ behavior: 'smooth' }});
        }}
        
        function filterByLevel(level) {{
            document.getElementById('level-filter').value = level;
            applyFilters();
        }}
        
        function filterCritical() {{
            filterByLevel('🔴 Critical');
            document.getElementById('risk-table').scrollIntoView({{ behavior: 'smooth' }});
        }}
        
        function filterByMatrix(prob, impact, type) {{
            const filtered = allRisks.filter(r => 
                r['prob_' + type] === prob && r['impact_' + type] === impact
            );
            if (filtered.length > 0) {{
                filteredRisks = filtered;
                populateRegistry();
                document.getElementById('visible-count').textContent = filtered.length;
                document.getElementById('risk-table').scrollIntoView({{ behavior: 'smooth' }});
            }}
        }}
        
        // === Registry Functions ===
        function populateRegistry() {{
            const tbody = document.getElementById('registry-body');
            const search = document.getElementById('registry-search')?.value.toLowerCase() || '';
            
            let data = [...filteredRisks];
            
            // Apply registry search
            if (search) {{
                data = data.filter(r => 
                    (r.entity + r.risk_id + r.scenario).toLowerCase().includes(search)
                );
            }}
            
            // Apply sorting
            if (sortColumn) {{
                data.sort((a, b) => {{
                    let valA = a[sortColumn];
                    let valB = b[sortColumn];
                    if (typeof valA === 'number') {{
                        return sortDirection === 'asc' ? valA - valB : valB - valA;
                    }}
                    valA = String(valA).toLowerCase();
                    valB = String(valB).toLowerCase();
                    return sortDirection === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
                }});
            }}
            
            // Generate rows
            let html = '';
            data.forEach(risk => {{
                const level = risk.level_residual;
                let badgeClass = 'badge-low';
                if (level.includes('🔴')) badgeClass = 'badge-critical';
                else if (level.includes('🟠')) badgeClass = 'badge-high';
                else if (level.includes('🟡')) badgeClass = 'badge-moderate';
                
                const scenario = risk.scenario.length > 50 ? risk.scenario.substring(0, 50) + '...' : risk.scenario;
                const levelLabel = level.replace(/[🔴🟠🟡🟢]/g, '').trim();
                
                html += '<tr onclick="showRiskDetail(\\'' + risk.entity + '\\', \\'' + risk.risk_id + '\\')">' +
                    '<td class="entity">' + risk.entity + '</td>' +
                    '<td>' + risk.risk_id + '</td>' +
                    '<td>' + scenario + '</td>' +
                    '<td><span class="score-pill" style="background: rgba(249,115,22,0.2); color: #f97316;">' + risk.score_gross + '</span></td>' +
                    '<td><span class="score-pill" style="background: rgba(16,185,129,0.2); color: #10b981;">' + risk.score_residual + '</span></td>' +
                    '<td><span class="risk-badge ' + badgeClass + '">' + levelLabel + '</span></td>' +
                    '</tr>';
            }});
            
            tbody.innerHTML = html;
            document.getElementById('registry-status').textContent = 'Showing ' + data.length + ' of ' + allRisks.length + ' risks';
        }}
        
        function filterRegistry() {{
            populateRegistry();
        }}
        
        function sortRegistry(column) {{
            if (sortColumn === column) {{
                sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
            }} else {{
                sortColumn = column;
                sortDirection = 'asc';
            }}
            populateRegistry();
        }}
        
        // === Modal Functions ===
        function showRiskDetail(entity, riskId) {{
            const risk = allRisks.find(r => r.entity === entity && r.risk_id === riskId);
            if (!risk) return;
            
            document.getElementById('modal-title').textContent = entity + ' — ' + riskId;
            document.getElementById('modal-gross-score').textContent = risk.score_gross;
            document.getElementById('modal-gross-details').textContent = 'P:' + risk.prob_gross + ' × I:' + risk.impact_gross;
            document.getElementById('modal-residual-score').textContent = risk.score_residual;
            document.getElementById('modal-residual-details').textContent = 'P:' + risk.prob_residual + ' × I:' + risk.impact_residual;
            document.getElementById('modal-scenario').textContent = risk.scenario || '-';
            document.getElementById('modal-description').textContent = risk.description || '-';
            document.getElementById('modal-factors').textContent = risk.aggravating_factors || '-';
            document.getElementById('modal-prevention').textContent = risk.prevention_measures || '-';
            document.getElementById('modal-actions').textContent = risk.corrective_actions || '-';
            
            document.getElementById('risk-modal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }}
        
        function closeModal(event) {{
            if (event && event.target !== document.getElementById('risk-modal')) return;
            document.getElementById('risk-modal').classList.remove('active');
            document.body.style.overflow = '';
        }}
        
        // Close on Escape
        document.addEventListener('keydown', function(e) {{
            if (e.key === 'Escape') closeModal();
        }});
        
        // === Export Functions ===
        function exportToPDF() {{
            window.print();
        }}
        
        function exportToCSV() {{
            const headers = ['Entity', 'Risk ID', 'Scenario', 'Prob Gross', 'Impact Gross', 'Score Gross', 'Prob Residual', 'Impact Residual', 'Score Residual', 'Level'];
            const rows = filteredRisks.map(r => [
                r.entity, r.risk_id, '"' + r.scenario.replace(/"/g, '""') + '"',
                r.prob_gross, r.impact_gross, r.score_gross,
                r.prob_residual, r.impact_residual, r.score_residual,
                r.level_residual.replace(/[🔴🟠🟡🟢]/g, '').trim()
            ]);
            
            let csv = headers.join(',') + '\\n';
            rows.forEach(row => csv += row.join(',') + '\\n');
            
            const blob = new Blob([csv], {{ type: 'text/csv;charset=utf-8;' }});
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'risk_registry_' + new Date().toISOString().slice(0,10) + '.csv';
            link.click();
        }}
        
        function printDashboard() {{
            window.print();
        }}
        
        // === Chart Type Toggle ===
        function toggleChartType(chartId) {{
            const chart = charts.riskLevel;
            chart.config.type = chart.config.type === 'doughnut' ? 'bar' : 'doughnut';
            chart.update();
        }}
    </script>'''
    
    def save(self, html: str, filepath: str) -> str:
        """Save HTML to file."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(html)
        logger.info(f"Enhanced dashboard saved: {filepath}")
        return str(path)


def generate_enhanced_dashboard(
    df: pd.DataFrame,
    analysis: RiskAnalysis,
    output_path: str,
    config: Dict = None
) -> str:
    """
    Convenience function to generate and save enhanced dashboard.
    
    Args:
        df: DataFrame with risk data
        analysis: RiskAnalysis object
        output_path: Output file path
        config: Optional configuration dict
        
    Returns:
        Path to saved file
    """
    generator = EnhancedDashboardGenerator(config=config)
    html = generator.generate(df, analysis)
    return generator.save(html, output_path)


if __name__ == "__main__":
    # Test enhanced dashboard generation
    import sys
    sys.path.insert(0, '.')
    from excel_reader import load_risk_data
    from risk_analyzer import analyze_risks
    import os
    
    test_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    df, _ = load_risk_data(test_dir)
    analysis = analyze_risks(df)
    
    output = os.path.join(test_dir, 'output', 'risk_dashboard_enhanced.html')
    generate_enhanced_dashboard(df, analysis, output)
    
    print(f"\nEnhanced dashboard generated: {output}")
