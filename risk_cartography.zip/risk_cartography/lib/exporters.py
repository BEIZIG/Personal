"""
Exporters module for Risk Cartography Analysis.

Handles:
- CSV export for PowerBI
- JSON export for analysis results
- Excel export (optional)
"""

import pandas as pd
import json
import os
import logging
from typing import Dict, Any, Optional
from pathlib import Path
from dataclasses import dataclass

# Handle both package and direct imports
try:
    from .analyzer import RiskAnalysis
except ImportError:
    from analyzer import RiskAnalysis

logger = logging.getLogger(__name__)


# Default output filenames
@dataclass
class DefaultOutputFilenames:
    """Default filenames for exports."""
    risk_data_csv: str = "powerbi_risk_data.csv"
    entity_summary_csv: str = "powerbi_entity_summary.csv"
    category_summary_csv: str = "powerbi_category_summary.csv"
    risk_matrix_csv: str = "powerbi_risk_matrix.csv"
    analysis_json: str = "powerbi_analysis.json"


DEFAULT_OUTPUT_FILENAMES = DefaultOutputFilenames()


class DataExporter:
    """
    Exports analysis results to various formats.
    
    Usage:
        exporter = DataExporter(output_dir='/path/to/output')
        exporter.export_all(df, analysis)
    """
    
    def __init__(self, output_dir: str, config: Optional[Dict] = None):
        """
        Initialize exporter.
        
        Args:
            output_dir: Directory for output files
            config: Optional configuration overrides
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.config = config or {}
        self.exported_files = []
    
    def export_risk_data_csv(
        self, 
        df: pd.DataFrame, 
        filename: Optional[str] = None
    ) -> str:
        """
        Export raw risk data to CSV.
        
        Args:
            df: DataFrame with risk data
            filename: Output filename (default from config)
            
        Returns:
            Path to exported file
        """
        filename = filename or DEFAULT_OUTPUT_FILENAMES.risk_data_csv
        filepath = self.output_dir / filename
        
        # Clean up level columns for PowerBI
        export_df = df.copy()
        
        if 'level_gross' in export_df.columns:
            export_df['level_gross_clean'] = export_df['level_gross'].str.replace(
                r'^[^\s]+\s', '', regex=True
            )
        
        if 'level_residual' in export_df.columns:
            export_df['level_residual_clean'] = export_df['level_residual'].str.replace(
                r'^[^\s]+\s', '', regex=True
            )
        
        export_df.to_csv(filepath, index=False, encoding='utf-8-sig')
        self.exported_files.append(str(filepath))
        logger.info(f"Exported risk data: {filepath}")
        
        return str(filepath)
    
    def export_entity_summary_csv(
        self, 
        analysis: RiskAnalysis, 
        filename: Optional[str] = None
    ) -> str:
        """
        Export entity summary to CSV.
        
        Args:
            analysis: RiskAnalysis object
            filename: Output filename
            
        Returns:
            Path to exported file
        """
        filename = filename or DEFAULT_OUTPUT_FILENAMES.entity_summary_csv
        filepath = self.output_dir / filename
        
        # Convert entity stats to DataFrame
        data = []
        for entity_name, stats in analysis.by_entity.items():
            data.append({
                'entity': entity_name,
                'total_risks': stats.total_risks,
                'avg_gross_score': stats.avg_gross_score,
                'avg_residual_score': stats.avg_residual_score,
                'critical_count': stats.critical_count,
                'high_count': stats.high_count,
                'moderate_count': stats.moderate_count,
                'low_count': stats.low_count,
                'risk_reduction_pct': stats.risk_reduction_pct
            })
        
        df = pd.DataFrame(data)
        df.to_csv(filepath, index=False, encoding='utf-8-sig')
        self.exported_files.append(str(filepath))
        logger.info(f"Exported entity summary: {filepath}")
        
        return str(filepath)
    
    def export_category_summary_csv(
        self, 
        analysis: RiskAnalysis, 
        filename: Optional[str] = None
    ) -> str:
        """
        Export category summary to CSV.
        
        Args:
            analysis: RiskAnalysis object
            filename: Output filename
            
        Returns:
            Path to exported file
        """
        filename = filename or DEFAULT_OUTPUT_FILENAMES.category_summary_csv
        filepath = self.output_dir / filename
        
        # Convert category stats to DataFrame
        data = []
        for cat_code, stats in analysis.by_category.items():
            data.append({
                'category_code': cat_code,
                'category_name': stats.category_name,
                'color': stats.color,
                'count': stats.count,
                'avg_gross_score': stats.avg_gross_score,
                'avg_residual_score': stats.avg_residual_score
            })
        
        df = pd.DataFrame(data)
        df.to_csv(filepath, index=False, encoding='utf-8-sig')
        self.exported_files.append(str(filepath))
        logger.info(f"Exported category summary: {filepath}")
        
        return str(filepath)
    
    def export_analysis_json(
        self, 
        analysis: RiskAnalysis, 
        filename: Optional[str] = None
    ) -> str:
        """
        Export full analysis to JSON.
        
        Args:
            analysis: RiskAnalysis object
            filename: Output filename
            
        Returns:
            Path to exported file
        """
        filename = filename or DEFAULT_OUTPUT_FILENAMES.analysis_json
        filepath = self.output_dir / filename
        
        analysis_dict = analysis.to_dict()
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(analysis_dict, f, indent=2, ensure_ascii=False, default=str)
        
        self.exported_files.append(str(filepath))
        logger.info(f"Exported analysis JSON: {filepath}")
        
        return str(filepath)
    
    def export_risk_matrix_csv(
        self, 
        analysis: RiskAnalysis, 
        filename: str = 'powerbi_risk_matrix.csv'
    ) -> str:
        """
        Export risk matrix to CSV for PowerBI heatmap.
        
        Args:
            analysis: RiskAnalysis object
            filename: Output filename
            
        Returns:
            Path to exported file
        """
        filepath = self.output_dir / filename
        
        data = []
        for key, count in analysis.risk_matrix_residual.items():
            prob, impact = key.split('x')
            score = int(prob) * int(impact)
            
            # Determine level
            if score <= 2:
                level = 'Low'
            elif score <= 6:
                level = 'Moderate'
            elif score <= 9:
                level = 'High'
            else:
                level = 'Critical'
            
            data.append({
                'probability': int(prob),
                'impact': int(impact),
                'score': score,
                'level': level,
                'count_residual': count,
                'count_gross': analysis.risk_matrix_gross.get(key, 0)
            })
        
        df = pd.DataFrame(data)
        df.to_csv(filepath, index=False, encoding='utf-8-sig')
        self.exported_files.append(str(filepath))
        logger.info(f"Exported risk matrix: {filepath}")
        
        return str(filepath)
    
    def export_excel_with_charts(
        self,
        df: pd.DataFrame,
        analysis: RiskAnalysis,
        filename: str = 'risk_analysis_report.xlsx'
    ) -> str:
        """
        Export complete Excel workbook with charts - ready to use!
        
        Creates:
        - Risk Data sheet (all risks)
        - Entity Summary sheet with bar chart
        - Category Summary sheet with pie chart  
        - Dashboard sheet with multiple charts
        - Risk Matrix sheet
        
        Args:
            df: DataFrame with risk data
            analysis: RiskAnalysis object
            filename: Output filename
            
        Returns:
            Path to exported file
        """
        from openpyxl import Workbook
        from openpyxl.chart import BarChart, PieChart, Reference, DoughnutChart
        from openpyxl.chart.label import DataLabelList
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils.dataframe import dataframe_to_rows
        from openpyxl.formatting.rule import ColorScaleRule
        
        filepath = self.output_dir / filename
        wb = Workbook()
        
        # =====================================================================
        # Sheet 1: Dashboard (Summary)
        # =====================================================================
        ws_dash = wb.active
        ws_dash.title = "Dashboard"
        
        # Title
        ws_dash['A1'] = "🛡️ RISK CARTOGRAPHY DASHBOARD"
        ws_dash['A1'].font = Font(size=20, bold=True, color="0066CC")
        ws_dash.merge_cells('A1:F1')
        
        ws_dash['A2'] = f"Generated: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M')}"
        ws_dash['A2'].font = Font(italic=True, color="666666")
        
        # KPI Section
        ws_dash['A4'] = "KEY METRICS"
        ws_dash['A4'].font = Font(size=14, bold=True)
        
        kpi_data = [
            ("Total Risks", analysis.summary.total_risks),
            ("Total Entities", analysis.summary.total_entities),
            ("Avg Gross Score", f"{analysis.summary.avg_gross_score:.1f}"),
            ("Avg Residual Score", f"{analysis.summary.avg_residual_score:.1f}"),
            ("Risk Reduction", f"{analysis.summary.risk_reduction_pct:+.1f}%"),
            ("Mitigated Risks", analysis.mitigation.improved if analysis.mitigation else 0),
        ]
        
        for i, (label, value) in enumerate(kpi_data):
            row = 5 + i
            ws_dash[f'A{row}'] = label
            ws_dash[f'B{row}'] = value
            ws_dash[f'A{row}'].font = Font(bold=True)
            ws_dash[f'B{row}'].font = Font(size=12, bold=True, color="0066CC")
        
        # Risk Level Distribution for chart
        ws_dash['D4'] = "RISK LEVELS"
        ws_dash['D4'].font = Font(size=14, bold=True)
        
        level_data = [
            ("Level", "Count"),
            ("Low", analysis.by_level.get('🟢 Faible', type('', (), {'count': 0})).count),
            ("Moderate", analysis.by_level.get('🟡 Modéré', type('', (), {'count': 0})).count),
            ("High", analysis.by_level.get('🟠 Élevé', type('', (), {'count': 0})).count),
            ("Critical", analysis.by_level.get('🔴 Critique', type('', (), {'count': 0})).count),
        ]
        
        for i, (level, count) in enumerate(level_data):
            row = 5 + i
            ws_dash[f'D{row}'] = level
            ws_dash[f'E{row}'] = count
        
        # Create Pie Chart for risk levels
        pie = DoughnutChart()
        pie.title = "Risk Level Distribution"
        labels = Reference(ws_dash, min_col=4, min_row=6, max_row=9)
        data = Reference(ws_dash, min_col=5, min_row=5, max_row=9)
        pie.add_data(data, titles_from_data=True)
        pie.set_categories(labels)
        pie.width = 12
        pie.height = 10
        ws_dash.add_chart(pie, "G4")
        
        # Entity data for bar chart
        ws_dash['A14'] = "ENTITY SCORES"
        ws_dash['A14'].font = Font(size=14, bold=True)
        
        ws_dash['A15'] = "Entity"
        ws_dash['B15'] = "Gross"
        ws_dash['C15'] = "Residual"
        
        row = 16
        for entity_name, stats in sorted(analysis.by_entity.items()):
            ws_dash[f'A{row}'] = entity_name
            ws_dash[f'B{row}'] = round(stats.avg_gross_score, 1)
            ws_dash[f'C{row}'] = round(stats.avg_residual_score, 1)
            row += 1
        
        # Create Bar Chart for entities
        bar = BarChart()
        bar.title = "Gross vs Residual by Entity"
        bar.type = "col"
        bar.grouping = "clustered"
        
        max_row = 15 + len(analysis.by_entity)
        data = Reference(ws_dash, min_col=2, max_col=3, min_row=15, max_row=max_row)
        cats = Reference(ws_dash, min_col=1, min_row=16, max_row=max_row)
        bar.add_data(data, titles_from_data=True)
        bar.set_categories(cats)
        bar.width = 18
        bar.height = 10
        ws_dash.add_chart(bar, "A" + str(max_row + 2))
        
        # Adjust column widths
        ws_dash.column_dimensions['A'].width = 20
        ws_dash.column_dimensions['B'].width = 15
        ws_dash.column_dimensions['C'].width = 15
        ws_dash.column_dimensions['D'].width = 15
        ws_dash.column_dimensions['E'].width = 10
        
        # =====================================================================
        # Sheet 2: All Risk Data
        # =====================================================================
        ws_data = wb.create_sheet("Risk Data")
        
        # Prepare clean data
        export_df = df.copy()
        columns_to_export = ['entity', 'risk_id', 'scenario', 'description',
                           'prob_gross', 'impact_gross', 'score_gross', 'level_gross',
                           'prevention_measures', 
                           'prob_residual', 'impact_residual', 'score_residual', 'level_residual',
                           'corrective_actions']
        
        # Only include columns that exist
        columns_to_export = [c for c in columns_to_export if c in export_df.columns]
        export_df = export_df[columns_to_export]
        
        # Write header
        header_fill = PatternFill(start_color="0066CC", end_color="0066CC", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF")
        
        for col_idx, col_name in enumerate(export_df.columns, 1):
            cell = ws_data.cell(row=1, column=col_idx, value=col_name)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center')
        
        # Write data
        for row_idx, row_data in enumerate(export_df.values, 2):
            for col_idx, value in enumerate(row_data, 1):
                ws_data.cell(row=row_idx, column=col_idx, value=value)
        
        # Auto-filter
        ws_data.auto_filter.ref = f"A1:{chr(64+len(columns_to_export))}{len(export_df)+1}"
        
        # Freeze header row
        ws_data.freeze_panes = 'A2'
        
        # =====================================================================
        # Sheet 3: Entity Summary with Chart
        # =====================================================================
        ws_entity = wb.create_sheet("Entity Summary")
        
        # Header
        entity_headers = ['Entity', 'Total Risks', 'Critical', 'High', 'Moderate', 'Low', 
                         'Avg Gross', 'Avg Residual', 'Reduction %']
        
        for col_idx, header in enumerate(entity_headers, 1):
            cell = ws_entity.cell(row=1, column=col_idx, value=header)
            cell.fill = header_fill
            cell.font = header_font
        
        # Data
        row = 2
        for entity_name, stats in sorted(analysis.by_entity.items()):
            ws_entity.cell(row=row, column=1, value=entity_name)
            ws_entity.cell(row=row, column=2, value=stats.total_risks)
            ws_entity.cell(row=row, column=3, value=stats.critical_count)
            ws_entity.cell(row=row, column=4, value=stats.high_count)
            ws_entity.cell(row=row, column=5, value=stats.moderate_count)
            ws_entity.cell(row=row, column=6, value=stats.low_count)
            ws_entity.cell(row=row, column=7, value=round(stats.avg_gross_score, 1))
            ws_entity.cell(row=row, column=8, value=round(stats.avg_residual_score, 1))
            ws_entity.cell(row=row, column=9, value=round(stats.risk_reduction_pct, 1))
            row += 1
        
        # Stacked bar chart for risk levels by entity
        stacked = BarChart()
        stacked.type = "bar"
        stacked.grouping = "stacked"
        stacked.title = "Risk Levels by Entity"
        
        max_row = 1 + len(analysis.by_entity)
        data = Reference(ws_entity, min_col=3, max_col=6, min_row=1, max_row=max_row)
        cats = Reference(ws_entity, min_col=1, min_row=2, max_row=max_row)
        stacked.add_data(data, titles_from_data=True)
        stacked.set_categories(cats)
        stacked.width = 20
        stacked.height = 12
        ws_entity.add_chart(stacked, "K2")
        
        ws_entity.freeze_panes = 'A2'
        
        # =====================================================================
        # Sheet 4: Category Summary
        # =====================================================================
        ws_cat = wb.create_sheet("Category Summary")
        
        cat_headers = ['Code', 'Category', 'Count', 'Avg Gross', 'Avg Residual']
        for col_idx, header in enumerate(cat_headers, 1):
            cell = ws_cat.cell(row=1, column=col_idx, value=header)
            cell.fill = header_fill
            cell.font = header_font
        
        row = 2
        for cat_code, stats in analysis.by_category.items():
            ws_cat.cell(row=row, column=1, value=cat_code)
            ws_cat.cell(row=row, column=2, value=stats.category_name)
            ws_cat.cell(row=row, column=3, value=stats.count)
            ws_cat.cell(row=row, column=4, value=round(stats.avg_gross_score, 1))
            ws_cat.cell(row=row, column=5, value=round(stats.avg_residual_score, 1))
            row += 1
        
        # Pie chart for categories
        cat_pie = PieChart()
        cat_pie.title = "Risks by Category"
        max_row = 1 + len(analysis.by_category)
        labels = Reference(ws_cat, min_col=2, min_row=2, max_row=max_row)
        data = Reference(ws_cat, min_col=3, min_row=1, max_row=max_row)
        cat_pie.add_data(data, titles_from_data=True)
        cat_pie.set_categories(labels)
        cat_pie.width = 14
        cat_pie.height = 10
        ws_cat.add_chart(cat_pie, "G2")
        
        # =====================================================================
        # Sheet 5: Risk Matrix (Heatmap style)
        # =====================================================================
        ws_matrix = wb.create_sheet("Risk Matrix")
        
        ws_matrix['A1'] = "RESIDUAL RISK MATRIX"
        ws_matrix['A1'].font = Font(size=14, bold=True)
        ws_matrix.merge_cells('A1:E1')
        
        # Headers
        ws_matrix['A3'] = "Impact \\ Prob"
        for p in range(1, 5):
            ws_matrix.cell(row=3, column=p+1, value=f"P={p}")
            ws_matrix.cell(row=3, column=p+1).font = Font(bold=True)
            ws_matrix.cell(row=3, column=p+1).alignment = Alignment(horizontal='center')
        
        # Matrix data
        for i in range(4, 0, -1):
            row = 3 + (5 - i)
            ws_matrix.cell(row=row, column=1, value=f"I={i}")
            ws_matrix.cell(row=row, column=1).font = Font(bold=True)
            
            for p in range(1, 5):
                key = f"{p}x{i}"
                count = analysis.risk_matrix_residual.get(key, 0)
                cell = ws_matrix.cell(row=row, column=p+1, value=count if count > 0 else "")
                cell.alignment = Alignment(horizontal='center')
                
                # Color based on score
                score = p * i
                if score <= 2:
                    cell.fill = PatternFill(start_color="C6EFCE", fill_type="solid")  # Green
                elif score <= 6:
                    cell.fill = PatternFill(start_color="FFEB9C", fill_type="solid")  # Yellow
                elif score <= 9:
                    cell.fill = PatternFill(start_color="FFC7CE", fill_type="solid")  # Orange
                else:
                    cell.fill = PatternFill(start_color="FF6B6B", fill_type="solid")  # Red
        
        # Legend
        ws_matrix['A10'] = "Legend:"
        ws_matrix['A10'].font = Font(bold=True)
        
        legend = [("Low (1-2)", "C6EFCE"), ("Moderate (3-6)", "FFEB9C"), 
                  ("High (7-9)", "FFC7CE"), ("Critical (10-16)", "FF6B6B")]
        
        for i, (text, color) in enumerate(legend):
            ws_matrix.cell(row=11+i, column=1, value=text)
            ws_matrix.cell(row=11+i, column=2).fill = PatternFill(start_color=color, fill_type="solid")
        
        # Adjust column widths
        for col in ['A', 'B', 'C', 'D', 'E']:
            ws_matrix.column_dimensions[col].width = 12
        
        # =====================================================================
        # Sheet 6: Top Risks
        # =====================================================================
        ws_top = wb.create_sheet("Top Risks")
        
        ws_top['A1'] = "TOP 10 HIGHEST RESIDUAL RISKS"
        ws_top['A1'].font = Font(size=14, bold=True)
        ws_top.merge_cells('A1:F1')
        
        top_headers = ['#', 'Entity', 'Risk ID', 'Scenario', 'Gross Score', 'Residual Score']
        for col_idx, header in enumerate(top_headers, 1):
            cell = ws_top.cell(row=3, column=col_idx, value=header)
            cell.fill = header_fill
            cell.font = header_font
        
        for i, risk in enumerate(analysis.top_risks[:10], 1):
            row = 3 + i
            ws_top.cell(row=row, column=1, value=i)
            ws_top.cell(row=row, column=2, value=risk.get('entity', ''))
            ws_top.cell(row=row, column=3, value=risk.get('risk_id', ''))
            ws_top.cell(row=row, column=4, value=str(risk.get('scenario', ''))[:80])
            ws_top.cell(row=row, column=5, value=risk.get('score_gross', ''))
            ws_top.cell(row=row, column=6, value=risk.get('score_residual', ''))
            
            # Color critical rows
            if '🔴' in str(risk.get('level_residual', '')):
                for col in range(1, 7):
                    ws_top.cell(row=row, column=col).fill = PatternFill(
                        start_color="FFCCCC", fill_type="solid")
        
        ws_top.column_dimensions['D'].width = 60
        
        # Save workbook
        wb.save(filepath)
        self.exported_files.append(str(filepath))
        logger.info(f"Exported Excel with charts: {filepath}")
        
        return str(filepath)
    
    def export_all(
        self, 
        df: pd.DataFrame, 
        analysis: RiskAnalysis,
        include_matrix: bool = True,
        include_excel_report: bool = True
    ) -> Dict[str, str]:
        """
        Export all data files.
        
        Args:
            df: DataFrame with risk data
            analysis: RiskAnalysis object
            include_matrix: Whether to export risk matrix CSV
            include_excel_report: Whether to export Excel with charts
            
        Returns:
            Dictionary of exported file paths
        """
        exports = {
            'risk_data': self.export_risk_data_csv(df),
            'entity_summary': self.export_entity_summary_csv(analysis),
            'category_summary': self.export_category_summary_csv(analysis),
            'analysis_json': self.export_analysis_json(analysis)
        }
        
        if include_matrix:
            exports['risk_matrix'] = self.export_risk_matrix_csv(analysis)
        
        if include_excel_report:
            exports['excel_report'] = self.export_excel_with_charts(df, analysis)
        
        logger.info(f"\nExported {len(exports)} files to {self.output_dir}")
        
        return exports
    
    def get_exported_files(self) -> list:
        """Get list of all exported file paths."""
        return self.exported_files.copy()


def export_to_powerbi(
    df: pd.DataFrame, 
    analysis: RiskAnalysis, 
    output_dir: str
) -> Dict[str, str]:
    """
    Convenience function to export all PowerBI files.
    
    Args:
        df: DataFrame with risk data
        analysis: RiskAnalysis object
        output_dir: Output directory
        
    Returns:
        Dictionary of exported file paths
    """
    exporter = DataExporter(output_dir)
    return exporter.export_all(df, analysis)


if __name__ == "__main__":
    # Test exports
    import sys
    sys.path.insert(0, '.')
    from data_loader import load_risk_data
    from analyzer import analyze_risks
    import os
    
    test_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    lib_dir = os.path.join(test_dir, 'lib')
    
    df, _ = load_risk_data(test_dir)
    analysis = analyze_risks(df)
    
    exports = export_to_powerbi(df, analysis, lib_dir)
    
    print("\n=== EXPORTED FILES ===")
    for name, path in exports.items():
        print(f"  {name}: {path}")
